# CoPE – COVID-19 Policy Evaluation tool
#
# An agent-based model of the social spread of COVID-19 with a focus on 
# individual-level behavioral responses to policy. 
# 
# Thank you for your interest in CoPE. 
# If your use of CoPE results in a publication, please cite as follows: 
# 
# Rai Group. (2020). CoPE: COVID-19 Policy Evaluation tool
# 	 Version 0.1. [Computer Software].
#
# This project is under active development. If you find something that needs our 
# attention, please send a message to BAMEx.devs@gmail.com. 
# Your feedback and input is extremely valuable. Thank you!
#
# 
# CovidABM7 
# UT Austin, RaiGroup
# Created: 06/12/2020
#
# 
# 
# options(keep.source=TRUE)
# library(profvis)

#seed <- 8675309
seed <- sample(10000000, 1)
set.seed(seed)

# gc.time()

options(width=250)
# options(show.error.locations=TRUE)
# options(error = function() {
#   sink(stderr())
#   on.exit(sink(NULL))
#   traceback(5, max.lines = 2L)
#   if (!interactive()) {
#     q(status = 1)
#   }
# })

# 7100 : [] testing on Laptop
# 7200 : [55 min on laptop] ATX:5200 (48-453) All-in-one -1:120 PrEX=0.03 Scenario: De28 Du45 TaCDC Co25, Sample0.05 84 seed, Polite Flouters:
# 7201 : [success] Pass model num to scenario
# 7202 : [] CMD call timetest
# 7203 : [] write narratives to tmp timetest 
# 7204 : [] Separate thing timetest 
# 7205 : [] Whole thing timetest + I/O analysis 

args = commandArgs(TRUE)

jobNum = NA
ModelNum = 1
ModelLength = 120
FIPSstate = 48
FIPScounty = 453

if ("jobNum" %in% args) {
	jobNum <- as.numeric(args[match("jobNum", args) + 1])
	print(sprintf("[PreRun]     Got jobNum specified on CMD line: %d", jobNum))
}
if ("ModelNum" %in% args) {
	ModelNum <- as.numeric(args[match("ModelNum", args) + 1])
	print(sprintf("[PreRun]     Got ModelNum specified on CMD line: %d", ModelNum))
}
if ("ModelLength" %in% args) {
	ModelLength <- as.numeric(args[match("ModelLength", args) + 1])
	print(sprintf("[PreRun]     Got ModelLength specified on CMD line: %d", ModelLength))
}
if ("FIPSstate" %in% args) {
	FIPSstate <- as.character(args[match("FIPSstate", args) + 1])
	print(sprintf("[PreRun]     Got FIPSstate specified on CMD line: %s", FIPSstate))
}
if ("FIPScounty" %in% args) {
	FIPScounty <- as.character(args[match("FIPScounty", args) + 1])
	print(sprintf("[PreRun]     Got FIPScounty specified on CMD line: %s", FIPScounty))
}


# - ########################################################
# - ###
# - ###			Establish Parameters
# - ###
# - ########################################################
paramsDF = data.frame(
# - Identification parameters ------------------------------
	seed = seed,
	job = jobNum,
	Model = ModelNum, 										# Used as a outfile designation. Remember to change and log as parameters are altered.
	ModelType = "Regular",								#Regular, SIPParamBlast, Intervention, ParamSweep and ParamMagnitude set by CLI
	batches = 1, 											# Number of batches - batches can have different initial values
	runs = 1,												# Number of runs in a batch - runs share an initialization 
	StartDay = -1, 											# Number of Days in a run. set to Days 
	EndDay = ModelLength, 											# Number of Days in a run. set to Days
	dBug = as.character("OneShot"), 							# Route debugging output to stdout? Separate with ; .Choose from list(c("Control", "Init", "Stage", "Run","Day","Step","Substep","Outs","Off")
	cores = 1,
	indir = "inputs/",
	outdir = "outputs/", 
# - Initialization Modules ---------------------------------
#	StartDate = "01/01/2020",									####### Fix this when I fix initial adopters
#	StartDate = "01/01/2008",
	InitAgentMod = "JailHouse_ACS",									# Specifies an agent initialization module. One of c("JailHouse", "MISSING")
	InitSocNetMod = "JailHouse",								# Specifies a social network initialization module. One of c("JailHouse", "NPaths")
	SeedAdopters = "Off", 									# Use seeded adopters during initialization?
# -	Runtime Modules ----------------------------------------
	RuntimeStageMod = "JailHouse",								# Specifies runtime staging modules. One of c("JailHouse", "JailHouse_CCH", "CC", "ADP")
	RuntimeInfectMod = "JailHouse", 								# Specifies the adoption determining module. One of c("JailHouse", "JailHouse_CCH", "CC", "ADP")
	ProdInc_budget = "Off", 								# Impose a budget contraint on Production incentives?
# - Outputs Modules ----------------------------------------
	RunsOut = "Off", 										# Generate summaries for each run? 
	DaysOut = "Off", 									# Generate summary measures by Day? 
	DynamicsOut = "Off", 									# Generate Agent DynamicsOut? 
	NarrativeOut = "On", 									# Generate Agent Narratives?
	SocNetOut = "Off", 										# Generate Social Network output? 
	ErrorOut = "Off",										# Generate Run-level summary of error?
	EndStateOut = "Off", 									# Generate output with agent final states?
	RemainingProgressionsOut = "Off", 						# Generate output with remaining progressions?
	AllProgressionsOut = "On", 								# Generate output with all progressions?
# - ########################################################
# - ###
# - ###			Initialization Module Specific Parameters
# - ###
# - ########################################################
# - JailHouse ACS Initialization Module ----------------------
	GetNewGeography = TRUE,
	SaveGeography = TRUE,
	#UseGeographyFile
	state = as.character(FIPSstate),    												#Texas state fips code
	county = as.character(FIPScounty),     											#Travis county fips code
#	AgentCSVstub = "inputs/JailHouse_Agents_", 			# Agent state variables, includes HomeValue	AdoptDate	radMEANft	hhIndex	WGSlat	WGSlon	SIA	U	PBC
	AgentsAtCentroid = TRUE,
	SaveAgentPopulation = TRUE,
	AgentPopulationStub = "CovidABM7_JailHouse_ACSAgentPopulation_",					# Path header for Geo neighbors file
	SaveAgentSample = TRUE, 								# Became Useful
	AgentSampleStub = "CovidABM7_JailHouse_ACSAgentSample_",					# Path header for Geo neighbors file
	UsePreviousAgentPopulation = FALSE,
	SampleFrac = 0.05,                       #Sample some fraction of the total number of households
	RandomSample = FALSE,				#sample the populationrandomly instead of representatively 
	UsePreviousAgentSample = FALSE,
	#Specify which agents to load
	loadAgentModel = 5200, 
	loadAgentJob = 1,
	loadAgentBatch = 1,
#	AgentCSVpath = "inputs/Agents_Experimental.csv", 			# Agent state variables, includes HomeValue	AdoptDate	radMEANft	hhIndex	WGSlat	WGSlon	SIA	U	PBC
	Jailhouse_InitialInfectsType = "E",	
	Jailhouse_InitialInfectsMethod = "Random",					# c("Random","Empirical", "Localized","Targeted")
	tractbgTargets = as.character("tbg0006031;tbg0006032;tbg0006033;tbg0006034;tbg0006035;tbg0006041;tbg0006042;tbg0006043"),
	Jailhouse_InitialInfectsCount = 84,
# - MISSING Agent Initialization Module ----------------------

# - JailHouse Social Network Initialization Module -------------
	CalcGeoNei = TRUE,							# Re-calculate Geographic Neighbors? Saves to stripes
	CalcRadius = FALSE, 
	GeoNeiDistance = 2000,
	stripingValue = 10, 								# For very large elements, how many stripes to use?
	GeoNeiFilestub = "processing/CovidABM7_JailHouse_GeoNeiDF_stripe_",				# Path header for Geo neighbors file
#	GeoCandidateMax = 1000, 
	CalcLocals = TRUE,									# Re-calculate locals? Uses stripes
	SaveLocals = FALSE,									# Overwrite locals with re-calculated locals?
	LocalsFilestub = "CovidABM7_JailHouse_LocalsDF_",				# Path header for Geo neighbors file
	DoRewiring = TRUE, 
	SaveSocNet = FALSE,
	SocNetFilestub = "CovidABM7_SocNet_",
	FIT_rho = 0.05,									# Homophily constraint/density parameter
	FIT_lambda = 0.1,								# Random wiring parameter for SWN

# - ########################################################
# - ###
# - ###			Staging Module Specific Parameters
# - ###
# - ########################################################
# - JailHouse Staging Module --------------------------
#########  Begin Epidemiological progression engine
	JailHouse_Durations_UseAges = TRUE, 
	JailHouse_Duration_E = 2.9,								#
	JailHouse_Prob_E_Pa = 0.43,	
#	JailHouse_Prob_E_Py = 0.57,								#
	JailHouse_Duration_Pa = 2.3,
	JailHouse_Duration_Py = 2.3,
	JailHouse_Duration_Ia = 4,								#
	JailHouse_Prob_Ia_Rr = 1.0,								#
	JailHouse_Duration_Iy_Ih = 5.9,							#
	JailHouse_Duration_Iy_Rr = 4,							#
	JailHouse_Prob_Iy_Rr = 0.935,
#	JailHouse_Prob_Iy_Ih = 0.065,
	JailHouse_Prob_Iy_Rr_age = as.character("0.967;0.887;0.823"),
#	JailHouse_Prob_Iy_Ih_age = as.character("0.033;0.113;0.177"),
	JailHouse_Duration_Ih_Rr = 10.9,						#
	JailHouse_Duration_Ih_Rd = 7.8,						#
	JailHouse_Prob_Ih_Rr_age = as.character("0.969;0.893;0.769"),
#	JailHouse_Prob_Ih_Rd_age = as.character("0.031;0.107;0.231"),
	JailHouse_Prob_Ih_Rr = 0.893,							#
# 	JailHouse_Prob_Ih_Rd = 0.107,							#
#########  End Epidemiological progression engine
# - ########################################################
# - ###
# - ###			Runtime Module Specific Parameters
# - ###
# - ########################################################
# - JailHouse Runtime Module - Make Turns--------------------------
	Jailhouse_ActivityExposureBalancer = 0.10,
	Jailhouse_PrExposure = 0.3,
	Jailhouse_tock_resolution = 1,
	JailHouse_ArrivalRate_Esntl = (3/7), 
	JailHouse_ArrivalRate_NonEsntl = (10/7),
	JailHouse_ArrivalRate_Job = (5/7),	
	ContextData = sprintf("scenarii/CovidABM7_Scenario_%d.csv", ModelNum),
	JailHouse_SymptomBehavior = "PoliteFlout", 
#	Jailhouse_Esntl_Thresh = 0.20, 
	Jailhouse_EsntlAssign = "Job", 							# c("Income","Job")
	Jailhouse_Esntl_b0 = -5, 
	Jailhouse_Esntl_b1 = 0.0003, 
	Jailhouse_Esntl_b2 = -0.000000003,
#	Jailhouse_Flout_Thresh = 0.20, 
	Jailhouse_UseAwareness = TRUE,
	Jailhouse_Risk_b0 = 0.2,                                                # Quadratic: -.6
	Jailhouse_Risk_b1 = -0.01,                                      # Quadratic: 0.65
	Jailhouse_Risk_b2 = -0.00001,                                   # Quadratic: -0.01
	Jailhouse_Risk_b3 = -0.01,
# - Experimental switches for turning dynamics on / off
	Jailhouse_DifferentRiskTols = "On",			#On - standard use ages, On_Rand - use runif(0,1), Off_Old - force all old, Off_Young - force all young
	Jailhouse_EventRiskUpdates = "On",			#Toggle risk tolerance updates based on event coparticipants
# - JailHouse Runtime Module - Take Turns--------------------------
	Jailhouse_ApplyGroupThresh = FALSE,
#	Jailhouse_GroupThreshMin = 3,
	Jailhouse_GroupThreshMax = 10,
# - JailHouse Runtime Module - Testing--------------------------
	Jailhouse_TestStrategy = "Off", 							# c("Off","Random","Essential","Flout","RandomLocation","IaOnly")
	Jailhouse_TestStrategyParam = 2,
	Jailhouse_TestFP = 0.2, 
	Jailhouse_TestFN = 0.1, 
	JailHouse_QuarantineDays = 5,
# - JailHouse Runtime Module - Tracing--------------------------
	Jailhouse_TraceStrategy = "Off", 							# c("Off","Neighbors","Previous")
	Jailhouse_TraceStrategyParam = 100,
# - ########################################################
# - ###
# - ###			End Of paramsDF
# - ###
# - ########################################################
ender = 0)
# - ########################################################
# - ###
# - ###			Check CLI args
# - ###
# - ########################################################

# - ########################################################
# - ###
# - ###			Set up Logging
# - ###
# - ########################################################

LogFile = sprintf("runlogs/CovidABM7_Log_%s_job%s.txt", paramsDF$Model[1], paramsDF$job[1])
sink(LogFile, append=FALSE, type=c("output", "message"))
print("[PreRun]     Logging initated at time")
print(Sys.time())
print(sprintf("[PreRun]     Seed is %d", seed))
print("[PreRun]     Loading support functions...")
source("CovidABM7_func_support.R")
print("[PreRun]     Support functions loaded... ")
print("[PreRun]     Loading data structures...")
source("CovidABM7_data_structs.R")
print("[PreRun]     Data structures loaded")

print("[PreRun]     Establishing parameters...")
#-------------------------#
# Interpret Command Line Arguments
#-------------------------#


# - ########################################################
# - ###
# - ###			Backfitting Control, Expand Parameter DF, Param Writing
# - ###
# - ########################################################


#-------------------------#
# Expand Params DF, set params to paramsDF[1]
#-------------------------#
paramsDF$TotalRuns <- paramsDF$batches*paramsDF$runs
paramsDF <- paramsDF[rep(row.names(paramsDF), paramsDF$TotalRuns), ]
#params <- paramsDF[1, ]
paramsDF$subModelID <- paste(rep(1:paramsDF$batches[1], each=paramsDF$runs[1]), rep(seq(1, paramsDF$runs[1]), paramsDF$batches[1]), sep=":")


#-------------------------#
# Set up Param Blasting
#-------------------------#
print(sprintf("[Run]     Model Type is %s", paramsDF$ModelType[1]))
if (paramsDF$ModelType[1] == "SIPParamBlast") {
  print("[Run]     This is a SIP ParamBlast run")
  print("[Run]     ParamBlast variables: Jailhouse_SIPTiming")
  print("[Run]     ParamBlast variables: Jailhouse_SIPDuration")
  print("[Run]     Generating random values...")
  paramsDF$Jailhouse_SIPTiming <- sample(as.integer(seq(21,35)), nrow(paramsDF), replace=TRUE)
  paramsDF$Jailhouse_SIPDuration <- sample(as.integer(seq(45,60)), nrow(paramsDF), replace=TRUE) + paramsDF$Jailhouse_SIPTiming
  print("[Run]     ... Values Generated")
}


write.csv(paramsDF, sprintf("runlogs/CovidABM7_ParamLog_%s_job%s.csv", paramsDF$Model[1], paramsDF$job[1]), row.names=FALSE)
print("[PreRun]     Parameter Log Written")
allParams <- paramsClass$new()
allParams$runParams <- paramsDF
allParams$lockdown()

print("[PreRun]     ...Parameters established and locked")



########################################################
###
###			End Of Runtime setup/parametization
###
########################################################


print("[Run]     Loading function libraries")

source("CovidABM7_func_init.R")
print("[Run]          Initialization Library loaded... ")

source("CovidABM7_func_stage.R")
print("[Run]          Staging Library loaded... ")

source("CovidABM7_func_core.R")
print("[Run]          Core Library loaded... ")

print("[Run]     ...Function libraries loaded successfully")

print("[Run]     Determining Output Initialization...")


if (allParams$runParams$NarrativeOut[1] == "On") {
        NarrativeHeader <- as.matrix(t(c("Time",
        		"ModelNum",
                "subModelID",
                "Runtime",
                "ModelType",
                "FocalAgent",
                "FocalAgentPopID",
                "FocalAgentStatus",
                "FocalAgentEsntl",
                "FocalAgentFlout",
                "FocalAgentTest",
                "FocalAgent_RiskTol",
                "Event",
                "WithAgents",
                "WithAgentsPopID",
                "WithAgentsStatus",
                "WithAgentsEsntl",
                "WithAgentsFlout",
                "WithAgentsTest",
                "WithAgents_RiskTol",
                "ExposerIDs",
                "ExposerPopIDs",
                "NewExposureIDs",
                "NewExposurePopIDs")))
        write.table(NarrativeHeader, file=sprintf("%s/CovidABM7_NarrativeOuts_%s_job%s.csv", dirname(tempdir()), allParams$runParams$Model[1], allParams$runParams$job[1]), sep = ",", col.names = FALSE, row.names = FALSE)
}

print("[Run]     Outputs Initialized")

########################################################
###
###			Runtime Orders
###
########################################################



for (b in 1:max(allParams$runParams$batches)){ 
	set.seed(seed)
	print(sprintf("[Run]     Initializing batch: %d", b))
	params <- allParams$runParams[1, ]
	populationData <- initModel()

	for (r in 1:params$runs){ 
		dBugRun(sprintf("Begining runtime for run: %d", r))
		dBugRun(str(q))
		subModelID <- paste(b,r, sep=":")
		print(sprintf("[Run]     Running run: %d of batch: %d; subModelID: %s", r, b, subModelID))
		print(sprintf("[Run]     Setting params for subModelID: %s", subModelID))

		# If this isn't a single-element vector we're in trouble anyways
		subModelIDIndex = which(paramsDF$subModelID == subModelID)[1]
		params <- allParams$runParams[subModelIDIndex, ]
		set.seed(seed)
		print(system.time(runModel(populationData), gcFirst=FALSE))

	}#------End of runs

}#------End of batches


print("time just before a file write event")
print(Sys.time())

if (params$NarrativeOut == "On") {
	file.copy(from=sprintf("%s/CovidABM7_NarrativeOuts_%s_job%s.csv", dirname(tempdir()), params$Model, params$job),
		to=sprintf("%sCovidABM7_NarrativeOuts_%s_job%s.csv",  params$outdir, params$Model, params$job), overwrite=TRUE)
}

print(proc.time())
print(gc.time())

print("All done. Goodnight.")
warnings()
q()
