# CoPE – COVID-19 Policy Evaluation tool
#
# An agent-based model of the social spread of COVID-19 with a focus on 
# individual-level behavioral responses to policy. 
# 
# Thank you for your interest in CoPE. 
# If your use of CoPE results in a publication, please cite as follows: 
# 
# Rai Group. (2020). CoPE: COVID-19 Policy Evaluation tool
# 	 Version 0.1. [Computer Software].
#
# This project is under active development. If you find something that needs our 
# attention, please send a message to BAMEx.devs@gmail.com. 
# Your feedback and input is extremely valuable. Thank you!
#
# 
# CovidABM7 
# UT Austin, RaiGroup
# Created: 06/12/2020
#
# 

args = commandArgs(TRUE)


#---------------#
# Day Parameters ---- change to Day for the models you want to compare
#---------------#

ModelNumber <- c(7304) 
#RunLength = 120
#CompareDescription <- c("5010") 
#CompareArrivalRate <- c("1/7")
outDir = ("outputs/")
DaylogDir = ("runlogs/")
ProcOutDir = ("processedOuts/")
graphicsDir <- ("analytics/package/")
runlogDir = ("runlogs")

agentStates_vec = c("E","Pa","Py","Ia","Ih","Iy","Rd","Rr","S")

### Set options
UseSample <- "on"
CalcParticipate <- "on"

if (!is.na(args[1])) {
	print("Additional CMD line args present")
	if (args[1] == "PostProcInSeries") { 
		ModelNumber <<- args[2]
		print(sprintf("[PostProc]     Single Package Processing Model Number: %s", ModelNumber))
	}
}	

#-------------------------#
# Import Libraries
#-------------------------#

print("[Anls]          Loading Libraries ...")

library(ggplot2)
library(lubridate)
library(reshape2)
library(scales)
library(tidyverse)
library(dplyr)
library(ggraph)
library(tidygraph)
library(igraph)
library(gridExtra)
library(parallel)
library(DBI)
library(R6)


dataStore <- R6Class("dataStore", public=list(
	writer = function(field){
		print(field)
		print(sprintf("Writing out %s", field))
		saveRDS(self[[field]], file = sprintf("%s/CovidABM7_%s_%s.Rds", ProcOutDir, field, ModelNumber), compress=FALSE)
		invisible(self)
	}
))


PostProcStore <- R6Class("setupDataClass", inherit = dataStore, public = list(
	job = NULL, 
	ParamsData = NULL, 
	ProgressionsData = NULL, 
	NarrativeData = NULL, 
	NetworkData = NULL, 
	ExposerData = NULL
))

PostProcs <- PostProcStore$new()



print("[Anls]          ... Libraries Loaded")

#---------------#
# Get models ParamLogs
#---------------#

print("[Anls]          Reading Model Parameter Logs")
print(sprintf( "[Anls]          ParamLogs:%s", ModelNumber))
print("[Anls]          Finding Model Parameter Logs files")


# Out_pattern = sprintf("CovidABM7_ParamLog_%s_job", ModelNumber)
# Outfiles = unlist(lapply(Out_pattern, function(x) {list.files(path = runlogDir, pattern = x)}))
# # print(Out_pattern)
# # print(Outfiles)
# PostProcs$job <- seq(1,length(Outfiles))
# 
# PostProcs$ParamsData <- mclapply(PostProcs$job, function (j) {
# 	print(sprintf("[Anls]          Reading Model Parameter Log File:%s", Outfiles[j]))
#     fname <- sprintf("%s/%s", runlogDir, Outfiles[j])
# #	print(fname)
#     tmpParamLog <- read.csv(file = fname)
#     tmpParamLog$JobID <- j
#     tmpParamLog$uniqueRunID <- paste(tmpParamLog$Model, tmpParamLog$JobID, tmpParamLog$subModelID, sep = "-")
# 	return(tmpParamLog)
# }, mc.cores = cores)

PostProcs$ParamsData <- readRDS(file=sprintf("%s/CovidABM7_ParamsData_%s.Rds", ProcOutDir, ModelNumber))

# ---------------#
# Get Pop
# ---------------#
pop <-
  read.csv(
    file = sprintf(
      "inputs/%s%02d_%03d_%s.csv",
      PostProcs$ParamsData[[1]]$AgentPopulationStub,
      as.numeric(PostProcs$ParamsData[[1]]$state),
      as.numeric(PostProcs$ParamsData[[1]]$county),
      if (PostProcs$ParamsData[[1]]$UsePreviousAgentPopulation == TRUE) {
      	PostProcs$ParamsData[[1]]$loadAgentModel
      } else {
      	 ModelNumber
      }
    )
  )

#head(pop)

numAgents = nrow(pop)
agentPopID_vec <- seq(1, numAgents)
runDays_vec = seq(PostProcs$ParamsData[[1]]$StartDay, PostProcs$ParamsData[[1]]$EndDay)
RunLength <- max(runDays_vec)

#---------------#
#Load Model Proccessed Outs
#---------------#


print("[Anls]          Reading State Specific Narrative Data and Agent Data")

#Loading only Rd, Ih, Exposures(Pa and Py)
NarrConn = dbConnect(RSQLite::SQLite(), sprintf("processedOuts/CovidABM_Narratives_%s.db", ModelNumber))
ExposedCount <- dbGetQuery(NarrConn, "SELECT sum(ExposedCount) FROM Narratives")
Narr_Param_DF_Pa <- dbGetQuery(NarrConn, "SELECT * FROM Narratives WHERE Event = 'Pa'")
Narr_Param_DF_Py <- dbGetQuery(NarrConn, "SELECT * FROM Narratives WHERE Event = 'Py'")
Narr_Param_DF_Ih <- dbGetQuery(NarrConn, "SELECT * FROM Narratives WHERE Event = 'Ih'")
# Narr_Param_DF_Rd <- dbGetQuery(NarrConn, "SELECT * FROM Narratives WHERE Event = 'Rd'")
pop <- dbGetQuery(NarrConn, "SELECT * FROM agents")
dbDisconnect(NarrConn)

if (sum(ExposedCount) == 0) {
	print("PROBLEM: No New Exposures Generated")
	q()
}

if (nrow(Narr_Param_DF_Ih) == 0) {
	print("PROBLEM: No Hospitalizations Generated")
	q()
}

print("[Anls]          Reading Network Data")

load(file = sprintf("%sCovidABM7_Network_%s.Rdata", ProcOutDir, ModelNumber))


pop <- pop  %>% mutate(AgeHHCat = ifelse(AgeHH < 18, "Under 18y", 
										 ifelse(AgeHH >= 18 & AgeHH < 50, "18-49y",
												ifelse(AgeHH >= 50 & AgeHH < 65, "50-64y", "65y+"))))
pop <- pop %>% mutate(IncomeHHCat = ifelse(IncomeHH < 31000, "Lowest",
										   ifelse(IncomeHH >= 31000 & IncomeHH < 42000, "Lower-Middle",
												  ifelse(IncomeHH >= 42000 & IncomeHH < 126000, "Middle",
														 ifelse(IncomeHH >= 126000 & IncomeHH < 188000, "Upper-Middle", "Higher")))))

pop$PopID <- as.integer(pop$PopID)

genNet <- function(category){
	tmp.ref <- pop %>% select(PopID, category)
	tmp.edges <- edges %>% select(from, to) 
		
	tmp.edges <- tmp.edges %>% left_join(tmp.ref, by = c("from" = "PopID")) %>% rename(from_cat = category)
	tmp.edges <- tmp.edges %>% left_join(tmp.ref, by = c("to" = "PopID")) %>% rename(to_cat = category)

# 	print("check tmp.edges for NAs")
# 	print(table(tmp.edges$from_cat, exclude = NULL))
# 	print(table(tmp.edges$to_cat, exclude = NULL))
# 	print("See any NAs?")

	tmp.edges <- tmp.edges %>% select(from_cat, to_cat) %>%
	  rename(from = from_cat, to = to_cat)
	tmp.weights <- tmp.edges %>%  
	  group_by(from, to) %>%
	  summarise(weight = n()) %>% 
	  ungroup()
	tmp.edges <- tmp.edges %>%
	  left_join(tmp.weights) 
	tmp.edges <- distinct(tmp.edges) #Simplifying individual edges for ease of plotting
	tmp.nodes <- bind_rows(distinct(tmp.edges, from) %>% rename(category = from), 
						 distinct(tmp.edges, to) %>% rename(category = to)) %>% distinct()
	colnames(tmp.nodes) <- sprintf("%s", category)
# 	print("tmp.nodes")
# 	print(tmp.nodes)
# 	print("tmp.edges")
# 	print(tmp.edges)
	
	tmp.net <- tbl_graph(tmp.nodes, tmp.edges, directed = T)
# 	print("Success")
	return(tmp.net)
}

# print(head(nodes))

abmnet <-  abmnet %>% activate(nodes) %>% mutate(DegreeOut = degree(abmnet, mode = "out")/IncludedInRunCount)
nodes <- nodes %>% mutate(DegreeOut = degree(abmnet, mode = "out")/IncludedInRunCount)



se <- function(x) sd(x)/sqrt(length(x))
sumtab <- data.frame(row.names = c("Metric", "Value")) 

#Split these Narratives off and save as separate dataframes for each infection state. Then load all the relevant ones and recombine as needed.
Narr_Param_DF_Pa$Event <- "E"
Narr_Param_DF_Py$Event <- "E"
Narr_Status <- bind_rows(Narr_Param_DF_Pa, 
                         Narr_Param_DF_Py,
                         Narr_Param_DF_Ih)
# Narr_Status <- Narr_Status %>%
#   left_join(select(EndOuts, agentPopID, IncludedInRunCount),
#             by = c("FocalAgentPopID" = "agentPopID"))

Narr_Status <- merge(Narr_Status, pop[, c("PopID", "IncludedInRunCount")], by.x="FocalAgentPopID", by.y="PopID", all.x=TRUE)

Narr_Status <- Narr_Status %>%
  left_join(select(pop, PopID, AgeHHCat, RaceHH, IncomeHHCat),
            by = c("FocalAgentPopID" = "PopID"))


Narr_TimesInStatus <- Narr_Status %>%
  mutate(Day = trunc(Time)) %>%
  select(FocalAgentPopID, Day, Event, IncludedInRunCount, AgeHHCat, RaceHH, IncomeHHCat) %>%
  group_by(FocalAgentPopID, Day, Event, IncludedInRunCount, AgeHHCat, RaceHH, IncomeHHCat) %>%
  summarise(n = n()) %>%
  pivot_wider(names_from = "Event", values_from = "n") %>%
  ungroup() %>%
  rename(E_times = E, 
         Ih_times = Ih) %>%
  mutate(E_eff = E_times/IncludedInRunCount,
         Ih_eff = Ih_times/IncludedInRunCount) %>%
  mutate_all(replace_na, 0)


sumtab <- data.frame(NA)
sumtab$`Percent Exposed` <- round(sum(Narr_TimesInStatus$E_eff, na.rm = TRUE)/numAgents,6)*100
sumtab$`Percent Hospitalized` <- round(sum(Narr_TimesInStatus$Ih_eff, na.rm = TRUE)/numAgents,6)*100
# sumtab$`Percent Dead` <- round(sum(Narr_TimesInStatus$Rd_eff, na.rm = TRUE)/numAgents,6)*100

#Summarising by day
Narr_Day <- Narr_TimesInStatus %>%
  ungroup() %>%
  select(Day, E_eff, Ih_eff) %>%
  group_by(Day) %>%
  summarise_all(sum, na.rm = TRUE) %>%
  mutate_all(round, 0)

Narr_Day$E_eff_7day <- NA
Narr_Day$Ih_eff_7day <- NA
# Narr_Day$Rd_eff_7day <- NA

#Calculate 7 day moving average
for(i in 7:nrow(Narr_Day)){
  Narr_Day$E_eff_7day[i] <- round((Narr_Day$E_eff[i] +
                                     Narr_Day$E_eff[i-1] +
                                     Narr_Day$E_eff[i-2] +
                                     Narr_Day$E_eff[i-3] +
                                     Narr_Day$E_eff[i-4] +
                                     Narr_Day$E_eff[i-5] +
                                     Narr_Day$E_eff[i-6])/7,0)
}

for(i in 7:nrow(Narr_Day)){
  Narr_Day$Ih_eff_7day[i] <- round((Narr_Day$Ih_eff[i] +
                                      Narr_Day$Ih_eff[i-1] +
                                      Narr_Day$Ih_eff[i-2] +
                                      Narr_Day$Ih_eff[i-3] +
                                      Narr_Day$Ih_eff[i-4] +
                                      Narr_Day$Ih_eff[i-5] +
                                      Narr_Day$Ih_eff[i-6])/7,0)
}

for(i in 7:nrow(Narr_Day)){
#   Narr_Day$Rd_eff_7day[i] <- round((Narr_Day$Rd_eff[i] +
#                                       Narr_Day$Rd_eff[i-1] +
#                                       Narr_Day$Rd_eff[i-2] +
#                                       Narr_Day$Rd_eff[i-3] +
#                                       Narr_Day$Rd_eff[i-4] +
#                                       Narr_Day$Rd_eff[i-5] +
#                                       Narr_Day$Rd_eff[i-6])/7,0)
}

Narr_Day <- Narr_Day %>% 
  mutate_at((c("E_eff_7day", "Ih_eff_7day")), replace_na, 0)

sumtab$`Peak Hospitalization Percent` <- round(max(Narr_Day$Ih_eff_7day,0)/numAgents, 6)*100
sumtab$`Day of Peak Hospitalizations` <- as.integer(Narr_Day$Day[which.max(Narr_Day$Ih_eff_7day)])



#Calculate first peak
for(i in 1:length(Narr_Day$Day)) {
  if(Narr_Day$Ih_eff_7day[i] > Narr_Day$Ih_eff_7day[i+1] | Narr_Day$Ih_eff_7day[i] == max(Narr_Day$Ih_eff_7day)){
    sumtab$`Peak Hospitalization Percent (first)` <- round(Narr_Day$Ih_eff_7day[i]/numAgents, 6)*100
    sumtab$`Day of Peak Hospitalizations (first)` <- trunc(Narr_Day$Day[i])
    break
  }
}

sumtab <- sumtab %>%
  t() %>%
  as.data.frame() %>%
  rownames_to_column("Metric") %>%
  rename(Value = V1) %>%
  na.omit()

### Create dataframe for age-wise daily hospitalizations ###

#Summarising by day by age group
Narr_Day_Age <- Narr_TimesInStatus %>%
  select(Day, E_eff, Ih_eff, AgeHHCat) %>%
  group_by(Day, AgeHHCat) %>%
  summarise_all(sum, na.rm = TRUE) %>%
  mutate_at(c("E_eff", "Ih_eff"),round, 0)


#Moving average by age group
Narr_Day_Age$E_eff_7day <- NA
Narr_Day_Age$Ih_eff_7day <- NA
# Narr_Day_Age$Rd_eff_7day <- NA

Narr_Day_Age1 <- as.data.frame(Narr_Day_Age %>% filter(AgeHHCat == "18-49y"))
Narr_Day_Age2 <- as.data.frame(Narr_Day_Age %>% filter(AgeHHCat == "50-64y"))
Narr_Day_Age3 <- as.data.frame(Narr_Day_Age %>% filter(AgeHHCat == "65y+"))

Narr_Day_Age_corrector <- data.frame(Day = seq(1:RunLength), AgeHHCat=NA, E_eff=0, Ih_eff=0, E_eff_7day=NA, Ih_eff_7day=NA)

Narr_Day_Age1 <- rbind(Narr_Day_Age1, Narr_Day_Age_corrector[!(Narr_Day_Age_corrector$Day %in% Narr_Day_Age1$Day), ])
Narr_Day_Age1 <- Narr_Day_Age1[order(Narr_Day_Age1$Day), ]
Narr_Day_Age1$AgeHHCat <- "18-49y"
Narr_Day_Age2 <- rbind(Narr_Day_Age2, Narr_Day_Age_corrector[!(Narr_Day_Age_corrector$Day %in% Narr_Day_Age2$Day), ])
Narr_Day_Age2 <- Narr_Day_Age2[order(Narr_Day_Age2$Day), ]
Narr_Day_Age2$AgeHHCat <- "50-64y"
Narr_Day_Age3 <- rbind(Narr_Day_Age3, Narr_Day_Age_corrector[!(Narr_Day_Age_corrector$Day %in% Narr_Day_Age3$Day), ])
Narr_Day_Age3 <- Narr_Day_Age3[order(Narr_Day_Age3$Day), ]
Narr_Day_Age3$AgeHHCat <- "65y+"


for(i in 7:nrow(Narr_Day_Age1)){
  Narr_Day_Age1$E_eff_7day[i] <- round((Narr_Day_Age1$E_eff[i] +
                                           Narr_Day_Age1$E_eff[i-1] +
                                           Narr_Day_Age1$E_eff[i-2] +
                                           Narr_Day_Age1$E_eff[i-3] +
                                           Narr_Day_Age1$E_eff[i-4] +
                                           Narr_Day_Age1$E_eff[i-5] +
                                           Narr_Day_Age1$E_eff[i-6])/7,0)  
  Narr_Day_Age1$Ih_eff_7day[i] <- round((Narr_Day_Age1$Ih_eff[i] +
                                           Narr_Day_Age1$Ih_eff[i-1] +
                                           Narr_Day_Age1$Ih_eff[i-2] +
                                           Narr_Day_Age1$Ih_eff[i-3] +
                                           Narr_Day_Age1$Ih_eff[i-4] +
                                           Narr_Day_Age1$Ih_eff[i-5] +
                                           Narr_Day_Age1$Ih_eff[i-6])/7,0)
#   Narr_Day_Age1$Rd_eff_7day[i] <- round((Narr_Day_Age1$Rd_eff[i] +
#                                            Narr_Day_Age1$Rd_eff[i-1] +
#                                            Narr_Day_Age1$Rd_eff[i-2] +
#                                            Narr_Day_Age1$Rd_eff[i-3] +
#                                            Narr_Day_Age1$Rd_eff[i-4] +
#                                            Narr_Day_Age1$Rd_eff[i-5] +
#                                            Narr_Day_Age1$Rd_eff[i-6])/7,0)
}

for(i in 7:nrow(Narr_Day_Age2)){
  Narr_Day_Age2$E_eff_7day[i] <- round((Narr_Day_Age2$E_eff[i] +
                                           Narr_Day_Age2$E_eff[i-1] +
                                           Narr_Day_Age2$E_eff[i-2] +
                                           Narr_Day_Age2$E_eff[i-3] +
                                           Narr_Day_Age2$E_eff[i-4] +
                                           Narr_Day_Age2$E_eff[i-5] +
                                           Narr_Day_Age2$E_eff[i-6])/7,0)
  Narr_Day_Age2$Ih_eff_7day[i] <- round((Narr_Day_Age2$Ih_eff[i] +
                                          Narr_Day_Age2$Ih_eff[i-1] +
                                          Narr_Day_Age2$Ih_eff[i-2] +
                                          Narr_Day_Age2$Ih_eff[i-3] +
                                          Narr_Day_Age2$Ih_eff[i-4] +
                                          Narr_Day_Age2$Ih_eff[i-5] +
                                          Narr_Day_Age2$Ih_eff[i-6])/7,0)
#   Narr_Day_Age2$Rd_eff_7day[i] <- round((Narr_Day_Age2$Rd_eff[i] +
#                                           Narr_Day_Age2$Rd_eff[i-1] +
#                                           Narr_Day_Age2$Rd_eff[i-2] +
#                                           Narr_Day_Age2$Rd_eff[i-3] +
#                                           Narr_Day_Age2$Rd_eff[i-4] +
#                                           Narr_Day_Age2$Rd_eff[i-5] +
#                                           Narr_Day_Age2$Rd_eff[i-6])/7,0)
}

for(i in 7:nrow(Narr_Day_Age3)){
  Narr_Day_Age3$E_eff_7day[i] <- round((Narr_Day_Age3$E_eff[i] +
                                           Narr_Day_Age3$E_eff[i-1] +
                                           Narr_Day_Age3$E_eff[i-2] +
                                           Narr_Day_Age3$E_eff[i-3] +
                                           Narr_Day_Age3$E_eff[i-4] +
                                           Narr_Day_Age3$E_eff[i-5] +
                                           Narr_Day_Age3$E_eff[i-6])/7,0)
  Narr_Day_Age3$Ih_eff_7day[i] <- round((Narr_Day_Age3$Ih_eff[i] +
                                           Narr_Day_Age3$Ih_eff[i-1] +
                                           Narr_Day_Age3$Ih_eff[i-2] +
                                           Narr_Day_Age3$Ih_eff[i-3] +
                                           Narr_Day_Age3$Ih_eff[i-4] +
                                           Narr_Day_Age3$Ih_eff[i-5] +
                                           Narr_Day_Age3$Ih_eff[i-6])/7,0)
 #  Narr_Day_Age3$Rd_eff_7day[i] <- round((Narr_Day_Age3$Rd_eff[i] +
#                                            Narr_Day_Age3$Rd_eff[i-1] +
#                                            Narr_Day_Age3$Rd_eff[i-2] +
#                                            Narr_Day_Age3$Rd_eff[i-3] +
#                                            Narr_Day_Age3$Rd_eff[i-4] +
#                                            Narr_Day_Age3$Rd_eff[i-5] +
#                                            Narr_Day_Age3$Rd_eff[i-6])/7,0)
}


Narr_Day_Age <- bind_rows(Narr_Day_Age1, Narr_Day_Age2, Narr_Day_Age3)
Narr_Day_Age <- Narr_Day_Age %>% mutate_at((c("E_eff_7day", "Ih_eff_7day")), replace_na, 0)

### END dataframe for age-wise daily hospitalizations ###


### Create dataframe for income-wise daily hospitalizations ###

#Summarising by day by age group
Narr_Day_Inc <- Narr_TimesInStatus %>%
  select(Day, E_eff, Ih_eff, IncomeHHCat) %>%
  group_by(Day, IncomeHHCat) %>%
  summarise_all(sum, na.rm = TRUE) %>%
  mutate_at(c("E_eff", "Ih_eff"),round, 0)


#Moving average by age group
Narr_Day_Inc$E_eff_7day <- NA
Narr_Day_Inc$Ih_eff_7day <- NA
# Narr_Day_Inc$Rd_eff_7day <- NA



Narr_Day_Inc1 <- as.data.frame(Narr_Day_Inc %>% filter(IncomeHHCat == "Lowest"))
Narr_Day_Inc2 <- as.data.frame(Narr_Day_Inc %>% filter(IncomeHHCat == "Lower-Middle"))
Narr_Day_Inc3 <- as.data.frame(Narr_Day_Inc %>% filter(IncomeHHCat == "Middle"))
Narr_Day_Inc4 <- as.data.frame(Narr_Day_Inc %>% filter(IncomeHHCat == "Upper-Middle"))
Narr_Day_Inc5 <- as.data.frame(Narr_Day_Inc %>% filter(IncomeHHCat == "Higher"))

Narr_Day_Inc_corrector <- data.frame(Day = seq(1:RunLength), IncomeHHCat=NA, E_eff=0, Ih_eff=0, E_eff_7day=NA, Ih_eff_7day=NA)
# print(head(Narr_Day_Inc_corrector))

Narr_Day_Inc1 <- rbind(Narr_Day_Inc1, Narr_Day_Inc_corrector[!(Narr_Day_Inc_corrector$Day %in% Narr_Day_Inc1$Day), ])
Narr_Day_Inc1 <- Narr_Day_Inc1[order(Narr_Day_Inc1$Day), ]
Narr_Day_Inc1$IncomeHHCat <- "Lowest"
Narr_Day_Inc2 <- rbind(Narr_Day_Inc2, Narr_Day_Inc_corrector[!(Narr_Day_Inc_corrector$Day %in% Narr_Day_Inc2$Day), ])
Narr_Day_Inc2 <- Narr_Day_Inc2[order(Narr_Day_Inc2$Day), ]
Narr_Day_Inc2$IncomeHHCat <- "Lower-Middle"
Narr_Day_Inc3 <- rbind(Narr_Day_Inc3, Narr_Day_Inc_corrector[!(Narr_Day_Inc_corrector$Day %in% Narr_Day_Inc3$Day), ])
Narr_Day_Inc3 <- Narr_Day_Inc3[order(Narr_Day_Inc3$Day), ]
Narr_Day_Inc3$IncomeHHCat <- "Middle"
Narr_Day_Inc4 <- rbind(Narr_Day_Inc4, Narr_Day_Inc_corrector[!(Narr_Day_Inc_corrector$Day %in% Narr_Day_Inc4$Day), ])
Narr_Day_Inc4 <- Narr_Day_Inc4[order(Narr_Day_Inc4$Day), ]
Narr_Day_Inc4$IncomeHHCat <- "Upper-Middle"
Narr_Day_Inc5 <- rbind(Narr_Day_Inc5, Narr_Day_Inc_corrector[!(Narr_Day_Inc_corrector$Day %in% Narr_Day_Inc5$Day), ])
Narr_Day_Inc5 <- Narr_Day_Inc5[order(Narr_Day_Inc5$Day), ]
Narr_Day_Inc5$IncomeHHCat <- "Lower-Higher"


for(i in 7:nrow(Narr_Day_Inc1)){
  Narr_Day_Inc1$E_eff_7day[i] <- round((Narr_Day_Inc1$E_eff[i] +
                                          Narr_Day_Inc1$E_eff[i-1] +
                                          Narr_Day_Inc1$E_eff[i-2] +
                                          Narr_Day_Inc1$E_eff[i-3] +
                                          Narr_Day_Inc1$E_eff[i-4] +
                                          Narr_Day_Inc1$E_eff[i-5] +
                                          Narr_Day_Inc1$E_eff[i-6])/7,0)  
  Narr_Day_Inc1$Ih_eff_7day[i] <- round((Narr_Day_Inc1$Ih_eff[i] +
                                           Narr_Day_Inc1$Ih_eff[i-1] +
                                           Narr_Day_Inc1$Ih_eff[i-2] +
                                           Narr_Day_Inc1$Ih_eff[i-3] +
                                           Narr_Day_Inc1$Ih_eff[i-4] +
                                           Narr_Day_Inc1$Ih_eff[i-5] +
                                           Narr_Day_Inc1$Ih_eff[i-6])/7,0)
#   Narr_Day_Inc1$Rd_eff_7day[i] <- round((Narr_Day_Inc1$Rd_eff[i] +
#                                            Narr_Day_Inc1$Rd_eff[i-1] +
#                                            Narr_Day_Inc1$Rd_eff[i-2] +
#                                            Narr_Day_Inc1$Rd_eff[i-3] +
#                                            Narr_Day_Inc1$Rd_eff[i-4] +
#                                            Narr_Day_Inc1$Rd_eff[i-5] +
#                                            Narr_Day_Inc1$Rd_eff[i-6])/7,0)
}


for(i in 7:nrow(Narr_Day_Inc2)){
  Narr_Day_Inc2$E_eff_7day[i] <- round((Narr_Day_Inc2$E_eff[i] +
                                          Narr_Day_Inc2$E_eff[i-1] +
                                          Narr_Day_Inc2$E_eff[i-2] +
                                          Narr_Day_Inc2$E_eff[i-3] +
                                          Narr_Day_Inc2$E_eff[i-4] +
                                          Narr_Day_Inc2$E_eff[i-5] +
                                          Narr_Day_Inc2$E_eff[i-6])/7,0)
  Narr_Day_Inc2$Ih_eff_7day[i] <- round((Narr_Day_Inc2$Ih_eff[i] +
                                           Narr_Day_Inc2$Ih_eff[i-1] +
                                           Narr_Day_Inc2$Ih_eff[i-2] +
                                           Narr_Day_Inc2$Ih_eff[i-3] +
                                           Narr_Day_Inc2$Ih_eff[i-4] +
                                           Narr_Day_Inc2$Ih_eff[i-5] +
                                           Narr_Day_Inc2$Ih_eff[i-6])/7,0)
#   Narr_Day_Inc2$Rd_eff_7day[i] <- round((Narr_Day_Inc2$Rd_eff[i] +
#                                            Narr_Day_Inc2$Rd_eff[i-1] +
#                                            Narr_Day_Inc2$Rd_eff[i-2] +
#                                            Narr_Day_Inc2$Rd_eff[i-3] +
#                                            Narr_Day_Inc2$Rd_eff[i-4] +
#                                            Narr_Day_Inc2$Rd_eff[i-5] +
#                                            Narr_Day_Inc2$Rd_eff[i-6])/7,0)
}


for(i in 7:nrow(Narr_Day_Inc3)){
  Narr_Day_Inc3$E_eff_7day[i] <- round((Narr_Day_Inc3$E_eff[i] +
                                          Narr_Day_Inc3$E_eff[i-1] +
                                          Narr_Day_Inc3$E_eff[i-2] +
                                          Narr_Day_Inc3$E_eff[i-3] +
                                          Narr_Day_Inc3$E_eff[i-4] +
                                          Narr_Day_Inc3$E_eff[i-5] +
                                          Narr_Day_Inc3$E_eff[i-6])/7,0)
  Narr_Day_Inc3$Ih_eff_7day[i] <- round((Narr_Day_Inc3$Ih_eff[i] +
                                           Narr_Day_Inc3$Ih_eff[i-1] +
                                           Narr_Day_Inc3$Ih_eff[i-2] +
                                           Narr_Day_Inc3$Ih_eff[i-3] +
                                           Narr_Day_Inc3$Ih_eff[i-4] +
                                           Narr_Day_Inc3$Ih_eff[i-5] +
                                           Narr_Day_Inc3$Ih_eff[i-6])/7,0)
#   Narr_Day_Inc3$Rd_eff_7day[i] <- round((Narr_Day_Inc3$Rd_eff[i] +
#                                            Narr_Day_Inc3$Rd_eff[i-1] +
#                                            Narr_Day_Inc3$Rd_eff[i-2] +
#                                            Narr_Day_Inc3$Rd_eff[i-3] +
#                                            Narr_Day_Inc3$Rd_eff[i-4] +
#                                            Narr_Day_Inc3$Rd_eff[i-5] +
#                                            Narr_Day_Inc3$Rd_eff[i-6])/7,0)
}

for(i in 7:nrow(Narr_Day_Inc4)){
  Narr_Day_Inc4$E_eff_7day[i] <- round((Narr_Day_Inc4$E_eff[i] +
                                          Narr_Day_Inc4$E_eff[i-1] +
                                          Narr_Day_Inc4$E_eff[i-2] +
                                          Narr_Day_Inc4$E_eff[i-3] +
                                          Narr_Day_Inc4$E_eff[i-4] +
                                          Narr_Day_Inc4$E_eff[i-5] +
                                          Narr_Day_Inc4$E_eff[i-6])/7,0)
  Narr_Day_Inc4$Ih_eff_7day[i] <- round((Narr_Day_Inc4$Ih_eff[i] +
                                           Narr_Day_Inc4$Ih_eff[i-1] +
                                           Narr_Day_Inc4$Ih_eff[i-2] +
                                           Narr_Day_Inc4$Ih_eff[i-3] +
                                           Narr_Day_Inc4$Ih_eff[i-4] +
                                           Narr_Day_Inc4$Ih_eff[i-5] +
                                           Narr_Day_Inc4$Ih_eff[i-6])/7,0)
#   Narr_Day_Inc4$Rd_eff_7day[i] <- round((Narr_Day_Inc4$Rd_eff[i] +
#                                            Narr_Day_Inc4$Rd_eff[i-1] +
#                                            Narr_Day_Inc4$Rd_eff[i-2] +
#                                            Narr_Day_Inc4$Rd_eff[i-3] +
#                                            Narr_Day_Inc4$Rd_eff[i-4] +
#                                            Narr_Day_Inc4$Rd_eff[i-5] +
#                                            Narr_Day_Inc4$Rd_eff[i-6])/7,0)
}

for(i in 7:nrow(Narr_Day_Inc5)){
  Narr_Day_Inc5$E_eff_7day[i] <- round((Narr_Day_Inc5$E_eff[i] +
                                          Narr_Day_Inc5$E_eff[i-1] +
                                          Narr_Day_Inc5$E_eff[i-2] +
                                          Narr_Day_Inc5$E_eff[i-3] +
                                          Narr_Day_Inc5$E_eff[i-4] +
                                          Narr_Day_Inc5$E_eff[i-5] +
                                          Narr_Day_Inc5$E_eff[i-6])/7,0)
  Narr_Day_Inc5$Ih_eff_7day[i] <- round((Narr_Day_Inc5$Ih_eff[i] +
                                           Narr_Day_Inc5$Ih_eff[i-1] +
                                           Narr_Day_Inc5$Ih_eff[i-2] +
                                           Narr_Day_Inc5$Ih_eff[i-3] +
                                           Narr_Day_Inc5$Ih_eff[i-4] +
                                           Narr_Day_Inc5$Ih_eff[i-5] +
                                           Narr_Day_Inc5$Ih_eff[i-6])/7,0)
#   Narr_Day_Inc5$Rd_eff_7day[i] <- round((Narr_Day_Inc5$Rd_eff[i] +
#                                            Narr_Day_Inc5$Rd_eff[i-1] +
#                                            Narr_Day_Inc5$Rd_eff[i-2] +
#                                            Narr_Day_Inc5$Rd_eff[i-3] +
#                                            Narr_Day_Inc5$Rd_eff[i-4] +
#                                            Narr_Day_Inc5$Rd_eff[i-5] +
#                                            Narr_Day_Inc5$Rd_eff[i-6])/7,0)
}


Narr_Day_Inc <- bind_rows(Narr_Day_Inc1, Narr_Day_Inc2, Narr_Day_Inc3, Narr_Day_Inc4, Narr_Day_Inc5)
Narr_Day_Inc <- Narr_Day_Inc %>% mutate_at((c("E_eff_7day", "Ih_eff_7day")), replace_na, 0)



### END dataframe for income-wise daily hospitalizations ###


### Create dataframe for race-wise daily hospitalizations ###

#Summarising by day by age group
Narr_Day_Race <- Narr_TimesInStatus %>%
  select(Day, E_eff, Ih_eff, RaceHH) %>%
  group_by(Day, RaceHH) %>%
  summarise_all(sum, na.rm = TRUE) %>%
  mutate_at(c("E_eff", "Ih_eff"),round, 0)


#Moving average by age group
Narr_Day_Race$E_eff_7day <- NA
Narr_Day_Race$Ih_eff_7day <- NA
# Narr_Day_Race$Rd_eff_7day <- NA

Narr_Day_Race1 <- as.data.frame(Narr_Day_Race %>% filter(RaceHH == "W"))
Narr_Day_Race2 <- as.data.frame(Narr_Day_Race %>% filter(RaceHH == "B"))
Narr_Day_Race3 <- as.data.frame(Narr_Day_Race %>% filter(RaceHH == "A"))
Narr_Day_Race4 <- as.data.frame(Narr_Day_Race %>% filter(RaceHH == "Hi"))
Narr_Day_Race5 <- as.data.frame(Narr_Day_Race %>% filter(RaceHH == "NAm"))
Narr_Day_Race6 <- as.data.frame(Narr_Day_Race %>% filter(RaceHH == "NHaPIs"))
Narr_Day_Race7 <- as.data.frame(Narr_Day_Race %>% filter(RaceHH == "Mu"))
Narr_Day_Race8 <- as.data.frame(Narr_Day_Race %>% filter(RaceHH == "O"))

Narr_Day_Race_corrector <- data.frame(Day = seq(1:RunLength), RaceHH=NA, E_eff=0, Ih_eff=0, E_eff_7day=NA, Ih_eff_7day=NA)
# print(head(Narr_Day_Race_corrector))

Narr_Day_Race1 <- rbind(Narr_Day_Race1, Narr_Day_Race_corrector[!(Narr_Day_Race_corrector$Day %in% Narr_Day_Race1$Day), ])
Narr_Day_Race1 <- Narr_Day_Race1[order(Narr_Day_Race1$Day), ]
Narr_Day_Race1$RaceHH <- "W"
Narr_Day_Race2 <- rbind(Narr_Day_Race2, Narr_Day_Race_corrector[!(Narr_Day_Race_corrector$Day %in% Narr_Day_Race2$Day), ])
Narr_Day_Race2 <- Narr_Day_Race2[order(Narr_Day_Race2$Day), ]
Narr_Day_Race2$RaceHH <- "B"
Narr_Day_Race3 <- rbind(Narr_Day_Race3, Narr_Day_Race_corrector[!(Narr_Day_Race_corrector$Day %in% Narr_Day_Race3$Day), ])
Narr_Day_Race3 <- Narr_Day_Race3[order(Narr_Day_Race3$Day), ]
Narr_Day_Race3$RaceHH <- "A"
Narr_Day_Race4 <- rbind(Narr_Day_Race4, Narr_Day_Race_corrector[!(Narr_Day_Race_corrector$Day %in% Narr_Day_Race4$Day), ])
Narr_Day_Race4 <- Narr_Day_Race4[order(Narr_Day_Race4$Day), ]
Narr_Day_Race4$RaceHH <- "Hi"
Narr_Day_Race5 <- rbind(Narr_Day_Race5, Narr_Day_Race_corrector[!(Narr_Day_Race_corrector$Day %in% Narr_Day_Race5$Day), ])
Narr_Day_Race5 <- Narr_Day_Race5[order(Narr_Day_Race5$Day), ]
Narr_Day_Race5$RaceHH <- "NAm"
Narr_Day_Race6 <- rbind(Narr_Day_Race6, Narr_Day_Race_corrector[!(Narr_Day_Race_corrector$Day %in% Narr_Day_Race6$Day), ])
Narr_Day_Race6 <- Narr_Day_Race6[order(Narr_Day_Race6$Day), ]
Narr_Day_Race6$RaceHH <- "NHaPIs"
Narr_Day_Race7 <- rbind(Narr_Day_Race7, Narr_Day_Race_corrector[!(Narr_Day_Race_corrector$Day %in% Narr_Day_Race7$Day), ])
Narr_Day_Race7 <- Narr_Day_Race7[order(Narr_Day_Race7$Day), ]
Narr_Day_Race7$RaceHH <- "Mu"
Narr_Day_Race8 <- rbind(Narr_Day_Race8, Narr_Day_Race_corrector[!(Narr_Day_Race_corrector$Day %in% Narr_Day_Race8$Day), ])
Narr_Day_Race8 <- Narr_Day_Race8[order(Narr_Day_Race8$Day), ]
Narr_Day_Race8$RaceHH <- "O"

for(i in 7:nrow(Narr_Day_Race1)){
  Narr_Day_Race1$E_eff_7day[i] <- round((Narr_Day_Race1$E_eff[i] +
                                           Narr_Day_Race1$E_eff[i-1] +
                                           Narr_Day_Race1$E_eff[i-2] +
                                           Narr_Day_Race1$E_eff[i-3] +
                                           Narr_Day_Race1$E_eff[i-4] +
                                           Narr_Day_Race1$E_eff[i-5] +
                                           Narr_Day_Race1$E_eff[i-6])/7,0)  
  Narr_Day_Race1$Ih_eff_7day[i] <- round((Narr_Day_Race1$Ih_eff[i] +
                                            Narr_Day_Race1$Ih_eff[i-1] +
                                            Narr_Day_Race1$Ih_eff[i-2] +
                                            Narr_Day_Race1$Ih_eff[i-3] +
                                            Narr_Day_Race1$Ih_eff[i-4] +
                                            Narr_Day_Race1$Ih_eff[i-5] +
                                            Narr_Day_Race1$Ih_eff[i-6])/7,0)
#   Narr_Day_Race1$Rd_eff_7day[i] <- round((Narr_Day_Race1$Rd_eff[i] +
#                                             Narr_Day_Race1$Rd_eff[i-1] +
#                                             Narr_Day_Race1$Rd_eff[i-2] +
#                                             Narr_Day_Race1$Rd_eff[i-3] +
#                                             Narr_Day_Race1$Rd_eff[i-4] +
#                                             Narr_Day_Race1$Rd_eff[i-5] +
#                                             Narr_Day_Race1$Rd_eff[i-6])/7,0)
}

for(i in 7:nrow(Narr_Day_Race2)){
  Narr_Day_Race2$E_eff_7day[i] <- round((Narr_Day_Race2$E_eff[i] +
                                           Narr_Day_Race2$E_eff[i-1] +
                                           Narr_Day_Race2$E_eff[i-2] +
                                           Narr_Day_Race2$E_eff[i-3] +
                                           Narr_Day_Race2$E_eff[i-4] +
                                           Narr_Day_Race2$E_eff[i-5] +
                                           Narr_Day_Race2$E_eff[i-6])/7,0)
  Narr_Day_Race2$Ih_eff_7day[i] <- round((Narr_Day_Race2$Ih_eff[i] +
                                            Narr_Day_Race2$Ih_eff[i-1] +
                                            Narr_Day_Race2$Ih_eff[i-2] +
                                            Narr_Day_Race2$Ih_eff[i-3] +
                                            Narr_Day_Race2$Ih_eff[i-4] +
                                            Narr_Day_Race2$Ih_eff[i-5] +
                                            Narr_Day_Race2$Ih_eff[i-6])/7,0)
#   Narr_Day_Race2$Rd_eff_7day[i] <- round((Narr_Day_Race2$Rd_eff[i] +
#                                             Narr_Day_Race2$Rd_eff[i-1] +
#                                             Narr_Day_Race2$Rd_eff[i-2] +
#                                             Narr_Day_Race2$Rd_eff[i-3] +
#                                             Narr_Day_Race2$Rd_eff[i-4] +
#                                             Narr_Day_Race2$Rd_eff[i-5] +
#                                             Narr_Day_Race2$Rd_eff[i-6])/7,0)
}

for(i in 7:nrow(Narr_Day_Race3)){
  Narr_Day_Race3$E_eff_7day[i] <- round((Narr_Day_Race3$E_eff[i] +
                                           Narr_Day_Race3$E_eff[i-1] +
                                           Narr_Day_Race3$E_eff[i-2] +
                                           Narr_Day_Race3$E_eff[i-3] +
                                           Narr_Day_Race3$E_eff[i-4] +
                                           Narr_Day_Race3$E_eff[i-5] +
                                           Narr_Day_Race3$E_eff[i-6])/7,0)
  Narr_Day_Race3$Ih_eff_7day[i] <- round((Narr_Day_Race3$Ih_eff[i] +
                                            Narr_Day_Race3$Ih_eff[i-1] +
                                            Narr_Day_Race3$Ih_eff[i-2] +
                                            Narr_Day_Race3$Ih_eff[i-3] +
                                            Narr_Day_Race3$Ih_eff[i-4] +
                                            Narr_Day_Race3$Ih_eff[i-5] +
                                            Narr_Day_Race3$Ih_eff[i-6])/7,0)
#   Narr_Day_Race3$Rd_eff_7day[i] <- round((Narr_Day_Race3$Rd_eff[i] +
#                                             Narr_Day_Race3$Rd_eff[i-1] +
#                                             Narr_Day_Race3$Rd_eff[i-2] +
#                                             Narr_Day_Race3$Rd_eff[i-3] +
#                                             Narr_Day_Race3$Rd_eff[i-4] +
#                                             Narr_Day_Race3$Rd_eff[i-5] +
#                                             Narr_Day_Race3$Rd_eff[i-6])/7,0)
}

for(i in 7:nrow(Narr_Day_Race4)){
  Narr_Day_Race4$E_eff_7day[i] <- round((Narr_Day_Race4$E_eff[i] +
                                           Narr_Day_Race4$E_eff[i-1] +
                                           Narr_Day_Race4$E_eff[i-2] +
                                           Narr_Day_Race4$E_eff[i-3] +
                                           Narr_Day_Race4$E_eff[i-4] +
                                           Narr_Day_Race4$E_eff[i-5] +
                                           Narr_Day_Race4$E_eff[i-6])/7,0)
  Narr_Day_Race4$Ih_eff_7day[i] <- round((Narr_Day_Race4$Ih_eff[i] +
                                            Narr_Day_Race4$Ih_eff[i-1] +
                                            Narr_Day_Race4$Ih_eff[i-2] +
                                            Narr_Day_Race4$Ih_eff[i-3] +
                                            Narr_Day_Race4$Ih_eff[i-4] +
                                            Narr_Day_Race4$Ih_eff[i-5] +
                                            Narr_Day_Race4$Ih_eff[i-6])/7,0)
#   Narr_Day_Race4$Rd_eff_7day[i] <- round((Narr_Day_Race4$Rd_eff[i] +
#                                             Narr_Day_Race4$Rd_eff[i-1] +
#                                             Narr_Day_Race4$Rd_eff[i-2] +
#                                             Narr_Day_Race4$Rd_eff[i-3] +
#                                             Narr_Day_Race4$Rd_eff[i-4] +
#                                             Narr_Day_Race4$Rd_eff[i-5] +
#                                             Narr_Day_Race4$Rd_eff[i-6])/7,0)
}

for(i in 7:nrow(Narr_Day_Race5)){
  Narr_Day_Race5$E_eff_7day[i] <- round((Narr_Day_Race5$E_eff[i] +
                                           Narr_Day_Race5$E_eff[i-1] +
                                           Narr_Day_Race5$E_eff[i-2] +
                                           Narr_Day_Race5$E_eff[i-3] +
                                           Narr_Day_Race5$E_eff[i-4] +
                                           Narr_Day_Race5$E_eff[i-5] +
                                           Narr_Day_Race5$E_eff[i-6])/7,0)
  Narr_Day_Race5$Ih_eff_7day[i] <- round((Narr_Day_Race5$Ih_eff[i] +
                                            Narr_Day_Race5$Ih_eff[i-1] +
                                            Narr_Day_Race5$Ih_eff[i-2] +
                                            Narr_Day_Race5$Ih_eff[i-3] +
                                            Narr_Day_Race5$Ih_eff[i-4] +
                                            Narr_Day_Race5$Ih_eff[i-5] +
                                            Narr_Day_Race5$Ih_eff[i-6])/7,0)
#   Narr_Day_Race5$Rd_eff_7day[i] <- round((Narr_Day_Race5$Rd_eff[i] +
#                                             Narr_Day_Race5$Rd_eff[i-1] +
#                                             Narr_Day_Race5$Rd_eff[i-2] +
#                                             Narr_Day_Race5$Rd_eff[i-3] +
#                                             Narr_Day_Race5$Rd_eff[i-4] +
#                                             Narr_Day_Race5$Rd_eff[i-5] +
#                                             Narr_Day_Race5$Rd_eff[i-6])/7,0)
}

for(i in 7:nrow(Narr_Day_Race6)){
  Narr_Day_Race6$E_eff_7day[i] <- round((Narr_Day_Race6$E_eff[i] +
                                           Narr_Day_Race6$E_eff[i-1] +
                                           Narr_Day_Race6$E_eff[i-2] +
                                           Narr_Day_Race6$E_eff[i-3] +
                                           Narr_Day_Race6$E_eff[i-4] +
                                           Narr_Day_Race6$E_eff[i-5] +
                                           Narr_Day_Race6$E_eff[i-6])/7,0)
  Narr_Day_Race6$Ih_eff_7day[i] <- round((Narr_Day_Race6$Ih_eff[i] +
                                            Narr_Day_Race6$Ih_eff[i-1] +
                                            Narr_Day_Race6$Ih_eff[i-2] +
                                            Narr_Day_Race6$Ih_eff[i-3] +
                                            Narr_Day_Race6$Ih_eff[i-4] +
                                            Narr_Day_Race6$Ih_eff[i-5] +
                                            Narr_Day_Race6$Ih_eff[i-6])/7,0)
#   Narr_Day_Race6$Rd_eff_7day[i] <- round((Narr_Day_Race6$Rd_eff[i] +
#                                             Narr_Day_Race6$Rd_eff[i-1] +
#                                             Narr_Day_Race6$Rd_eff[i-2] +
#                                             Narr_Day_Race6$Rd_eff[i-3] +
#                                             Narr_Day_Race6$Rd_eff[i-4] +
#                                             Narr_Day_Race6$Rd_eff[i-5] +
#                                             Narr_Day_Race6$Rd_eff[i-6])/7,0)
}

for(i in 7:nrow(Narr_Day_Race7)){
  Narr_Day_Race7$E_eff_7day[i] <- round((Narr_Day_Race7$E_eff[i] +
                                           Narr_Day_Race7$E_eff[i-1] +
                                           Narr_Day_Race7$E_eff[i-2] +
                                           Narr_Day_Race7$E_eff[i-3] +
                                           Narr_Day_Race7$E_eff[i-4] +
                                           Narr_Day_Race7$E_eff[i-5] +
                                           Narr_Day_Race7$E_eff[i-6])/7,0)
  Narr_Day_Race7$Ih_eff_7day[i] <- round((Narr_Day_Race7$Ih_eff[i] +
                                            Narr_Day_Race7$Ih_eff[i-1] +
                                            Narr_Day_Race7$Ih_eff[i-2] +
                                            Narr_Day_Race7$Ih_eff[i-3] +
                                            Narr_Day_Race7$Ih_eff[i-4] +
                                            Narr_Day_Race7$Ih_eff[i-5] +
                                            Narr_Day_Race7$Ih_eff[i-6])/7,0)
#   Narr_Day_Race7$Rd_eff_7day[i] <- round((Narr_Day_Race7$Rd_eff[i] +
#                                             Narr_Day_Race7$Rd_eff[i-1] +
#                                             Narr_Day_Race7$Rd_eff[i-2] +
#                                             Narr_Day_Race7$Rd_eff[i-3] +
#                                             Narr_Day_Race7$Rd_eff[i-4] +
#                                             Narr_Day_Race7$Rd_eff[i-5] +
#                                             Narr_Day_Race7$Rd_eff[i-6])/7,0)
}

for(i in 7:nrow(Narr_Day_Race8)){
  Narr_Day_Race8$E_eff_7day[i] <- round((Narr_Day_Race8$E_eff[i] +
                                           Narr_Day_Race8$E_eff[i-1] +
                                           Narr_Day_Race8$E_eff[i-2] +
                                           Narr_Day_Race8$E_eff[i-3] +
                                           Narr_Day_Race8$E_eff[i-4] +
                                           Narr_Day_Race8$E_eff[i-5] +
                                           Narr_Day_Race8$E_eff[i-6])/7,0)
  Narr_Day_Race8$Ih_eff_7day[i] <- round((Narr_Day_Race8$Ih_eff[i] +
                                            Narr_Day_Race8$Ih_eff[i-1] +
                                            Narr_Day_Race8$Ih_eff[i-2] +
                                            Narr_Day_Race8$Ih_eff[i-3] +
                                            Narr_Day_Race8$Ih_eff[i-4] +
                                            Narr_Day_Race8$Ih_eff[i-5] +
                                            Narr_Day_Race8$Ih_eff[i-6])/7,0)
#   Narr_Day_Race8$Rd_eff_7day[i] <- round((Narr_Day_Race8$Rd_eff[i] +
#                                             Narr_Day_Race8$Rd_eff[i-1] +
#                                             Narr_Day_Race8$Rd_eff[i-2] +
#                                             Narr_Day_Race8$Rd_eff[i-3] +
#                                             Narr_Day_Race8$Rd_eff[i-4] +
#                                             Narr_Day_Race8$Rd_eff[i-5] +
#                                             Narr_Day_Race8$Rd_eff[i-6])/7,0)
}

Narr_Day_Race <- bind_rows(Narr_Day_Race1, Narr_Day_Race2, Narr_Day_Race3, Narr_Day_Race4, Narr_Day_Race5, Narr_Day_Race6, Narr_Day_Race7, Narr_Day_Race8)
Narr_Day_Race <- Narr_Day_Race %>% mutate_at((c("E_eff_7day", "Ih_eff_7day")), replace_na, 0)

### END dataframe for race-wise daily hospitalizations ###


#Age-wise impact summary for hospitalization
Narr_Age_Ih <- Narr_TimesInStatus %>%
  select(Ih_eff, AgeHHCat) %>%
  group_by(AgeHHCat) %>%
  summarise(Hospitalized = round(sum(Ih_eff, na.rm = TRUE),0)) %>%
  left_join(
    Narr_TimesInStatus %>% 
      select(FocalAgentPopID, AgeHHCat) %>%
      distinct() %>%
      group_by(AgeHHCat) %>%
      summarize(Population = n()),
    by = "AgeHHCat"
  ) %>%
  select(AgeHHCat, Population, Hospitalized)

Narr_Age_Ih$Population_percent <- round(100*Narr_Age_Ih$Population/sum(Narr_Age_Ih$Population), 2)
Narr_Age_Ih$Hospitalized_percent <- round(100*Narr_Age_Ih$Hospitalized/sum(Narr_Age_Ih$Hospitalized), 2)
Narr_Age_Ih$Hospitalized_disprop <- round(100*((Narr_Age_Ih$Hospitalized_percent - Narr_Age_Ih$Population_percent)/Narr_Age_Ih$Population_percent),2)

#Age-wise impact summary for Exposures
Narr_Age_E <- Narr_TimesInStatus %>%
  select(E_eff, AgeHHCat) %>%
  group_by(AgeHHCat) %>%
  summarise(Exposed = round(sum(E_eff, na.rm = TRUE),0)) %>%
  left_join(
    Narr_TimesInStatus %>% 
      select(FocalAgentPopID, AgeHHCat) %>%
      distinct() %>%
      group_by(AgeHHCat) %>%
      summarize(Population = n()),
    by = "AgeHHCat"
  ) %>%
  select(AgeHHCat, Population, Exposed)

Narr_Age_E$Population_percent <- round(100*Narr_Age_E$Population/sum(Narr_Age_E$Population), 2)
Narr_Age_E$Exposed_percent <- round(100*Narr_Age_E$Exposed/sum(Narr_Age_E$Exposed), 2)
Narr_Age_E$Exposed_disprop <- round(100*((Narr_Age_E$Exposed_percent - Narr_Age_E$Population_percent)/Narr_Age_E$Population_percent),2)

#Combined table for disproportional impact by age
Narr_Age <- bind_cols(
  Narr_Age_E %>% select(AgeHHCat, Population_percent, Exposed_percent, Exposed_disprop),
  Narr_Age_Ih %>% select(Hospitalized_percent, Hospitalized_disprop)
)




#Race-wise impact summary for hospitalization
Narr_Race_Ih <- Narr_TimesInStatus %>%
  select(Ih_eff, RaceHH) %>%
  group_by(RaceHH) %>%
  summarise(Hospitalized = round(sum(Ih_eff, na.rm = TRUE),0)) %>%
  left_join(
    Narr_TimesInStatus %>% 
      select(FocalAgentPopID, RaceHH) %>%
      distinct() %>%
      group_by(RaceHH) %>%
      summarize(Population = n()),
    by = "RaceHH"
  ) %>%
  select(RaceHH, Population, Hospitalized)

Narr_Race_Ih$Population_percent <- round(100*Narr_Race_Ih$Population/sum(Narr_Race_Ih$Population), 2)
Narr_Race_Ih$Hospitalized_percent <- round(100*Narr_Race_Ih$Hospitalized/sum(Narr_Race_Ih$Hospitalized), 2)
Narr_Race_Ih$Hospitalized_disprop <- round(100*((Narr_Race_Ih$Hospitalized_percent - Narr_Race_Ih$Population_percent)/Narr_Race_Ih$Population_percent),2)

#Race-wise impact summary for Exposures
Narr_Race_E <- Narr_TimesInStatus %>%
  select(E_eff, RaceHH) %>%
  group_by(RaceHH) %>%
  summarise(Exposed = round(sum(E_eff, na.rm = TRUE),0)) %>%
  left_join(
    Narr_TimesInStatus %>% 
      select(FocalAgentPopID, RaceHH) %>%
      distinct() %>%
      group_by(RaceHH) %>%
      summarize(Population = n()),
    by = "RaceHH"
  ) %>%
  select(RaceHH, Population, Exposed)

Narr_Race_E$Population_percent <- round(100*Narr_Race_E$Population/sum(Narr_Race_E$Population), 2)
Narr_Race_E$Exposed_percent <- round(100*Narr_Race_E$Exposed/sum(Narr_Race_E$Exposed), 2)
Narr_Race_E$Exposed_disprop <- round(100*((Narr_Race_E$Exposed_percent - Narr_Race_E$Population_percent)/Narr_Race_E$Population_percent),2)

#Combined table for disproportional impact by race
Narr_Race <- bind_cols(
  Narr_Race_E %>% select(RaceHH, Population_percent, Exposed_percent, Exposed_disprop),
  Narr_Race_Ih %>% select(Hospitalized_percent, Hospitalized_disprop)
)



#Income-wise impact summary for hospitalization
Narr_Income_Ih <- Narr_TimesInStatus %>%
  select(Ih_eff, IncomeHHCat) %>%
  group_by(IncomeHHCat) %>%
  summarise(Hospitalized = round(sum(Ih_eff, na.rm = TRUE),0)) %>%
  left_join(
    Narr_TimesInStatus %>% 
      select(FocalAgentPopID, IncomeHHCat) %>%
      distinct() %>%
      group_by(IncomeHHCat) %>%
      summarize(Population = n()),
    by = "IncomeHHCat"
  ) %>%
  select(IncomeHHCat, Population, Hospitalized)

Narr_Income_Ih$Population_percent <- round(100*Narr_Income_Ih$Population/sum(Narr_Income_Ih$Population), 2)
Narr_Income_Ih$Hospitalized_percent <- round(100*Narr_Income_Ih$Hospitalized/sum(Narr_Income_Ih$Hospitalized), 2)
Narr_Income_Ih$Hospitalized_disprop <- round(100*((Narr_Income_Ih$Hospitalized_percent - Narr_Income_Ih$Population_percent)/Narr_Income_Ih$Population_percent),2)

#Income-wise impact summary for Exposures
Narr_Income_E <- Narr_TimesInStatus %>%
  select(E_eff, IncomeHHCat) %>%
  group_by(IncomeHHCat) %>%
  summarise(Exposed = round(sum(E_eff, na.rm = TRUE),0)) %>%
  left_join(
    Narr_TimesInStatus %>% 
      select(FocalAgentPopID, IncomeHHCat) %>%
      distinct() %>%
      group_by(IncomeHHCat) %>%
      summarize(Population = n()),
    by = "IncomeHHCat"
  ) %>%
  select(IncomeHHCat, Population, Exposed)

Narr_Income_E$Population_percent <- round(100*Narr_Income_E$Population/sum(Narr_Income_E$Population), 2)
Narr_Income_E$Exposed_percent <- round(100*Narr_Income_E$Exposed/sum(Narr_Income_E$Exposed), 2)
Narr_Income_E$Exposed_disprop <- round(100*((Narr_Income_E$Exposed_percent - Narr_Income_E$Population_percent)/Narr_Income_E$Population_percent),2)

#Combined table for disproportional impact by Income
Narr_Income <- bind_cols(
  Narr_Income_E %>% select(IncomeHHCat, Population_percent, Exposed_percent, Exposed_disprop),
  Narr_Income_Ih %>% select(Hospitalized_percent, Hospitalized_disprop)
)



# Create PDF

pdf(paste0("analytics/package/",ModelNumber, "_Single_report.pdf"), width=8.5, height=11)
plot.new()
par(lheight=.5, mar=c(10,0,4,4))
mtext("Single Model Report", side=3, cex=2, font=2)


print("[Summary]        Cumulative exposures and hospitalizations")

grid.table(sumtab, rows = NULL, theme=ttheme_minimal(base_size = 8))

mtext("Proportion of population who are exposed, hospitalized and dead. Table also shows\n
the first and subsequent peak in the proportion of population hospitalized, and the number\n
of days after which the peaks occured.", side=1, adj=0, padj=1)

frame()

grid.table(Narr_Age, rows = NULL, theme=ttheme_minimal(base_size = 8))

mtext("Table shows the proportion of population who are disproportionately exposed and\n
hospitalized in each age category, calculated with reference to the proportion that each\n
category make up in the total population.", side=1, adj=0, padj=1)

frame()

grid.table(Narr_Race, rows = NULL, theme=ttheme_minimal(base_size = 8))

mtext("Table shows the proportion of population who are disproportionately exposed and\n
hospitalized in each race category, calculated with reference to the proportion that each\n
category make up in the total population.", side=1, adj=0, padj=1)

frame()

grid.table(Narr_Income, rows = NULL, theme=ttheme_minimal(base_size = 8))

mtext("Table shows the proportion of population who are disproportionately exposed and\n
hospitalized in each income category, calculated with reference to the proportion that\n
each category make up in the total population.", side=1, adj=0, padj=1)

Narr_Day$E_eff <- Narr_Day$E_eff / numAgents
Narr_Day$E_eff_7day <- Narr_Day$E_eff_7day / numAgents

Narr_Day$Ih_eff <- Narr_Day$Ih_eff / numAgents
Narr_Day$Ih_eff_7day <- Narr_Day$Ih_eff_7day / numAgents

# Narr_Day$Rd_eff <- Narr_Day$Rd_eff / numAgents
# Narr_Day$Rd_eff_7day <- Narr_Day$Rd_eff_7day / numAgents

Narr_Day_Age$E_eff <- Narr_Day_Age$E_eff / numAgents
Narr_Day_Age$E_eff_7day <- Narr_Day_Age$E_eff_7day / numAgents

Narr_Day_Age$Ih_eff <- Narr_Day_Age$Ih_eff / numAgents
Narr_Day_Age$Ih_eff_7day <- Narr_Day_Age$Ih_eff_7day / numAgents

# Narr_Day_Age$Rd_eff <- Narr_Day_Age$Rd_eff / numAgents
# Narr_Day_Age$Rd_eff_7day <- Narr_Day_Age$Rd_eff_7day / numAgents

Narr_Day_Inc$E_eff <- Narr_Day_Inc$E_eff / numAgents
Narr_Day_Inc$E_eff_7day <- Narr_Day_Inc$E_eff_7day / numAgents

Narr_Day_Inc$Ih_eff <- Narr_Day_Inc$Ih_eff / numAgents
Narr_Day_Inc$Ih_eff_7day <- Narr_Day_Inc$Ih_eff_7day / numAgents

# Narr_Day_Inc$Rd_eff <- Narr_Day_Inc$Rd_eff / numAgents
# Narr_Day_Inc$Rd_eff_7day <- Narr_Day_Inc$Rd_eff_7day / numAgents

Narr_Day_Race$E_eff <- Narr_Day_Race$E_eff / numAgents
Narr_Day_Race$E_eff_7day <- Narr_Day_Race$E_eff_7day / numAgents

Narr_Day_Race$Ih_eff <- Narr_Day_Race$Ih_eff / numAgents
Narr_Day_Race$Ih_eff_7day <- Narr_Day_Race$Ih_eff_7day / numAgents

# Narr_Day_Race$Rd_eff <- Narr_Day_Race$Rd_eff / numAgents
# Narr_Day_Race$Rd_eff_7day <- Narr_Day_Race$Rd_eff_7day / numAgents


ggplot(Narr_Day) + 
  geom_line(aes(x = Day, y = E_eff), alpha = 0.3) +
  geom_line(aes(x = Day, y = E_eff_7day), size = 2) +
  labs(title = sprintf("Percent Daily Exposures\nModel: %s", ModelNumber)) +
  scale_x_continuous(breaks = seq(0,120,10)) +
  ylab("Exposure") +
  theme_bw() + 
  theme(aspect.ratio=1)

ggplot(Narr_Day) + 
  geom_line(aes(x = Day, y = Ih_eff), alpha = 0.3) +
  geom_line(aes(x = Day, y = Ih_eff_7day), size = 2) +
  labs(title = sprintf("Percent Daily Hospitalizations\nModel: %s", ModelNumber)) +
  scale_x_continuous(breaks = seq(0,120,10)) +
  ylab("Hospitalization") +
  theme_bw() + 
  theme(aspect.ratio=1)
  
# ggplot(Narr_Day) + 
#     geom_line(aes(x = Day, y = Rd_eff), alpha = 0.3) +
#     geom_line(aes(x = Day, y = Rd_eff_7day), size = 2) +
#     labs(title = sprintf("Percent Daily Deaths\nModel: %s", ModelNumber)) +
#   scale_x_continuous(breaks = seq(0,120,10)) +
#     ylab("Death") +
#   theme_bw()

# Age-wise daily plots

ggplot(Narr_Day_Age) + 
  geom_line(aes(x = Day, y = E_eff, color = AgeHHCat), alpha = 0.3) +
  geom_line(aes(x = Day, y = E_eff_7day, color = AgeHHCat), size = 2) +
  labs(title = sprintf("Percent Daily Exposures by Age\nModel: %s", ModelNumber)) +
#   scale_y_continuous(limits = c(0,20000), breaks = seq(0,20000,1000)) +
  scale_color_discrete(name = "Age") +
  scale_x_continuous(breaks = seq(0,120,10)) +
  ylab("Exposure") +
  theme_bw() + 
  theme(aspect.ratio=1)

ggplot(Narr_Day_Age) + 
  geom_line(aes(x = Day, y = Ih_eff, color = AgeHHCat), alpha = 0.3) +
  geom_line(aes(x = Day, y = Ih_eff_7day, color = AgeHHCat), size = 2) +
  labs(title = sprintf("Percent Daily Hospitalizations by Age\nModel: %s", ModelNumber)) +
  ylab("Hospitalization") +
#   scale_y_continuous(limits = c(0,1000), breaks = seq(0,1000,100)) +
  scale_color_discrete(name = "Age") +
  scale_x_continuous(breaks = seq(0,120,10)) +
  theme_bw() + 
  theme(aspect.ratio=1)

Narr_Day_Age <- Narr_Day_Age %>%
  left_join(select(Narr_Age_Ih, AgeHHCat, Population), by = "AgeHHCat")

ggplot(Narr_Day_Age) + 
  geom_line(aes(x = Day, y = Ih_eff/Population, color = AgeHHCat), alpha = 0.3) +
  geom_line(aes(x = Day, y = Ih_eff_7day/Population, color = AgeHHCat), size = 2) +
  labs(title = sprintf("Percent Daily Hospitalizations by Age per Population\nModel: %s", ModelNumber)) +
  ylab("Hospitalization/Population") +
  #scale_y_continuous(limits = c(0,1000), breaks = seq(0,1000,100)) +
  scale_color_discrete(name = "Age") +
  scale_x_continuous(breaks = seq(0,120,10)) +
  theme_bw() + 
  theme(aspect.ratio=1)

# Narr_Day_Age2 <- Narr_Day_Age %>%
#   group_by(AgeHHCat) %>%
#   mutate(Ih_eff_7day_DailyTotal = sum(Ih_eff_7day)) %>%
#   ungroup() %>%
#   left_join(select(Narr_Age, Population_percent, AgeHHCat), by = "AgeHHCat")

tmpDaily_Ih <- as.data.frame(aggregate(data = Narr_Day_Age, Ih_eff_7day~Day, FUN = sum))
colnames(tmpDaily_Ih) <- c("Day","Ih_eff_7day_sum")
Narr_Day_Age2 <- merge(Narr_Day_Age, tmpDaily_Ih, by="Day", all.x=TRUE)
Narr_Day_Age2$Ih_eff_7day_prop <- 100 * Narr_Day_Age2$Ih_eff_7day / Narr_Day_Age2$Ih_eff_7day_sum
Narr_Day_Age2 <- merge(Narr_Day_Age2, Narr_Age[, c("AgeHHCat", "Population_percent")], by="AgeHHCat", all.x=TRUE)


# Narr_Day_Age_df_2 <- as.data.frame(Narr_Day_Age2)
# Narr_Day_Age2 <- Narr_Day_Age2[order(Narr_Day_Age2$AgeHHCat, Narr_Day_Age2$Day), ]
# Narr_Day_Age2$Ih_eff_7day_prop[is.nan(Narr_Day_Age2$Ih_eff_7day_prop)] <- NA
Narr_Day_Age2$Ih_eff_7day_prop[is.infinite(Narr_Day_Age2$Ih_eff_7day_prop)] <- NA


# head(Narr_Day_Age2, n = 20)

ggplot(Narr_Day_Age2) + 
  #geom_line(aes(x = Day, y = Ih_eff/Population, color = AgeHHCat), alpha = 0.3) +
  geom_line(aes(x = Day, y = Ih_eff_7day_prop, color = AgeHHCat), size = 2) +
  geom_line(aes(x = Day, y = Population_percent, color = AgeHHCat), alpha = 1, linetype = "dashed") +
  labs(title = sprintf("Proportion of daily hospitalizations by Age\nModel: %s", ModelNumber)) +
  ylab("Proportion of daily hospitalizations") +
  scale_y_continuous(limits = c(0,100)) +
  scale_color_discrete(name = "Age") +
    scale_x_continuous(breaks = seq(0,120,10)) +
  theme_bw() + 
  theme(aspect.ratio=1, plot.caption = element_text(hjust = 0.5)) + 
  labs(caption = "Figure shows the proportion of population in each category who face disproportionately\n
higher or lower daily rate of hospitalization. The dotted line indicates the base\n
proportion of each category in the total population. A disproportionately high rate of\n
hospitalization is indicated by the solid line being above the dotted line, and vice versa.")


# mtext("\n\nFigure shows the proportion of population in each category who face disproportionately\n
# higher or lower daily rate of hospitalization. The dotted line indicates the base\n
# proportion of each category in the total population. A disproportionately high rate of\n
# hospitalization is indicated by the solid line being above the dotted line, and vice versa.", side=1, adj=0, padj=1)


# ggplot(Narr_Day_Age) + 
#   geom_line(aes(x = Day, y = Rd_eff, color = AgeHHCat), alpha = 0.3) +
#   geom_line(aes(x = Day, y = Rd_eff_7day, color = AgeHHCat), size = 2) +
#   labs(title = sprintf("Percent Daily Deaths by Age\nModel: %s", ModelNumber)) +
#   ylab("Death") +
# #   scale_y_continuous(limits = c(0,100), breaks = seq(0,100,10)) +
#   scale_color_discrete(name = "Age") +
#   scale_x_continuous(breaks = seq(0,120,10)) +
#   theme_bw()


# Income-wise daily plots

ggplot(Narr_Day_Inc) + 
  geom_line(aes(x = Day, y = E_eff, color = IncomeHHCat), alpha = 0.3) +
  geom_line(aes(x = Day, y = E_eff_7day, color = IncomeHHCat), size = 2) +
  labs(title = sprintf("Percent Daily Exposures by Income\nModel: %s", ModelNumber)) +
  ylab("Exposure") +
#   scale_y_continuous(limits = c(0,20000), breaks = seq(0,20000,1000)) +
  scale_color_discrete(name = "Income") +
  scale_x_continuous(breaks = seq(0,120,10)) +
  theme_bw() + 
  theme(aspect.ratio=1)

ggplot(Narr_Day_Inc) + 
  geom_line(aes(x = Day, y = Ih_eff, color = IncomeHHCat), alpha = 0.3) +
  geom_line(aes(x = Day, y = Ih_eff_7day, color = IncomeHHCat), size = 2) +
  labs(title = sprintf("Percent Daily Hospitalizations by Income\nModel: %s", ModelNumber)) +
  ylab("Hospitalization") +
#   scale_y_continuous(limits = c(0,1000), breaks = seq(0,1000,100)) +
  scale_color_discrete(name = "Income") +
  scale_x_continuous(breaks = seq(0,120,10)) +
  theme_bw() + 
  theme(aspect.ratio=1)

Narr_Day_Inc <- Narr_Day_Inc %>%
  left_join(select(Narr_Income_Ih, IncomeHHCat, Population), by = "IncomeHHCat")

ggplot(Narr_Day_Inc) + 
  geom_line(aes(x = Day, y = Ih_eff/Population, color = IncomeHHCat), alpha = 0.3) +
  geom_line(aes(x = Day, y = Ih_eff_7day/Population, color = IncomeHHCat), size = 2) +
  labs(title = sprintf("Percent Daily Hospitalizations by Income per Population\nModel: %s", ModelNumber)) +
  ylab("Hospitalization/Population") +
  #scale_y_continuous(limits = c(0,1000), breaks = seq(0,1000,100)) +
  scale_color_discrete(name = "Income") +
  scale_x_continuous(breaks = seq(0,120,10)) +
  theme_bw() + 
  theme(aspect.ratio=1)

# Narr_Day_Inc2 <- Narr_Day_Inc %>%
#   group_by(IncomeHHCat) %>%
#   mutate(Ih_eff_7day_DailyTotal = sum(Ih_eff_7day)) %>%
#   ungroup() %>%
#   left_join(select(Narr_Income, Population_percent, IncomeHHCat), by = "IncomeHHCat")


Narr_Day_Inc2 <- merge(Narr_Day_Inc, tmpDaily_Ih, by="Day", all.x=TRUE)
Narr_Day_Inc2$Ih_eff_7day_prop <- 100 * Narr_Day_Inc2$Ih_eff_7day / Narr_Day_Inc2$Ih_eff_7day_sum
Narr_Day_Inc2 <- merge(Narr_Day_Inc2, Narr_Income[, c("IncomeHHCat", "Population_percent")], by="IncomeHHCat", all.x=TRUE)

# Narr_Day_Inc2 <- Narr_Day_Inc2[order(Narr_Day_Inc2$IncomeHHCat, Narr_Day_Inc2$Day), ]
# Narr_Day_Inc2$Ih_eff_7day_prop[is.nan(Narr_Day_Inc2$Ih_eff_7day_prop)] <- NA

# Narr_Day_Inc2$Ih_eff_7day_prop[c(1:3)] <- c(110,103,102)

Narr_Day_Inc2$Ih_eff_7day_prop[is.infinite(Narr_Day_Inc2$Ih_eff_7day_prop)] <- NA

# head(Narr_Day_Inc2[Narr_Day_Inc2$IncomeHHCat == "Middle",], n = 20)

ggplot(Narr_Day_Inc2) + 
  #geom_line(aes(x = Day, y = Ih_eff/Population, color = AgeHHCat), alpha = 0.3) +
  geom_line(aes(x = Day, y = Ih_eff_7day_prop, color = IncomeHHCat), size = 2) +
  geom_line(aes(x = Day, y = Population_percent, color = IncomeHHCat), alpha = 1, linetype = "dashed") +
labs(title = sprintf("Proportion of daily hospitalizations by Income\nModel: %s", ModelNumber)) +
  ylab("Proportion of daily hospitalizations") +
  scale_y_continuous(limits = c(0,100)) +
  scale_color_discrete(name = "Income") +
  scale_x_continuous(breaks = seq(0,120,10)) +
  theme_bw() + 
  theme(aspect.ratio=1, plot.caption = element_text(hjust = 0.5)) + 
  labs(caption = "Figure shows the proportion of population in each category who face disproportionately\n
higher or lower daily rate of hospitalization. The dotted line indicates the base\n
proportion of each category in the total population. A disproportionately high rate of\n
hospitalization is indicated by the solid line being above the dotted line, and vice versa.")
# , side=1, adj=0, padj=1)

# ggplot(Narr_Day_Inc) + 
#   geom_line(aes(x = Day, y = Rd_eff, color = IncomeHHCat), alpha = 0.3) +
#   geom_line(aes(x = Day, y = Rd_eff_7day, color = IncomeHHCat), size = 2) +
#   labs(title = sprintf("Percent Daily Deaths by Income\nModel: %s", ModelNumber)) +
#   ylab("Death") +
# #   scale_y_continuous(limits = c(0,100), breaks = seq(0,100,10)) +
#   scale_color_discrete(name = "Income") +
#   scale_x_continuous(breaks = seq(0,120,10)) +
#   theme_bw()


# Race-wise daily plots

ggplot(Narr_Day_Race) + 
  geom_line(aes(x = Day, y = E_eff, color = RaceHH), alpha = 0.3) +
  geom_line(aes(x = Day, y = E_eff_7day, color = RaceHH), size = 2) +
  labs(title = sprintf("Percent Daily Exposures by Race\nModel: %s", ModelNumber)) +
  ylab("Exposure") +
#   scale_y_continuous(limits = c(0,20000), breaks = seq(0,20000,1000)) +
  scale_color_discrete(name = "Race") +
  scale_x_continuous(breaks = seq(0,120,10)) +
  theme_bw() + 
  theme(aspect.ratio=1)

ggplot(Narr_Day_Race) + 
  geom_line(aes(x = Day, y = Ih_eff, color = RaceHH), alpha = 0.3) +
  geom_line(aes(x = Day, y = Ih_eff_7day, color = RaceHH), size = 2) +
  labs(title = sprintf("Percent Daily Hospitalizations by Race\nModel: %s", ModelNumber)) +
  ylab("Hospitalization") +
#   scale_y_continuous(limits = c(0,1000), breaks = seq(0,1000,100)) +
  scale_color_discrete(name = "Race") +
  scale_x_continuous(breaks = seq(0,120,10)) +
  theme_bw() + 
  theme(aspect.ratio=1)

Narr_Day_Race <- Narr_Day_Race %>%
  left_join(select(Narr_Race_Ih, RaceHH, Population))

ggplot(Narr_Day_Race) + 
  geom_line(aes(x = Day, y = Ih_eff/Population, color = RaceHH), alpha = 0.3) +
  geom_line(aes(x = Day, y = Ih_eff_7day/Population, color = RaceHH), size = 2) +
  labs(title = sprintf("Percent Daily Hospitalizations by Race per Population\nModel: %s", ModelNumber)) +
  ylab("Hospitalization/Population") +
  #scale_y_continuous(limits = c(0,1000), breaks = seq(0,1000,100)) +
  scale_color_discrete(name = "Race") +
  scale_x_continuous(breaks = seq(0,120,10)) +
  theme_bw() + 
  theme(aspect.ratio=1)

# Narr_Day_Race2 <- Narr_Day_Race %>%
#   group_by(RaceHH) %>%
#   mutate(Ih_eff_7day_DailyTotal = sum(Ih_eff_7day)) %>%
#   ungroup() %>%
#   left_join(select(Narr_Race, Population_percent, RaceHH), by = "RaceHH")

Narr_Day_Race2 <- merge(Narr_Day_Race, tmpDaily_Ih, by="Day", all.x=TRUE)
Narr_Day_Race2$Ih_eff_7day_prop <- 100 * Narr_Day_Race2$Ih_eff_7day / Narr_Day_Race2$Ih_eff_7day_sum
Narr_Day_Race2 <- merge(Narr_Day_Race2, Narr_Race[, c("RaceHH", "Population_percent")], by="RaceHH", all.x=TRUE)

Narr_Day_Race2$Ih_eff_7day_prop[is.infinite(Narr_Day_Race2$Ih_eff_7day_prop)] <- NA


ggplot(Narr_Day_Race2) + 
  #geom_line(aes(x = Day, y = Ih_eff/Population, color = AgeHHCat), alpha = 0.3) +
  geom_line(aes(x = Day, y = Ih_eff_7day_prop, color = RaceHH), size = 2) +
  geom_line(aes(x = Day, y = Population_percent, color = RaceHH), alpha = 1, linetype = "dashed") +
labs(title = sprintf("Proportion of daily hospitalizations by Race\nModel: %s", ModelNumber)) +
  ylab("Proportion of daily hospitalizations") +
  scale_y_continuous(limits = c(0,100)) +
  scale_color_discrete(name = "Race") +
  scale_x_continuous(breaks = seq(0,120,10)) +
  theme_bw() + 
  theme(aspect.ratio=1, plot.caption = element_text(hjust = 0.5)) + 
  labs(caption = "Figure shows the proportion of population in each category who face disproportionately\n
higher or lower daily rate of hospitalization. The dotted line indicates the base\n
proportion of each category in the total population. A disproportionately high rate of\n
hospitalization is indicated by the solid line being above the dotted line, and vice versa.")
# , side=1, adj=0, padj=1)

# ggplot(Narr_Day_Race) + 
#   geom_line(aes(x = Day, y = Rd_eff, color = RaceHH), alpha = 0.3) +
#   geom_line(aes(x = Day, y = Rd_eff_7day, color = RaceHH), size = 2) +
#   labs(title = sprintf("Percent Daily Deaths by Race\nModel: %s", ModelNumber)) +
#   ylab("Death") +
# #   scale_y_continuous(limits = c(0,100), breaks = seq(0,100,10)) +
#   scale_color_discrete(name = "Race") +
#   scale_x_continuous(breaks = seq(0,120,10)) +
#   theme_bw()

print("[Network]     creating activity plots")

# print(head(nodes))

p.act.2 <- ggplot(arrange(nodes, DegreeOut), aes(x = FloutPct, y =EsntlActPct, color = DegreeOut,size = DegreeOut, shape = EsntlWrkTendency)) +
  geom_point(position = "jitter") +
  geom_hline(yintercept = 0.5, color = "grey40") +
  geom_vline(xintercept = 0.5, color = "grey40") +
  scale_color_viridis_c(direction = -1, guide = "legend") +
  scale_size_continuous(range = c(0.05,3), guide = "legend") +
  scale_x_continuous(name = "Percentage of times willing to flout", limits = c(0,1), breaks = c(0,0.25,0.5,0.75,1)) +
  scale_y_continuous(name = "Percentage of times engaged in essential activities", limits = c(0,1), breaks = c(0,0.25,0.5,0.75,1)) +
  labs(title = sprintf("Agent activity type and Degree Out - Variation by Occupation\nModel: %s", ModelNumber)) +
  theme_bw() +
  facet_wrap(~OccupationHH) +
  theme(strip.text = element_text(size = 6), aspect.ratio=1, plot.caption = element_text(hjust = 0.5)) + 
  labs(caption = "Each dot in this figure represents an exposed agent, plotted against the percentage\n
of times they are engaged in essential activities and the percentage of times they are\n
willing to engage in flouting behavior. For each respective exposed agent, the shape of\n
the dot indicates whether in the course of the simulation overall they were more likely to\n
be engaged as essential workers as defined by the Shelter in Place policy, and the darker\n
color of the dots indicate a higher number of agents that they in turn exposed in the\n
course of the simulation.")


p.act.2
#ggsave(p.act.2, file = sprintf("%sActivityPlot_DegreeOut_%s_Occupation.png", graphicsDir, ModelNumber), height = 8, width = 10)

# mtext("Each dot in this figure represents an exposed agent, plotted against the percentage\n
# of times they are engaged in essential activities and the percentage of times they are\n
# willing to engage in flouting behavior. For each respective exposed agent, the shape of\n
# the dot indicates whether in the course of the simulation overall they were more likely to\n
# be engaged as essential workers as defined by the Shelter in Place policy, and the darker\n
# color of the dots indicate a higher number of agents that they in turn exposed in the\n
# course of the simulation.", side=1, adj=0, padj=1)

print("[Network]     creating race contact graph")

RaceNet <- genNet("RaceHH")

p.cont.1 <- ggraph(RaceNet) +
  geom_edge_fan(aes(label = weight), alpha = 0.3, edge_width = 0.2, strength = 0.5, angle_calc = 'along',
                 color = "grey40", label_size = 2, label_pos = 0.8,
                arrow = arrow(ends = "last", angle = 5, length = unit(0.1, "inches"), type = "closed")) +
  geom_edge_loop(aes(label = weight, strength = 0.5), alpha = 0.3,
                 color = "grey40", edge_width = 0.2, label_size = 2,
                 arrow = arrow(ends = "last", angle = 10, length = unit(0.1, "inches"), type = "closed")) +
  geom_node_text(aes(label = RaceHH), size = 3, color = "darkred") +
  labs(title = sprintf("Contact Graph of Exposures: By Race\nModel: %s", ModelNumber)) +
  theme_graph(base_family = 'Helvetica') + 
  theme(aspect.ratio=1, plot.caption = element_text(hjust = 0.5)) + 
  labs(caption = "This figure shows the aggregate number of exposures between agents of same and different\n
race categories. Group exposures have been broken down into one-to-one exposures between\n
the exposing agent(s) and the exposed agent(s).")
p.cont.1
#ggsave(p.cont.1, file = sprintf("%sContactGraph_%s_Race.png", graphicsDir, ModelNumber), height = 6, width = 6)

# mtext("\n\nThis figure shows the aggregate number of exposures between agents of same and different\n
# race categories. Group exposures have been broken down into one-to-one exposures between\n
# the exposing agent(s) and the exposed agent(s).", side=1, adj=0, padj=1)

print("[Network]     creating occupation contact graph")

# Contact graph: Occupation
OccNet <- genNet("OccupationHH")

p.cont.2 <- ggraph(OccNet) +
  geom_edge_fan(alpha = 0.2, edge_width = 0.1, strength = 0.5, angle_calc = 'along',
                color = "grey80") +
  geom_edge_fan(aes(filter = weight>quantile(weight,0.9), label = weight), alpha = 0.3, edge_width = 0.2, strength = 0.5, angle_calc = 'along',
                color = "grey40", label_size = 2, label_pos = 0.8,
                arrow = arrow(ends = "last", angle = 5, length = unit(0.1, "inches"), type = "closed")) +
  geom_edge_loop(aes(filter = weight>quantile(weight,0.9), label = weight, strength = 0.5), alpha = 0.3,
                 color = "grey40", edge_width = 0.2, label_size = 2,
                 arrow = arrow(ends = "last", angle = 10, length = unit(0.1, "inches"), type = "closed")) +
  geom_node_text(aes(label = OccupationHH), size = 2, color = "darkred") +
  labs(title = sprintf("Contact Graph of Exposures: By Occupation\nModel: %s", ModelNumber)) +
  theme_graph(base_family = 'Helvetica') + 
  theme(aspect.ratio=1, plot.caption = element_text(hjust = 0.5)) + 
  labs(caption = "This figure shows the aggregate number of exposures between agents of same and different\n
occupation categories. Group exposures have been broken down into one-to-one exposures\n
between the exposing agent(s) and the exposed agent(s). Numbers are displayed only for\n
more prominent linkages.")

p.cont.2
#ggsave(p.cont.2, file = sprintf("%sContactGraph_%s_Occupation.png", graphicsDir, ModelNumber), height = 8, width = 8)

# mtext("\n\nThis figure shows the aggregate number of exposures between agents of same and different\n
# occupation categories. Group exposures have been broken down into one-to-one exposures\n
# between the exposing agent(s) and the exposed agent(s). Numbers are displayed only for\n
# more prominent linkages.", side=1, adj=0, padj=1)

print("[Network]     creating age contact graph")

# Contact graph: Age

AgeNet <- genNet("AgeHHCat")

p.cont.3 <- ggraph(AgeNet) +
  geom_edge_fan(aes(label = weight), alpha = 0.3, edge_width = 0.2, strength = 0.5, angle_calc = 'along',
                color = "grey40", label_size = 2, label_pos = 0.8,
                arrow = arrow(ends = "last", angle = 5, length = unit(0.1, "inches"), type = "closed")) +
  geom_edge_loop(aes(label = weight, strength = 0.5), alpha = 0.3,
                 color = "grey40", edge_width = 0.2, label_size = 2,
                 arrow = arrow(ends = "last", angle = 10, length = unit(0.1, "inches"), type = "closed")) +
  geom_node_text(aes(label = AgeHHCat), size = 4, color = "darkred") +
  labs(title = sprintf("Contact Graph of Exposures: By Age\nModel: %s", ModelNumber)) +
  theme_graph(base_family = 'Helvetica') + 
  theme(aspect.ratio=1, plot.caption = element_text(hjust = 0.5)) + 
  labs(caption = "This figure shows the aggregate number of exposures between agents of same and different\n
age brackets. Group exposures have been broken down into one-to-one exposures between the\n
exposing agent(s) and the exposed agent(s).")
p.cont.3
#ggsave(p.cont.3, file = sprintf("%sContactGraph_%s_Age.png", graphicsDir, ModelNumber), height = 6, width = 6)

# mtext("\n\nThis figure shows the aggregate number of exposures between agents of same and different\n
# age brackets. Group exposures have been broken down into one-to-one exposures between the\n
# exposing agent(s) and the exposed agent(s).", side=1, adj=0, padj=1)

print("[Network]     creating income contact graph")

# Contact graph: Income

IncomeNet <- genNet("IncomeHHCat")

p.cont.4 <- ggraph(IncomeNet) +
  geom_edge_fan(aes(label = weight), alpha = 0.3, edge_width = 0.2, strength = 0.5, angle_calc = 'along',
                color = "grey40", label_size = 2, label_pos = 0.8,
                arrow = arrow(ends = "last", angle = 5, length = unit(0.1, "inches"), type = "closed")) +
  geom_edge_loop(aes(label = weight, strength = 0.5), alpha = 0.3,
                 color = "grey40", edge_width = 0.2, label_size = 2,
                 arrow = arrow(ends = "last", angle = 10, length = unit(0.1, "inches"), type = "closed")) +
  geom_node_text(aes(label = IncomeHHCat), size = 3, color = "darkred") +
  labs(title = sprintf("Contact Graph of Exposures: By Income\nModel: %s", ModelNumber)) +
  theme_graph(base_family = 'Helvetica') + 
  theme(aspect.ratio=1, plot.caption = element_text(hjust = 0.5)) + 
  labs(caption = "This figure shows the aggregate number of exposures between agents of same and different\n
income categories. Group exposures have been brokwn down into one-to-one exposures\n
between the exposing agent(s) and the exposed agent(s).")

p.cont.4
#ggsave(p.cont.4, file = sprintf("%sContactGraph_%s_Income.png", graphicsDir, ModelNumber), height = 6, width = 6)

# mtext("\n\nThis figure shows the aggregate number of exposures between agents of same and different\n
# income categories. Group exposures have been brokwn down into one-to-one exposures\n
# between the exposing agent(s) and the exposed agent(s).", side=1, adj=0, padj=1)

print("[Network]     creating exposure plots")

### Exposure events by occupation and job
edges$from <- as.character(edges$from)
nodes$agentPopID <- as.character(nodes$agentPopID)
jobexp <- right_join(select(edges, from, Time, Event), 
                     select(nodes, agentPopID, OccupationHH), 
                     by = c("from" = "agentPopID"))

p.exp.2 <- ggplot(edges) +
  geom_density(aes(Time, y = ..count.., fill = FocalAgentStatus), position = "stack", color = NA) +
labs(title = sprintf("Exposure density: \nBy infection status of scheduling agent\nModel: %s", ModelNumber)) +
  ylab("Number of exposures") +
  theme_bw() + 
 theme(aspect.ratio=1, plot.caption = element_text(hjust = 0.5)) + 
  labs(caption = "This figure shows daily aggregate infection status of the agent who scheduled the\n
interactions which resulted in exposures. The exposing agent can be anyone in the group\n
interaction organized by the scheduling agent. This figure highlights the reality that\n
often, the person who initiates a group get together may not be intected, but these get-\n
togethers none-the-less result in exposures because of other infectious people in the group.")
  
  #Recovered individuals need to pay attention to events they schedule - these events can be a substantial source of new infections

p.exp.2
#ggsave(p.exp.2, file = sprintf("%sExposures_%s_InfStatus.png", graphicsDir, ModelNumber), height = 6, width = 8)

# mtext("This figure shows daily aggregate infection status of the agent who scheduled the\n
# interactions which resulted in exposures. The exposing agent can be anyone in the group\n
# interaction organized by the scheduling agent. This figure highlights the reality that\n
# often, the person who initiates a group get together may not be intected, but these get-\n
# togethers none-the-less result in exposures because of other infectious people in the group.", side=1, adj=0, padj=1)

p.exp.3 <- ggplot(filter(jobexp)) +
  geom_density(aes(Time, y = ..count.., fill = Event), position = "stack", color = NA) +
  facet_wrap(~OccupationHH) +
  labs(title = sprintf("Exposures: \nBy occupation of exposing agent\nModel: %s", ModelNumber)) +
  ylab("Number of exposures") +
  theme_bw() +
  theme(strip.text = element_text(size = 6), aspect.ratio=1, plot.caption = element_text(hjust = 0.5)) + 
  labs(caption = "This figure breaks down the daily exposures by the occupation status of the agents as\n
well as the type of activity that resulted in the exposure.")

p.exp.3
#ggsave(p.exp.3, file = sprintf("%sExposures_%s_Occupation.png", graphicsDir, ModelNumber), height = 8, width = 10)

# mtext("This figure breaks down the daily exposures by the occupation status of the agents as\n
# well as the type of activity that resulted in the exposure.", side=1, adj=0, padj=1)

print("[Network]     creating density plot")

p.den.14 <- ggplot(nodes, aes(DegreeOut)) + 
  geom_density(aes(color = FloutEsntlWrk), alpha = 0.8, adjust = 3, size = 1) +
  scale_color_brewer(palette = "Spectral") +
  geom_hline(yintercept = 0, size = 1, color = "grey50") +
  geom_vline(xintercept = 0, size = 1, color = "grey50") +
  labs(title = sprintf("Exposures by Flout/Essential Worker Tendency", ModelNumber), 
       x = "Number of Exposures by each Agent", y = "Density") +
  theme_minimal() + 
  theme(aspect.ratio=1)

p.den.14
#ggsave(p.den.14, file = sprintf("%sDensityPlot_Flout_Esntl_%s.png", graphicsDir, ModelNumber), height = 6, width = 8)

print("[Network]     End of network analytics")

NarrConn = dbConnect(RSQLite::SQLite(), sprintf("processedOuts/CovidABM_Narratives_%s.db", ModelNumber))
Events_Realized_Pa <- dbGetQuery(NarrConn, "SELECT FocalAgent AS agentIndex, uniqueRunID, FocalAgentPopID, Event, Time FROM Narratives WHERE Event = 'Pa'")
Events_Realized_Py <- dbGetQuery(NarrConn, "SELECT FocalAgent AS agentIndex, uniqueRunID, FocalAgentPopID, Event, Time FROM Narratives WHERE Event = 'Py'")
# IhTime_Realized_Ih <- dbGetQuery(NarrConn, "SELECT FocalAgent AS agentIndex, uniqueRunID, FocalAgentPopID, Event, Time FROM Narratives WHERE Event = 'Ih'")
# RrTime_Realized_Rd <- dbGetQuery(NarrConn, "SELECT FocalAgent AS agentIndex, uniqueRunID, FocalAgentPopID, Event, Time FROM Narratives WHERE Event = 'Rd'")
dbDisconnect(NarrConn)

Progressions_list <- readRDS(file=sprintf("processedOuts/CovidABM7_ProgressionsData_%s.Rds", ModelNumber))

# print(str(Events_Realized_Pa))
# print(str(Events_Realized_Py))
Events_Realized <- rbind(Events_Realized_Pa, Events_Realized_Py)

# print(str(Events_Realized))

# print("checkPoint 1")

Progressions <- do.call(rbind, Progressions_list)
# print(str(Progressions))
# print("checkPoint 2")

Events_RealSched <- merge(Events_Realized, Progressions, by=c("agentIndex", "uniqueRunID"))
# print(head(Events_RealSched))
# print(str(Events_RealSched))

Events_RealSched$Event_Exposed <- 1
Events_RealSched$Time_Exposed <- NA
Events_RealSched$Time_Exposed[Events_RealSched$E2_Pa_or_Py == "Pa"] = Events_RealSched$Time[Events_RealSched$E2_Pa_or_Py == "Pa"] - Events_RealSched$E_EndTime[Events_RealSched$E2_Pa_or_Py == "Pa"]
Events_RealSched$Time_Exposed[Events_RealSched$E2_Pa_or_Py == "Py"] = Events_RealSched$Time[Events_RealSched$E2_Pa_or_Py == "Py"] - Events_RealSched$E_EndTime[Events_RealSched$E2_Pa_or_Py == "Py"]

Events_RealSched$Event_Hospital <- 0
Events_RealSched$Event_Hospital[Events_RealSched$E2_Py2_Ih == "Ih"] <- 1
Events_RealSched$Time_Hospital <- NA
Events_RealSched$Time_Hospital[Events_RealSched$E2_Py2_Ih == "Ih"] = Events_RealSched$Time[Events_RealSched$E2_Py2_Ih == "Ih"] + Events_RealSched$Py_EndTime[Events_RealSched$E2_Py2_Ih == "Ih"] + Events_RealSched$Iy_Ih_EndTime[Events_RealSched$E2_Py2_Ih == "Ih"]

# Events_RealSched$Event_Dead <- 0
# Events_RealSched$Event_Dead[Events_RealSched$E2_Py2_Ih2_Rd == "Rd"] <- 1
# Events_RealSched$Time_Dead <- NA
# Events_RealSched$Time_Dead[Events_RealSched$E2_Py2_Ih2_Rd == "Rd"] = Events_RealSched$Time[Events_RealSched$E2_Py2_Ih2_Rd == "Rd"] + Events_RealSched$Py_EndTime[Events_RealSched$E2_Py2_Ih2_Rd == "Rd"] + Events_RealSched$Iy_Ih_EndTime[Events_RealSched$E2_Py2_Ih2_Rd == "Rd"] + Events_RealSched$Ih_Rd_EndTime[Events_RealSched$E2_Py2_Ih2_Rd == "Rd"]

Events_RealSched$Day_Exposed <- trunc(Events_RealSched$Time_Exposed)
Events_RealSched$Day_Hospital <- trunc(Events_RealSched$Time_Hospital)
# Events_RealSched$Day_Dead <- trunc(Events_RealSched$Time_Dead)

# print(head(Events_RealSched))
# print(tail(Events_RealSched))
# print(nrow(Events_RealSched))
# print("checkPoint 3")


Events_RealSched_agg <- as.data.frame(aggregate(data=Events_RealSched, Event_Exposed ~ Day_Exposed+uniqueRunID, FUN=sum))
colnames(Events_RealSched_agg) <- c("Day", "uniqueRunID", "TotalE")
Events_RealSched_agg$UniqueRunDay <- paste(Events_RealSched_agg$uniqueRunID, Events_RealSched_agg$Day)

Events_RealSched_agg_Ih <- as.data.frame(aggregate(data=Events_RealSched, Event_Hospital ~ Day_Hospital+uniqueRunID, FUN=sum))
colnames(Events_RealSched_agg_Ih) <- c("Day", "uniqueRunID", "TotalIh")
Events_RealSched_agg_Ih$UniqueRunDay <- paste(Events_RealSched_agg_Ih$uniqueRunID, Events_RealSched_agg_Ih$Day)

Events_RealSched_agg_corrector <- data.frame(Day = rep(seq(1:max(Events_RealSched_agg$Day, Events_RealSched_agg_Ih$Day)), times=length(unique(Events_RealSched_agg_Ih$uniqueRunID))), 
	uniqueRunID = rep(unique(Events_RealSched_agg_Ih$uniqueRunID), each=max(Events_RealSched_agg$Day, Events_RealSched_agg_Ih$Day)), 
	TotalIh=0, 
	TotalE=0)

Events_RealSched_agg_corrector$UniqueRunDay <- paste(Events_RealSched_agg_corrector$uniqueRunID, Events_RealSched_agg_corrector$Day)


Events_RealSched_agg <- rbind(Events_RealSched_agg, Events_RealSched_agg_corrector[!(Events_RealSched_agg_corrector$UniqueRunDay %in% Events_RealSched_agg$UniqueRunDay), c("Day", "uniqueRunID", "TotalE", "UniqueRunDay")])
Events_RealSched_agg <- Events_RealSched_agg[order(Events_RealSched_agg$Day, Events_RealSched_agg$uniqueRunID), ]

Events_RealSched_agg$UniqueRunDay <- NULL


Events_RealSched_agg_Ih <- rbind(Events_RealSched_agg_Ih, Events_RealSched_agg_corrector[!(Events_RealSched_agg_corrector$UniqueRunDay %in% Events_RealSched_agg_Ih$UniqueRunDay), c("Day", "uniqueRunID", "TotalIh", "UniqueRunDay")])
Events_RealSched_agg_Ih <- Events_RealSched_agg_Ih[order(Events_RealSched_agg_Ih$Day, Events_RealSched_agg_Ih$uniqueRunID), ]

Events_RealSched_agg_Ih$UniqueRunDay <- NULL


# Events_RealSched_agg_Rd <- as.data.frame(aggregate(data=Events_RealSched, Event_Dead ~ Day_Dead+uniqueRunID, FUN=sum))
# colnames(Events_RealSched_agg_Rd) <- c("Day", "uniqueRunID", "TotalRd")

Events_RealSched_agg <- merge(Events_RealSched_agg, Events_RealSched_agg_Ih, by=c("Day", "uniqueRunID"), all.x=TRUE, all.y=TRUE)
# Events_RealSched_agg <- merge(Events_RealSched_agg, Events_RealSched_agg_Rd, by=c("Day", "uniqueRunID"), all.x=TRUE, all.y=TRUE)

# Events_RealSched_agg$TotalE[is.na(Events_RealSched_agg$TotalE), ] = 0


Events_RealSched_agg$TotalE <- Events_RealSched_agg$TotalE / numAgents
Events_RealSched_agg$TotalIh <- Events_RealSched_agg$TotalIh / numAgents
# Events_RealSched_agg$TotalRd <- Events_RealSched_agg$TotalRd / numAgents


# print(head(Events_RealSched_agg))
# print(tail(Events_RealSched_agg))
# print(nrow(Events_RealSched_agg))
# print("checkPoint 4")

print(str(Events_RealSched_agg))

Events_RealSched_agg_melt <- melt(Events_RealSched_agg, id.vars = c("uniqueRunID","Day"))

# print(head(Events_RealSched_agg_melt))
# print(tail(Events_RealSched_agg_melt))
# print(nrow(Events_RealSched_agg_melt))
# print("checkPoint 5")

#---------------#
# Make figures
#---------------#



ExposureTimePlot <- ggplot(data=Events_RealSched_agg_melt[Events_RealSched_agg_melt$variable == "TotalE" & Events_RealSched_agg_melt$Day <= RunLength, ], aes(x=Day, y=value)) +
	geom_line(aes(color=uniqueRunID), alpha=0.5, show.legend = FALSE) + 
	scale_y_continuous(name="Days") +
	scale_y_continuous(name="New Daily Exposures") +
	geom_vline(xintercept = RunLength, color = "black") + 
	ggtitle(sprintf("Model: %s", ModelNumber)) + 
	theme_bw() + 
  theme(aspect.ratio=1)

ExposureTimePlot
#ggsave(sprintf("ExposureTimePlot_%s.png", ModelNumber), ExposureTimePlot, path = "analytics/package/")	


HospitalTimePlot <- ggplot(data=Events_RealSched_agg_melt[Events_RealSched_agg_melt$variable == "TotalIh", ], aes(x=Day, y=value, color=uniqueRunID)) +
	geom_line(aes(color=uniqueRunID), alpha=0.5, show.legend = FALSE) + 
	scale_y_continuous(name="Days") +
	scale_y_continuous(name="New Daily Hospitalizations") +
	geom_vline(xintercept = RunLength, color = "black") + 
	ggtitle(sprintf("Model: %s", ModelNumber)) + 
	theme_bw() + 
  theme(aspect.ratio=1)

HospitalTimePlot
#ggsave(sprintf("HospitalTimePlot_%s.png", ModelNumber), HospitalTimePlot, path = "analytics/package/")	

# DeathTimePlot <- ggplot(data=Events_RealSched_agg_melt[Events_RealSched_agg_melt$variable == "TotalRd", ], aes(x=Day, y=value, color=uniqueRunID)) +
# 	geom_line(aes(color=uniqueRunID), alpha=0.5, show.legend = FALSE) + 
# #	stat_smooth() +
# # 	guides(alpha=FALSE) + 
# #     facet_grid(. ~ race) +
# 	scale_x_continuous(name="Days") +
# 	scale_y_continuous(name="New Daily Deaths") +
# 	geom_vline(xintercept = RunLength, color = "black") + 
# 	ggtitle(sprintf("Model: %s", ModelNumber)) + 
# 	theme_bw()
# 
# DeathTimePlot
#ggsave(sprintf("DeathTimePlot_%s.png", ModelNumber), DeathTimePlot, path = "analytics/package/")	


dev.off()

warnings()
q()
