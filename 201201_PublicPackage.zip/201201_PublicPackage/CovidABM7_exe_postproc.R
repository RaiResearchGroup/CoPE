# CoPE – COVID-19 Policy Evaluation tool
#
# An agent-based model of the social spread of COVID-19 with a focus on 
# individual-level behavioral responses to policy. 
# 
# Thank you for your interest in CoPE. 
# If your use of CoPE results in a publication, please cite as follows: 
# 
# Rai Group. (2020). CoPE: COVID-19 Policy Evaluation tool
# 	 Version 0.1. [Computer Software].
#
# This project is under active development. If you find something that needs our 
# attention, please send a message to BAMEx.devs@gmail.com. 
# Your feedback and input is extremely valuable. Thank you!
#
# 
# CovidABM7 
# UT Austin, RaiGroup
# Created: 06/12/2020
#
# 
# all 48 narrative outs takes 1:10

# options(keep.source=TRUE)
options(width=80)
# options(show.error.locations=TRUE)
# options(error = function() {
#   sink(stderr())
#   on.exit(sink(NULL))
#   traceback(5, max.lines = 2L)
#   if (!interactive()) {
#     q(status = 1)
#   }
# })

args = commandArgs(TRUE)

#---------------#
# Run Parameters ---- change to run for the model you want to process
#---------------#
# agentCSVpath = "inputs/ATXAgents.csv"
# EmpDays = 12
ModelNumber <- 7204
# CompareDescription <- c("Regular")
# CompareModelType <- c("Regular")
outDir = ("outputs")
runlogDir = ("runlogs")
ProcOutDir = ("processedOuts")
PreProcDir = ("processedOuts/preProcs/")
cores = 1
agentStates_vec = c("E", "Pa", "Py", "Ia", "Ih", "Iy", "Rd", "Rr", "S")
NetworksCalcParticipate <- "on"



if (!is.na(args[1])) {
  print("Additional CMD line args present")
  if (args[1] == "PostProcInSeries") {
    ModelNumber <<- args[2]
    print(sprintf(
      "[PostProc]     Post Processing Model Number: %s",
      ModelNumber
    ))
  }
}

library(ggplot2)
library(lubridate)
library(reshape2)
library(scales)
library(tidyverse)
library(dplyr)
library(ggraph)
library(tidygraph)
library(igraph)
library(gridExtra)
library(parallel)
library(data.table)
library(R6)
library(DBI)
library(fastmatch)
library(profvis)

print("[Anls]          ... Libraries Loaded")

library(profvis)

dataStore <- R6Class("dataStore", public=list(
	writer = function(field){
		print(field)
		print(sprintf("Writing out %s", field))
		saveRDS(self[[field]], file = sprintf("%s/CovidABM7_%s_%s.Rds", ProcOutDir, field, ModelNumber), compress=FALSE)
		invisible(self)
	}
))


PostProcStore <- R6Class("setupDataClass", inherit = dataStore, public = list(
	job = NULL, 
	ParamsData = NULL, 
	ProgressionsData = NULL, 
	NarrativeData = NULL, 
	NetworkData = NULL, 
	ExposerData = NULL
))

PostProcs <- PostProcStore$new()

#---------------#
# Get models ParamLogs
#---------------#

print("[Anls]          Reading Model Parameter Logs")
print(sprintf( "[Anls]          ParamLogs:%s", ModelNumber))
print("[Anls]          Finding Model Parameter Logs files")


Out_pattern = sprintf("CovidABM7_ParamLog_%s_job", ModelNumber)
Outfiles = unlist(lapply(Out_pattern, function(x) {list.files(path = runlogDir, pattern = x)}))
# print(Out_pattern)
# print(Outfiles)
PostProcs$job <- seq(1,length(Outfiles))

PostProcs$ParamsData <- mclapply(PostProcs$job, function (j) {
	print(sprintf("[Anls]          Reading Model Parameter Log File:%s", Outfiles[j]))
    fname <- sprintf("%s/%s", runlogDir, Outfiles[j])
#	print(fname)
    tmpParamLog <- read.csv(file = fname)
    tmpParamLog$JobID <- j
    tmpParamLog$uniqueRunID <- paste(tmpParamLog$Model, tmpParamLog$JobID, tmpParamLog$subModelID, sep = "-")
	return(tmpParamLog)
}, mc.cores = cores)

PostProcs$writer("ParamsData")


# ---------------#
# Get Pop
# ---------------#
pop <-
  read.csv(
    file = sprintf(
      "inputs/%s%02d_%03d_%s.csv",
      PostProcs$ParamsData[[1]]$AgentPopulationStub,
      as.numeric(PostProcs$ParamsData[[1]]$state),
      as.numeric(PostProcs$ParamsData[[1]]$county),
      if (PostProcs$ParamsData[[1]]$UsePreviousAgentPopulation == TRUE) {
      	PostProcs$ParamsData[[1]]$loadAgentModel
      } else {
      	 ModelNumber
      }
    )
  )

pop$agentIndex <- NULL

# head(pop)

numAgents = nrow(pop)
agentPopID_vec <- seq(1, numAgents)
runDays_vec = seq(PostProcs$ParamsData[[1]]$StartDay, PostProcs$ParamsData[[1]]$EndDay)

# rm(pop)

# 
# ---------------#
# Get compare models AllProgs
# ---------------#

print(sprintf("[Anls]          Models:%s",ModelNumber ))

print("[Anls]          Finding Model AllProg Output files")

Out_pattern = sprintf("CovidABM7_AllProgressions_%s_job", ModelNumber)
Outfiles = unlist(lapply(Out_pattern, function(x) {list.files(path = outDir, pattern = x)}))
# print(Out_pattern)
# print(Outfiles)


PostProcs$ProgressionsData <- mclapply(PostProcs$job, function (j) {
	print(sprintf("[Anls]          Reading Model Progressions File:%s", Outfiles[j]))
    fname <- sprintf("%s/%s", outDir, Outfiles[j])
	load(file = fname)
    progressions$JobID <- j
    progressions$uniqueRunID <- paste(progressions$Model, progressions$JobID, progressions$subModelID, sep = "-")
	return(progressions)
}, mc.cores = cores)


PostProcs$writer("ProgressionsData")
print("[Anls]          Finding Model AllProg Outputs processed")


# ---------------#
# Get NarrativeOuts, preprocess 
# ---------------#
 
print(sprintf("[Anls]           Models:%s",ModelNumber ))

print("[Anls]          Finding Model Narrative Output files for preprocessing")

Out_pattern = sprintf("CovidABM7_NarrativeOuts_%s_job", ModelNumber)
Outfiles = unlist(lapply(Out_pattern, function(x) {list.files(path = outDir, pattern = x)}))
# print(Out_pattern)
# print(Outfiles)

PreProcNarratives <- function (j) {
	print(sprintf("[Anls]          Reading Model Narrative File:%s", Outfiles[j]))
    fname <- sprintf("%s/%s", outDir, Outfiles[j])
    tmpNarrLog <- read.csv(file = fname)
    tmpNarrLog$JobID <- j
    tmpNarrLog$uniqueRunID <- paste(ModelNumber, tmpNarrLog$JobID, tmpNarrLog$subModelID, sep = "-")
	tmpNarrLog$Time <- as.numeric(tmpNarrLog$Time)

	tmpNarrLog$ExposerCount <- 0
	tmpNarrLog$ExposerCount[tmpNarrLog$ExposerPopIDs != "None" & tmpNarrLog$NewExposurePopIDs != ""] <- 
		sapply(tmpNarrLog$ExposerPopIDs[tmpNarrLog$ExposerPopIDs != "None" & tmpNarrLog$NewExposurePopIDs != ""], 
			function (x) length(str_split(x, "-", simplify = TRUE)))
	tmpNarrLog$ExposerCount <- unlist(tmpNarrLog$ExposerCount)

	tmpNarrLog$ExposedCount <- 0
	tmpNarrLog$ExposedCount[tmpNarrLog$ExposerPopIDs != "None" & tmpNarrLog$NewExposurePopIDs != ""] <- 
		sapply(tmpNarrLog$NewExposurePopIDs[tmpNarrLog$ExposerPopIDs != "None" & tmpNarrLog$NewExposurePopIDs != ""], 
			function (x) length(str_split(x, "-", simplify = TRUE)))
	tmpNarrLog$ExposedCount <- unlist(tmpNarrLog$ExposedCount)

	tmpNarrLog$ExposureAttrib <- tmpNarrLog$ExposedCount/tmpNarrLog$ExposerCount
	
# 	print(head(tmpNarrLog[tmpNarrLog$ExposerPopIDs != "None" & tmpNarrLog$NewExposurePopIDs != "", c("ExposerPopIDs", "NewExposurePopIDs", "ExposerCount", "ExposedCount", "ExposureAttrib")]))
# 	print(nrow(tmpNarrLog[tmpNarrLog$ExposerPopIDs != "None" & tmpNarrLog$NewExposurePopIDs != "", c("ExposerPopIDs", "NewExposurePopIDs", "ExposerCount", "ExposedCount", "ExposureAttrib")]))
# 	print(head(tmpNarrLog[, c("ExposerPopIDs", "NewExposurePopIDs", "ExposerCount", "ExposedCount", "ExposureAttrib")]))
# 	print(tail(tmpNarrLog))
	saveRDS(tmpNarrLog, file=sprintf("/tmp/CovidABM7_NarrativePreProc_%s_%03d.Rds", ModelNumber, j))
}

nothing <- mclapply(PostProcs$job, function (j) PreProcNarratives(j), mc.cores=cores)

print("Narratives PreProcessed into files")

# ---------------#
# Add Preproc Narratives to DB
# ---------------#


print("[Anls]          Setting Up DB")
setupNarrativesdb <- function () {
	print("[Anls]          Removing Previous DB if it exists")
	if (file.exists(sprintf("processedOuts/CovidABM_Narratives_%s.db", ModelNumber))) {
		file.remove(sprintf("processedOuts/CovidABM_Narratives_%s.db", ModelNumber))
	}

	NarrConn = dbConnect(RSQLite::SQLite(), sprintf("processedOuts/CovidABM_Narratives_%s.db", ModelNumber))
	dbGetQuery(NarrConn, "PRAGMA foreign_keys")
	dbSendQuery(NarrConn, "PRAGMA foreign_keys=ON")
	dbGetQuery(NarrConn, "PRAGMA foreign_keys")

	dbSendQuery(NarrConn, "DROP TABLE IF EXISTS agents")
	dbSendQuery(NarrConn, "DROP TABLE IF EXISTS events")
	dbSendQuery(NarrConn, "DROP TABLE IF EXISTS exposers")
	dbSendQuery(NarrConn, "DROP TABLE IF EXISTS events_exposers")

	dbSendQuery(NarrConn, "CREATE TABLE IF NOT EXISTS agents (
		id INTEGER PRIMARY KEY,
		PopID VARCHAR(32) NOT NULL,
		InfectDate VARCHAR(32),   
		WGSlat Real NOT NULL,
		WGSlon Real NOT NULL,
		NumHH INTEGER NOT NULL,       
		AgeHH Real NOT NULL,
		IncomeHH Real NOT NULL,
		OccupationHH VARCHAR(32) NOT NULL,
		RaceHH VARCHAR(32) NOT NULL,
		tractbg VARCHAR(32) NOT NULL,     
		IncludedInRunCount INTEGER,
		FOREIGN KEY(PopID) REFERENCES exposers(PopID)
	)")

	dbSendQuery(NarrConn, "CREATE TABLE IF NOT EXISTS events (
		id INTEGER PRIMARY KEY,
		uniqueRunID VARCHAR(32) NOT NULL,
		Time Real NOT NULL,
		ExposureAttrib Real,
		RunIDtime VARCHAR(32) NOT NULL
	)")

	dbSendQuery(NarrConn, "CREATE TABLE IF NOT EXISTS exposers (
		id INTEGER PRIMARY KEY,
		ExposerPopID VARCHAR(32) NOT NULL
	)")

	dbSendQuery(NarrConn, "CREATE TABLE IF NOT EXISTS events_exposers (
		events_id INTEGER NOT NULL,
		exposers_id INTEGER NOT NULL,
		FOREIGN KEY(events_id) REFERENCES events(id),
		FOREIGN KEY(exposers_id) REFERENCES exposers(id)
	)")
	dbDisconnect(NarrConn)
}
print("[Anls]          DB schemas established")

Narratives2DB <- function (j) {
### ---------------- Runtime Profiling
# profileOut <- profvis({
# print("Timing Test on the Runtime")
### ---------------- Runtime Profiling
	print(sprintf("[Anls]          Reading Model Narrative PreProcs:%s", Outfiles[j]))
    fname <- sprintf("%s/%s", "/tmp/", Outfiles[j])
    tmpNarrLog <- readRDS(file = fname)
# 	print(head(tmpNarrLog))

	############# Read in all of narrative and write it to db
	NarrConn = dbConnect(RSQLite::SQLite(), sprintf("processedOuts/CovidABM_Narratives_%s.db", ModelNumber))
	dbWriteTable(NarrConn, "Narratives", tmpNarrLog, append = TRUE)

	############# END OF Read in all of narrative and write it to db
	
	############# Add up IncludedInRunCount from new narratives and existing db
#	unique_PopIDs <- na.omit(unique(c(as.numeric(tmpNarrLog$FocalAgentPopID), 
#		suppressWarnings(as.numeric(unlist(sapply(tmpNarrLog$WithAgentsPopID, function(x) str_split(x, "-"))))))))

	tmpNarrLog$WithAgentsPopID <- as.character(tmpNarrLog$WithAgentsPopID)

	unique_PopIDs <- na.omit(unique(c(as.numeric(tmpNarrLog$FocalAgentPopID),
                suppressWarnings(as.numeric(unlist(strsplit(tmpNarrLog$WithAgentsPopID, "-")))))))
	
	unique_PopIDs <- unique_PopIDs[order(unique_PopIDs)]	
#	print(head(unique_PopIDs))
#	print(tail(unique_PopIDs))
#	print(length(unique_PopIDs))
	
	agents_new <- data.frame(PopID = unique_PopIDs, IncludedInRunCount = 1)

	agents_new$PopID <- as.character(agents_new$PopID)
	
	if (j == 1) {
		agents_new <- merge(pop, agents_new, by="PopID", all.x=TRUE)
# 		print(head(agents_new))
# 		print(tail(agents_new))
# 		print(nrow(agents_new))
		dbWriteTable(NarrConn, "agents", agents_new, append = TRUE)
	} else {
	
		agents_db <- dbGetQuery(NarrConn, "SELECT * FROM agents")
		agents_db$PopID <- as.numeric(agents_db$PopID)
		agents_db <- agents_db[order(agents_db$PopID), ]
		agents_db$PopID <- as.character(agents_db$PopID)
# 		print(head(agents_db))
# 		print(tail(agents_db))
# 		print(nrow(agents_db))
	
		agents_df <- merge(agents_new, agents_db, by="PopID", all.x=TRUE, all.y=TRUE)
		agents_df$PopID <- as.numeric(agents_df$PopID)
		agents_df <- agents_df[order(agents_df$PopID), ]
		agents_df$PopID <- as.character(agents_df$PopID)
		agents_df[is.na(agents_df)] = 0
		agents_df$IncludedInRunCount <- agents_df$IncludedInRunCount.x + agents_df$IncludedInRunCount.y
		agents_df$IncludedInRunCount.x <- NULL 
		agents_df$IncludedInRunCount.y <- NULL
# 		print(head(agents_df))
# 		print(tail(agents_df))
# 		print(nrow(agents_df))
		print(table(agents_df$IncludedInRunCount))

		dbWriteTable(NarrConn, "agents", agents_df, overwrite = TRUE)
	
	}
	############# END OF Add up IncludedInRunCount from new narratives and existing db

	############# Build events_exposers bridging table
	events_df <- tmpNarrLog[!is.na(tmpNarrLog$ExposureAttrib), c("uniqueRunID", "Time", "ExposureAttrib")] 
	#dbGetQuery(NarrConn, "SELECT uniqueRunID, Time, ExposureAttrib FROM Narratives WHERE ExposureAttrib != 'NA' ORDER BY uniqueRunID, Time")
# 	print(head(events_df))
# 	print(tail(events_df))
# 	print(nrow(events_df))
	events_df <- events_df[order(events_df$uniqueRunID,events_df$Time), ]
	if (nrow(events_df) > 0) { 
		rownames(events_df) <- seq(1:nrow(events_df))
	
	events_df$RunIDtime <- paste(events_df$uniqueRunID, signif(events_df$Time, 8), sep="-")
# 	print("events_df")
# 	print(head(events_df))
# 	print(tail(events_df))
# 	print(nrow(events_df))
	
	dbWriteTable(NarrConn, "events", events_df, append = TRUE)
# 	print(dbGetQuery(NarrConn, "SELECT COUNT(*) FROM events"))
# 	print(dbGetQuery(NarrConn, "SELECT * FROM events LIMIT 10"))

	unique_event_df <- data.frame(RunIDtime = events_df$RunIDtime, id = seq(1:nrow(events_df)))
	#dbGetQuery(NarrConn, "SELECT ROWID, RunIDtime FROM events")
# 	print("unique_event_df")
# 	print(head(unique_event_df))
# 	print(tail(unique_event_df))
# 	print(nrow(unique_event_df))

# 	print("tmpNarrLog[!is.na(tmpNarrLog$ExposureAttrib),]")
# 	print(head(tmpNarrLog[!is.na(tmpNarrLog$ExposureAttrib),]))
# 	print(tail(tmpNarrLog[!is.na(tmpNarrLog$ExposureAttrib),]))
# 	print(nrow(tmpNarrLog[!is.na(tmpNarrLog$ExposureAttrib),]))
	
	exposers_strung <-  tmpNarrLog[!is.na(tmpNarrLog$ExposureAttrib),c("ExposerPopIDs")]
	#dbGetQuery(NarrConn, "SELECT ExposerPopIDS FROM Narratives WHERE ExposureAttrib != 'NA'")
	exposer_ordered_vec <- as.character(unlist(sapply(exposers_strung, function(x) str_split(x, "-"))))
# 	print(head(exposer_ordered_vec))
# 	print(length(exposer_ordered_vec))
# 	print("this was exposer_ordered_vec")
	unique_exposers_vec <- unique(exposer_ordered_vec)
# 	print(head(unique_exposers_vec))
# 	print(length(unique_exposers_vec))
# 	print("this was unique_exposers_vec")
	unique_exposers_df <- data.frame(ExposerPopID = unique_exposers_vec)
	
# 	print("unique_exposers_df")
# 	print(head(unique_exposers_df))
# 	print(tail(unique_exposers_df))
# 	print(nrow(unique_exposers_df))
	
	dbWriteTable(NarrConn, "exposers", unique_exposers_df, append = TRUE)
# 	print(dbGetQuery(NarrConn, "SELECT COUNT(*) FROM exposers"))
# 	print(dbGetQuery(NarrConn, "SELECT * FROM exposers LIMIT 10"))

# 	unique_exposers_db <- unique_exposers_df[,c("ExposerPopID")]
# 	#dbGetQuery(NarrConn, "SELECT ROWID, ExposerPopID FROM exposers")
# 	head(unique_exposers_db)
# 	nrow(unique_exposers_db)



	exposerID_ordered_vec <- fmatch(exposer_ordered_vec, unique_exposers_df$ExposerPopID)
	names(exposerID_ordered_vec) <- NULL
	# head(exposerID_ordered_vec)
	print(length(exposerID_ordered_vec)) ### Finished and correct length (33623)
# 	print("checkpoint 1")


	# head(exposers_strung, n=62)
	exposers_list <- sapply(exposers_strung, function(x) str_split(x, "-"))
	# head(exposers_list, n=62)
# 	print("checkpoint 2")

	##################################The following is slow - dont run on all narratives at once

	exposers_list_length <- sapply(exposers_list, function(x) length(exposers_list[x]))
	# head(exposers_list_length, n=62)
	names(exposers_list_length) <- NULL
	# length(exposers_list_length)
# 	print("checkpoint 3")

	eventID_vec <- unlist(mapply(function(i,j) rep(i,each=j), unique_event_df$id, exposers_list_length))
	# head(eventID_vec, n=62)
	print(length(eventID_vec)) ### Finished and correct length (33623)
# 	print("checkpoint 4")

	events_exposers_df <- data.frame(events_id = eventID_vec, exposers_id = exposerID_ordered_vec)
	# head(events_exposers_df)
# 	nrow(events_exposers_df)

	dbWriteTable(NarrConn, "events_exposers", events_exposers_df, append = TRUE)
# 	print(dbGetQuery(NarrConn, "SELECT COUNT(*) FROM events_exposers"))
# 	print(dbGetQuery(NarrConn, "SELECT * FROM events_exposers LIMIT 10"))
	############# END OF Build events_exposers bridging table

	dbDisconnect(NarrConn)
### ---------------- Runtime Profiling
# })
# saveRDS(profileOut, file="TimingRuntime_profileOut.Rds")
### ---------------- Runtime Profiling
	return(nrow(events_df))
	} else {
		print("PROBLEM: No New Exposures Generated")
		return(0)
	}

}

print("[Anls]          Finding Model Narrative preprocs files for database insert")

Out_pattern = sprintf("CovidABM7_NarrativePreProc_%s", ModelNumber)
Outfiles = unlist(lapply(Out_pattern, function(x) {list.files(path = "/tmp/", pattern = x)}))
# print(Out_pattern)
# print(Outfiles)



setupNarrativesdb()
ExposureCount <- sum(unlist(lapply(PostProcs$job, function (j) Narratives2DB(j))))


print("[Anls]          Model Narrative preprocs inserted to DB")



# ---------------#
# Get Network PreProcs
# ---------------#
print("Processing Networks from db")

ProcNetworks <- function (j) {

# 	print(sprintf("[Anls]          Outfile %d of %d", j, length(Outfiles)))
# 	print(sprintf("[Anls]          Reading Model Narrative Output File:%s", Outfiles[j]))

# 	Narr_Param_DF <- read.csv(file = sprintf("%s/%s", outDir, Outfiles[j]), stringsAsFactors=FALSE)
#     Narr_Param_DF <- readRDS(file = sprintf("%s/%s", "/tmp/", Outfiles[j]))
# 	Narr_Param_DF$Time <- as.numeric(Narr_Param_DF$Time)
# 	print(str(Narr_Param_DF))

	NarrConn = dbConnect(RSQLite::SQLite(), sprintf("processedOuts/CovidABM_Narratives_%s.db", ModelNumber))
	
	Narr_Param_DF <- dbGetQuery(NarrConn, "SELECT ExposerPopIDs, 
												NewExposurePopIDs, 
												Time, 
												FocalAgentPopID, 
												FocalAgentStatus,
												FocalAgentFlout, 
												FocalAgentEsntl, 
												FocalAgent_RiskTol, 
												FocalAgentTest, 
												WithAgentsPopID,
												WithAgentsFlout, 
												WithAgentsEsntl, 
												WithAgents_RiskTol, 
												WithAgentsTest,
												Event 
											FROM Narratives 
											WHERE Time > 0 AND 
												ExposerPopIDs != 'None' AND 
												ExposerPopIDs != '' AND 
												NewExposurePopIDs != ''")
	
	
	dbDisconnect(NarrConn)

	Narr_Param_DF$Days <- trunc(Narr_Param_DF$Time)
	
	N.tmp <- Narr_Param_DF
	N.tmp <- N.tmp %>%
	  bind_cols(as.data.frame(str_split(N.tmp$NewExposurePopIDs, "-", simplify = TRUE))) %>%
	  gather(-names(N.tmp), key = "NewExposure", value = "NewExposurePopIDs") %>%
	  filter(NewExposurePopIDs != "")

	N.tmp <- N.tmp %>%
	  bind_cols(as.data.frame(str_split(N.tmp$ExposerPopIDs, "-", simplify = TRUE))) %>%
	  gather(-names(N.tmp), key = "Exposer", value = "ExposerPopIDs") %>%
	  filter(ExposerPopIDs != "")

	N.tmp$NewExposurePopIDs <- as.integer(N.tmp$NewExposurePopIDs)
	N.tmp <- N.tmp[order(N.tmp$NewExposurePopIDs), ]
	N.tmp$ExposerPopIDs <- as.integer(N.tmp$ExposerPopIDs)
	N.tmp <- N.tmp[order(N.tmp$ExposerPopIDs), ]
	
# 	print(head(N.tmp))
# 	print(tail(N.tmp))
# 	print(str(N.tmp))

# 	print(str(N.tmp))

#		N.tmp$ExposerPopIDs <- as.character(as.integer(N.tmp$ExposerPopIDs))

	NetworkData <- N.tmp 

	rm(N.tmp)

	NetworkData <- NetworkData[order(NetworkData$ExposerPopIDs), ]
# 	print(head(NetworkData))
# 	print(tail(NetworkData))
# 	print(str(NetworkData))
	
	#Create weights, nodes and edges

	weights <- NetworkData %>%  
	  group_by(ExposerPopIDs, NewExposurePopIDs) %>%
	  summarise(weight = n()) %>% 
	  ungroup()

	edges <- NetworkData %>%
	  left_join(weights) %>%
	  rename(from = ExposerPopIDs, to = NewExposurePopIDs) %>%
	  select(-Exposer, -NewExposure) %>%
	  select(from, to, everything())


# 		nodes <- bind_rows(distinct(NetworkData, NewExposurePopIDs) %>% rename(agentPopID = NewExposurePopIDs), 
# 							distinct(NetworkData, ExposerPopIDs) %>% rename(agentPopID = ExposerPopIDs)) %>% distinct() 
	
	
	nodes.all <- c(NetworkData$ExposerPopIDs, NetworkData$NewExposurePopIDs)
# 	print(head(nodes.all))
# 	print(tail(nodes.all))
# 	print(length(nodes.all))
# 	print(length(unique(nodes.all)))

#################################why doesnt this line match another line?
	nodes <- data.frame(agentPopID=unique(nodes.all))
	nodes$flag <- 1
	nodes <- nodes[order(nodes$agentPopID), ]
# 	print(" problem with IncludedInRunCount ?") 
# 	print(head(nodes))
# 	print(tail(nodes))
# 	print(nrow(nodes))

	NarrConn = dbConnect(RSQLite::SQLite(), sprintf("processedOuts/CovidABM_Narratives_%s.db", ModelNumber))

		TotalDirectExposures_df <- dbGetQuery(NarrConn, "SELECT exposers.ExposerPopID, SUM(events.ExposureAttrib) as TotalDirectExposures, COUNT(events.ExposureAttrib) as TotalExposerTimes
		  FROM exposers 
		  INNER JOIN events_exposers 
				ON events_exposers.exposers_id = exposers.id 
		   INNER JOIN events 
				ON events_exposers.events_id = events.id        
			GROUP BY exposers.ExposerPopID")
		
		agents_df <- dbGetQuery(NarrConn, "SELECT PopID, IncludedInRunCount FROM agents")
	
	dbDisconnect(NarrConn)

	TotalDirectExposures_df <- TotalDirectExposures_df[order(as.numeric(TotalDirectExposures_df$ExposerPopID)), ]

	exposers_df <- TotalDirectExposures_df
# 	exposers_df$meanDirectExposures <- exposers_df$TotalDirectExposures / exposers_df$IncludedInRunCount
	colnames(exposers_df)[colnames(exposers_df) == "ExposerPopID"] = "agentPopID"
	exposers_df$agentPopID <- as.integer(exposers_df$agentPopID)
	exposers_df <- exposers_df[order(exposers_df$agentPopID), ]

# 	print(" problem with IncludedInRunCount Correct for exposers") 

# 	print(head(exposers_df))
# 	print(tail(exposers_df))
# 	print(nrow(exposers_df))


	nodes <- left_join(nodes, exposers_df, by = "agentPopID") 
	nodes <- merge(nodes, agents_df, by.x="agentPopID", by.y="PopID", all.x=TRUE)
# 	print(" problem with IncludedInRunCount - NAS ") 
# 	print(head(nodes))
# 	print(tail(nodes))
# 	print(nrow(nodes))

	nodes[is.na(nodes)] = 0

# 	print(head(nodes))
# 	print(tail(nodes))
# 	print(nrow(nodes))	


	pop <- pop  %>% mutate(AgeHHCat = ifelse(AgeHH < 18, "Under 18y", 
											 ifelse(AgeHH >= 18 & AgeHH < 50, "18-49y",
													ifelse(AgeHH >= 50 & AgeHH < 65, "50-64y", "65y+"))))
	pop <- pop %>% mutate(IncomeHHCat = ifelse(IncomeHH < 31000, "Lowest",
											   ifelse(IncomeHH >= 31000 & IncomeHH < 42000, "Lower-Middle",
													  ifelse(IncomeHH >= 42000 & IncomeHH < 126000, "Middle",
															 ifelse(IncomeHH >= 126000 & IncomeHH < 188000, "Upper-Middle", "Higher")))))
	pop$agentPopID <- as.integer(pop$PopID)

	nodes <- pop %>% 
	  select(agentPopID, NumHH, IncomeHH, OccupationHH, RaceHH, AgeHH, AgeHHCat, IncomeHHCat) %>%
	  right_join(nodes, by = "agentPopID") %>%
	  select(agentPopID, everything())
	
	nodes <- nodes[order(nodes$agentPopID), ]
# 	print("check nodes RaceHH for NAs")
# 	print(table(nodes$RaceHH, exclude = NULL))
# 	print("See any NAs?")

# 	print("still a problem with IncludedInRunCount -1 ") 
# 	print(head(nodes))
# 	print(tail(nodes))
# 	print(nrow(nodes))
######## 
#
# Calculate aggregate metrics
#
########

	exposures <- Narr_Param_DF %>% filter(NewExposurePopIDs != "None")
# 	print(head(exposures))
# 	print(tail(exposures))
# 	print(nrow(exposures))	

	schedule <- exposures %>%
	  select(FocalAgentPopID, FocalAgentFlout, FocalAgentEsntl, Event, FocalAgent_RiskTol, FocalAgentTest) %>%
	  mutate(Flout = ifelse(FocalAgentFlout == "Flout", 1, 0),
			 EsntlAct = ifelse(Event == "NonEssential", 0, 1),
			 EsntlWrk = ifelse(FocalAgentEsntl == "Esntl", 1, 0),
			 Test = ifelse(FocalAgentTest == "None", 0, 1)) %>%
	  rename(agentPopID = FocalAgentPopID, FloutStatus = FocalAgentFlout, EsntlStatus = FocalAgentEsntl,  TestStatus = FocalAgentTest, RiskTol = FocalAgent_RiskTol) %>%
	  select(agentPopID, Flout, EsntlAct, EsntlWrk, Test, RiskTol)

	schedule$agentPopID <- as.integer(schedule$agentPopID)
	schedule$RiskTol <- round(as.numeric(schedule$RiskTol), 2)

	schedule <- schedule[order(schedule$agentPopID), ]
# 		print(head(schedule))
# 		print(tail(schedule))
# 		print(str(schedule))


	if(NetworksCalcParticipate == "on"){

	part.tmp <- exposures %>%
	  select(WithAgentsPopID, WithAgentsFlout, WithAgentsEsntl, Event, WithAgents_RiskTol, WithAgentsTest) %>%
	  filter(WithAgentsPopID != "")

# 		print(head(part.tmp))
# 		print(tail(part.tmp))
# 		print(nrow(part.tmp))

	participate <- suppressWarnings({apply(part.tmp, 1, function(z) cbind(
	  "agentPopID"=unlist(strsplit(as.character(z[1]),"-")),
	  "FloutStatus"=unlist(strsplit(as.character(z[2]),"-")),
	  "EsntlStatus"=unlist(strsplit(as.character(z[3]),"-")),
	  "Event"=z[4],
	  "RiskTol"=unlist(strsplit(as.character(z[5]),"-")),
	  "TestStatus"=unlist(strsplit(as.character(z[6]),"-"))))
	  })
# 		print(head(participate))
# 		print(tail(participate))
# 		print(nrow(participate))


	participate <- data.frame(do.call("rbind", participate), stringsAsFactors=FALSE)

	participate <- participate %>%
	  mutate(Flout = ifelse(FloutStatus == "Flout", 1, 0),
			 EsntlAct = ifelse(Event == "NonEssential", 0, 1),
			 EsntlWrk = ifelse(EsntlStatus == "Esntl", 1, 0),
			 Test = ifelse(TestStatus == "None", 0, 1)) %>%
	  select(agentPopID, Flout, EsntlAct, EsntlWrk, Test, RiskTol)

	participate$agentPopID <- as.integer(participate$agentPopID)
	participate$RiskTol <- round(as.numeric(participate$RiskTol), 2)
	participate <- participate[order(participate$agentPopID), ]
# 		print(head(participate))
# 		print(tail(participate))
# 		print(nrow(participate))
# 		print(table(participate$EsntlWrk))
# 
# 		df <- as.data.frame(aggregate(data = participate, EsntlWrk~agentPopID, FUN = mean))
# 
# 		print(head(df))
# 
# 		print(summary(df$EsntlWrk))



	}

	schedule$flag <- 1
	schedule <- schedule[order(schedule$agentPopID), ]
	participate$flag <- 1
	participate <- participate[order(participate$agentPopID), ]

# 		print(head(schedule))
# 		print(head(participate))

	ifelse(NetworksCalcParticipate == "on", 
		   allevents <- bind_rows(schedule, participate),
		   allevents <- schedule)

	allevents <- allevents %>%
	  group_by(agentPopID) %>%
	  summarise(ActivityCount = sum(flag), FloutPct = mean(Flout), EsntlActPct = mean(EsntlAct), EsntlWrkPct = mean(EsntlWrk), TestPct = mean(Test), RiskTolMean = mean(RiskTol)) 

# 		allevents <- allevents %>%
# 		  mutate(FloutTendency = ifelse(FloutPct>median(FloutPct, na.rm = T), "High", "Low"),
# 				 EsntlActTendency = ifelse(EsntlActPct>median(EsntlActPct, na.rm = T), "High", "Low"),
# 				 EsntlWrkTendency = ifelse(EsntlWrkPct>median(EsntlWrkPct, na.rm = T), "High", "Low"),
# 				 TestTendency = ifelse(TestPct>median(TestPct, na.rm = T), "High", "Low"))

	allevents <- allevents[order(allevents$agentPopID), ]
# 		print(head(allevents))
# 		print(tail(allevents))
# 		print(str(allevents))

	rm(part.tmp, schedule, participate)

	#Merge with nodes

	nodes <- nodes %>% left_join(allevents, by = "agentPopID")

# 		nodes <- nodes %>% mutate(FloutEsntlWrk = ifelse(FloutTendency == "High" & EsntlWrkTendency == "High", "HighFlout_HighEsntlWrk",
# 													  ifelse(FloutTendency == "High" & EsntlWrkTendency == "Low", "HighFlout_LowEsntlWrk",
# 															 ifelse(FloutTendency == "Low" & EsntlWrkTendency == "High", "LowFlout_HighEsntlWrk", "LowFlout_LowEsntlWrk"))))

	# Create graph dataframe
#		nodes$agentPopID <- as.numeric(nodes$agentPopID)
	
	nodes <- nodes[order(nodes$agentPopID), ]

#     if(9 %in% nodes$agentPopID) { print(nodes[nodes$agentPopID == 9, ]) }
#     if(380401 %in% nodes$agentPopID) { print(nodes[nodes$agentPopID == 380401, ]) }

# print("still a problem with IncludedInRunCount 0") 
# print(head(nodes))
# print(tail(nodes))
# print(nrow(nodes))
	
# 	print(sprintf("[Anls]          Writing Network preproc %d", j))
# 	
# 	save(nodes, edges, file=sprintf("%sCovidABM7_PreProcNet_%s_%03d.Rdata", "/tmp/", ModelNumber, j))

nodes <- nodes %>%
  mutate(
    FloutTendency = ifelse(FloutPct > mean(FloutPct, na.rm = T), "High", "Low"),
    EsntlActTendency = ifelse(EsntlActPct > mean(EsntlActPct, na.rm = T), "High", "Low"),
    EsntlWrkTendency = ifelse(EsntlWrkPct > mean(EsntlWrkPct, na.rm = T), "High", "Low"),
    TestTendency = ifelse(TestPct > mean(TestPct, na.rm = T), "High", "Low")
  )
  
  
# print("still a problem with IncludedInRunCount 1") 
# print(head(nodes))
# print(tail(nodes))
# print(nrow(nodes))
nodes <-
  nodes %>% mutate(
    FloutEsntlWrk = ifelse(
      FloutTendency == "High" &
        EsntlWrkTendency == "High",
      "HighFlout_HighEsntlWrk",
      ifelse(
        FloutTendency == "High" &
          EsntlWrkTendency == "Low",
        "HighFlout_LowEsntlWrk",
        ifelse(
          FloutTendency == "Low" &
            EsntlWrkTendency == "High",
          "LowFlout_HighEsntlWrk",
          "LowFlout_LowEsntlWrk"
        )
      )
    )
  )
  

abmnet2 <-
  graph_from_data_frame(vertices = nodes,
                        d = edges,
                        directed = TRUE)
abmnet <- as_tbl_graph(abmnet2)

# print(head(nodes))
# print(tail(nodes))
# print(nrow(nodes))
# print(head(edges))
# print(tail(edges))
# print(nrow(edges))

print("Saving Networks")

save(abmnet, nodes, edges, file = sprintf("processedOuts/CovidABM7_Network_%s.Rdata", ModelNumber))
}

if(ExposureCount > 0) {ProcNetworks()}

print("Done Processing Networks from db")
warnings()
q()


































# ---------------#
# Aggregate Networks
# ---------------#


nodes_all <- data.frame()
edges_all <- data.frame()


Out_pattern = sprintf("CovidABM7_PreProcNet_%s_", ModelNumber)
Outfiles = unlist(lapply(Out_pattern, function(x) {list.files(path = "/tmp/", pattern = x)}))
# print(Out_pattern)
# print(Outfiles)  
  

for (j in 1:length(Outfiles)) {
    #	for(j in 46:length(Outfiles)) {
#     for(j in 1:9) {
    print(sprintf("[Anls]          Outfile %d of %d", j, length(Outfiles)))
    print(sprintf("[Anls]          Reading Model Network PreProc File:%s", Outfiles[j]))
    
    load(file = sprintf("%s/%s", "/tmp", Outfiles[j]))
    
    if(9 %in% nodes$agentPopID) { print(nodes[nodes$agentPopID == 9, ]) }
    if(380401 %in% nodes$agentPopID) { print(nodes[nodes$agentPopID == 380401, ]) }
    
    if (j == 1) {
    	nodes_all <- nodes
    	edges_all <- edges
    } else {
		nodes <- nodes[order(nodes$agentPopID),]
		# 			print(head(nodes))
		# 			print(tail(nodes))
		# 			print(str(nodes))

		nodes_all <- nodes_all[order(nodes_all$agentPopID),]
		# 			print(head(nodes_all))
		# 			print(tail(nodes_all))
		# 			print(str(nodes_all))


		agentPopID_common <-
		nodes$agentPopID[nodes$agentPopID %in% nodes_all$agentPopID]
		#			print(agentPopID_common)

		nrow_nodes <- nrow(nodes)
		nrow_nodes_all <- nrow(nodes_all)


		# 			print(head(nodes[nodes$agentPopID %in% agentPopID_common, ]))
		# 			print(head(nodes_all[nodes_all$agentPopID %in% agentPopID_common, ]))

		nodes_common <-
		merge(nodes[nodes$agentPopID %in% agentPopID_common,], nodes_all[nodes_all$agentPopID %in% agentPopID_common,], by =
				"agentPopID")
		nodes_common <-
		nodes_common[order(as.numeric(nodes_common$agentPopID)), ]

		nodes_common$agentPopID
		nodes_common$NumHH <- nodes_common$NumHH.x
		nodes_common$IncomeHH <- nodes_common$IncomeHH.x
		nodes_common$OccupationHH <- nodes_common$OccupationHH.x
		nodes_common$RaceHH <- nodes_common$RaceHH.x
		nodes_common$AgeHH <- nodes_common$AgeHH.x
		nodes_common$AgeHHCat <- nodes_common$AgeHHCat.x
		nodes_common$IncomeHHCat <- nodes_common$IncomeHHCat.x
		nodes_common$flag <- nodes_common$flag.x + nodes_common$flag.y
		nodes_common$TotalDirectExposures <- nodes_common$TotalDirectExposures.x
		nodes_common$TotalExposerTimes <- nodes_common$TotalExposerTimes.x
# 		nodes_common$meanDirectExposures <- nodes_common$meanDirectExposures.x
		nodes_common$IncludedInRunCount <- nodes_common$IncludedInRunCount.x


		############ Use Activity Count to get weighted average of things
		
# 		nodes_common$meanDirectExposures <-
# 		(
# 		  nodes_common$meanDirectExposures.x * nodes_common$ActivityCount.x +  nodes_common$meanDirectExposures.y *
# 			nodes_common$ActivityCount.y
# 		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)
# 
# 		nodes_common$IncludedInRunCount <-
# 		(
# 		  nodes_common$IncludedInRunCount.x * nodes_common$ActivityCount.x +  nodes_common$IncludedInRunCount.y *
# 			nodes_common$ActivityCount.y
# 		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)


# 		nodes_common$Pr_S <-
# 		(
# 		  nodes_common$Pr_S.x * nodes_common$ActivityCount.x +  nodes_common$Pr_S.y *
# 			nodes_common$ActivityCount.y
# 		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)
# 		nodes_common$Pr_E <-
# 		(
# 		  nodes_common$Pr_E.x * nodes_common$ActivityCount.x +  nodes_common$Pr_E.y *
# 			nodes_common$ActivityCount.y
# 		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)
# 		nodes_common$Pr_Pa <-
# 		(
# 		  nodes_common$Pr_Pa.x * nodes_common$ActivityCount.x +  nodes_common$Pr_Pa.y *
# 			nodes_common$ActivityCount.y
# 		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)
# 		nodes_common$Pr_Py <-
# 		(
# 		  nodes_common$Pr_Py.x * nodes_common$ActivityCount.x +  nodes_common$Pr_Py.y *
# 			nodes_common$ActivityCount.y
# 		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)
# 		nodes_common$Pr_Ia <-
# 		(
# 		  nodes_common$Pr_Ia.x * nodes_common$ActivityCount.x +  nodes_common$Pr_Ia.y *
# 			nodes_common$ActivityCount.y
# 		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)
# 		nodes_common$Pr_Iy <-
# 		(
# 		  nodes_common$Pr_Iy.x * nodes_common$ActivityCount.x +  nodes_common$Pr_Iy.y *
# 			nodes_common$ActivityCount.y
# 		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)
# 		nodes_common$Pr_Ih <-
# 		(
# 		  nodes_common$Pr_Ih.x * nodes_common$ActivityCount.x +  nodes_common$Pr_Ih.y *
# 			nodes_common$ActivityCount.y
# 		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)
# 		nodes_common$Pr_Rr <-
# 		(
# 		  nodes_common$Pr_Rr.x * nodes_common$ActivityCount.x +  nodes_common$Pr_Rr.y *
# 			nodes_common$ActivityCount.y
# 		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)
# 		nodes_common$Pr_Rd <-
# 		(
# 		  nodes_common$Pr_Rd.x * nodes_common$ActivityCount.x +  nodes_common$Pr_Rd.y *
# 			nodes_common$ActivityCount.y
# 		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)


		############ Use Activity Count to get weighted average of things

		nodes_common$ActivityCount <-
		nodes_common$ActivityCount.x + nodes_common$ActivityCount.y
		nodes_common$FloutPct <-
		(
		  nodes_common$FloutPct.x * nodes_common$ActivityCount.x +  nodes_common$FloutPct.y *
			nodes_common$ActivityCount.y
		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)
		nodes_common$EsntlActPct <-
		(
		  nodes_common$EsntlActPct.x * nodes_common$ActivityCount.x +  nodes_common$EsntlActPct.y *
			nodes_common$ActivityCount.y
		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)
		nodes_common$EsntlWrkPct <-
		(
		  nodes_common$EsntlWrkPct.x * nodes_common$ActivityCount.x +  nodes_common$EsntlWrkPct.y *
			nodes_common$ActivityCount.y
		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)
		nodes_common$TestPct <-
		(
		  nodes_common$TestPct.x * nodes_common$ActivityCount.x +  nodes_common$TestPct.y *
			nodes_common$ActivityCount.y
		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)
		nodes_common$RiskTolMean <-
		(
		  nodes_common$RiskTolMean.x * nodes_common$ActivityCount.x +  nodes_common$RiskTolMean.y *
			nodes_common$ActivityCount.y
		) / (nodes_common$ActivityCount.x + nodes_common$ActivityCount.y)


		nodes_common <-
		nodes_common[, c(
			"agentPopID",
			"NumHH",
			"IncomeHH",
			"OccupationHH",
			"RaceHH",
			"AgeHH",
			"AgeHHCat",
			"IncomeHHCat",
			"flag",
			"TotalDirectExposures",
			"TotalExposerTimes",
			"IncludedInRunCount",
# 			"meanDirectExposures",
# 			"Pr_S",
# 			"Pr_E",
# 			"Pr_Pa",
# 			"Pr_Py",
# 			"Pr_Ia",
# 			"Pr_Iy",
# 			"Pr_Ih",
# 			"Pr_Rr",
# 			"Pr_Rd",
			"ActivityCount",
			"FloutPct",
			"EsntlActPct",
			"EsntlWrkPct",
			"TestPct",
			"RiskTolMean"
		)]



		nodes_common <- nodes_common[order(nodes_common$agentPopID), ]
		
		nrow_nodes_update <- nrow(nodes_common)

		nodes_all[nodes_all$agentPopID %in% agentPopID_common,] <-
		nodes_common

		nodes_all <-
		rbind(nodes_all, nodes[!(nodes$agentPopID %in% nodes_all$agentPopID),])


		print(
			sprintf(
			  "nrow in nodes all: %d, nrow in nodes: %d, nrow in nodes_update: %d, FINAL nrow in nodes_all: %d",
			  nrow_nodes_all,
			  nrow_nodes,
			  nrow_nodes_update,
			  nrow(nodes_all)
			)
		)


		# 			print(head(edges))
		# 			print(nrow(edges))

		# 			print(head(edges_all))
		# 			print(nrow(edges_all))

		edges_all <- rbind(edges_all, edges)

		# 			print(head(edges_all))
		# 			print(nrow(edges_all))

	}
}


print("done Aggregating, processing aggregated network now")

NarrConn = dbConnect(RSQLite::SQLite(), sprintf("processedOuts/CovidABM_Narratives_%s.db", ModelNumber))
	
exposers_db <- dbGetQuery(NarrConn, "SELECT ExposerPopID, COUNT(ExposerPopID) FROM exposers GROUP BY ExposerPopID")

dbDisconnect(NarrConn)
exposers_db <- exposers_db[order(as.integer(exposers_db$ExposerPopID)),]
colnames(exposers_db) <- c("agentPopID", "TotalExposerRuns")

# print(head(exposers_db))
# print(tail(exposers_db))
# print(nrow(exposers_db))

nodes_all <- merge(nodes_all, exposers_db, by = "agentPopID", all.x=TRUE)
#nodes_all$meanDirectExposures <- nodes_all$TotalDirectExposures / nodes_all$flag


# print(head(nodes_all))
# print(tail(nodes_all))
# print(nrow(nodes_all))


nodes_all <- nodes_all %>%
  mutate(
    FloutTendency = ifelse(FloutPct > mean(FloutPct, na.rm = T), "High", "Low"),
    EsntlActTendency = ifelse(EsntlActPct > mean(EsntlActPct, na.rm = T), "High", "Low"),
    EsntlWrkTendency = ifelse(EsntlWrkPct > mean(EsntlWrkPct, na.rm = T), "High", "Low"),
    TestTendency = ifelse(TestPct > mean(TestPct, na.rm = T), "High", "Low")
  )


nodes_all <-
  nodes_all %>% mutate(
    FloutEsntlWrk = ifelse(
      FloutTendency == "High" &
        EsntlWrkTendency == "High",
      "HighFlout_HighEsntlWrk",
      ifelse(
        FloutTendency == "High" &
          EsntlWrkTendency == "Low",
        "HighFlout_LowEsntlWrk",
        ifelse(
          FloutTendency == "Low" &
            EsntlWrkTendency == "High",
          "LowFlout_HighEsntlWrk",
          "LowFlout_LowEsntlWrk"
        )
      )
    )
  )

nodes_all <- nodes_all[order(nodes_all$agentPopID), ]

abmnet2 <-
  graph_from_data_frame(vertices = nodes_all,
                        d = edges_all,
                        directed = TRUE)
abmnet <- as_tbl_graph(abmnet2)

print(head(nodes_all))
print(tail(nodes_all))
print(nrow(nodes_all))

print("Saving Networks")

save(abmnet, nodes_all, edges_all, file = sprintf("processedOuts/CovidABM7_Network_%s.Rdata", ModelNumber))



#---------------#
# Make Days Outs from Narratives (maybe?)
#---------------#


print("Finished PostProccing")
warnings()
q()


##########   -   Garbage between here and below

#     print(head(tmpNarrLog))	
# 	tmpNarrLog <- tmpNarrLog[tmpNarrLog$ExposerPopIDs != "None" & tmpNarrLog$NewExposurePopIDs != "", 
# 		c("ExposerPopIDs", "NewExposurePopIDs", "Model", "subModelID")]
# 	
# 	tmpNarrLog$JobID <- j
#     tmpNarrLog$uniqueRunID <- paste(tmpNarrLog$Model, tmpNarrLog$JobID, tmpNarrLog$subModelID, sep = "-")
# 	tmpNarrLog$Time <- as.numeric(tmpNarrLog$Time)
# 	tmpNarrLog$IncludedInRunCount <- 1
# # 	print(head(tmpNarrLog[tmpNarrLog$ExposerPopIDs != "None" & tmpNarrLog$NewExposurePopIDs != "", c("ExposerPopIDs", "NewExposurePopIDs")]))
# # 	print(nrow(tmpNarrLog[tmpNarrLog$ExposerPopIDs != "None" & tmpNarrLog$NewExposurePopIDs != "", c("ExposerPopIDs", "NewExposurePopIDs")]))
# # 	PostProcs$ExposerData[[j]] <- tmpNarrLog[tmpNarrLog$ExposerPopIDs != "None" & tmpNarrLog$NewExposurePopIDs != "", c("ExposerPopIDs", "NewExposurePopIDs")]
# # 	#get Mean Direct Exposures
# 	
# 	
# 	
# 	
# 	
# 	
# 	
# 	
# 	
# # 	saveRDS(tmpNarrLog, file=sprintf("/tmp/CovidABM7_NarrativePreProc_%s_%03d", ModelNumber, j), compress=FALSE)
# }
# 
# PostProcs$ExposerData <- mclapply(PostProcs$job[2], function (j) PreProcExposures(j), mc.cores=cores)
# print("Exposures PreProcessed")
# 
# 
# PostProcs
# head(PostProcs$ExposerData[[1]])
# head(PostProcs$ExposerData[[2]])
# q()
# 
# Out_pattern = sprintf("CovidABM7_NarrativePreProc_%s", ModelNumber)
# Outfiles = unlist(lapply(Out_pattern, function(x) {list.files(path = "/tmp/", pattern = x)}))
# # print(Out_pattern)
# # print(Outfiles)
# 
# collectNarratives <- function (j) {
# 	print(sprintf("[Anls]          Reading Model Narrative PreProc:%s", Outfiles[j]))
#     fname <- sprintf("%s/%s", "/tmp/", Outfiles[j])
#     tmpNarrLog <- readRDS(file = fname)
# 	return(tmpNarrLog)
# }
# 
# PostProcs$NarrativeData <- lapply(PostProcs$job, function (j) collectNarratives(j))
# 
# print("Narratives Collected")
# 
# PostProcs$writer("NarrativeData")
# 
# print("Narratives Saved")

##########   -   Garbage between here and above
