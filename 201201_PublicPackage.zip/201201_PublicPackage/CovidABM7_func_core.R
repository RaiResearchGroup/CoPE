# CoPE – COVID-19 Policy Evaluation tool
#
# An agent-based model of the social spread of COVID-19 with a focus on 
# individual-level behavioral responses to policy. 
# 
# Thank you for your interest in CoPE. 
# If your use of CoPE results in a publication, please cite as follows: 
# 
# Rai Group. (2020). CoPE: COVID-19 Policy Evaluation tool
# 	 Version 0.1. [Computer Software].
#
# This project is under active development. If you find something that needs our 
# attention, please send a message to BAMEx.devs@gmail.com. 
# Your feedback and input is extremely valuable. Thank you!
#
# 
# CovidABM7 
# UT Austin, RaiGroup
# Created: 06/12/2020
#
# 


#####------------------------#
### MakeTurns Function  
#####------------------------#	
	
MakeTurns = function(simData,dailyData) {

	q <- dailyData$q
	subModelID <- params$subModelID

	dBugMakeTurns(params$JailHouse_ArrivalRate_Esntl)

	dBugMakeTurns(params$JailHouse_ArrivalRate_NonEsntl)

	dBugMakeTurns(head(simData$agentIndex_vec))
	if (params$JailHouse_SymptomBehavior == "SelfIsolateSIP") {
		EsntlAg <- data.frame(ID = simData$agentIndex_vec[(simData$FloutStatus_vec == "Flout" & 
																simData$InfectStatus_vec == "Iy" & 
																simData$FloutStatus_vec != "Quarantine") | 
																(simData$InfectStatus_vec != "Iy" &
																simData$InfectStatus_vec != "Ih" & 
																simData$FloutStatus_vec != "Quarantine")])
	} else if (params$JailHouse_SymptomBehavior == "SelfIsolateAll") {
		EsntlAg <- data.frame(ID = simData$agentIndex_vec[simData$InfectStatus_vec != "Iy" & 
															simData$InfectStatus_vec != "Ih" & 
															simData$FloutStatus_vec != "Quarantine"])
	} else { ### Polite Flout & Rude Flout
		EsntlAg <- data.frame(ID = simData$agentIndex_vec[simData$InfectStatus_vec != "Ih" & 
															simData$FloutStatus_vec != "Quarantine"])
	}
	
	dBugMakeTurns(head(EsntlAg))
	dBugMakeTurns(nrow(EsntlAg))
	
	Adj_EsntlArrivalRate <- (params$JailHouse_ArrivalRate_Esntl*params$Jailhouse_ActivityExposureBalancer)
	dBugMakeTurns(sprintf("Adjusted Esntl Arrival Rate: %f per day",Adj_EsntlArrivalRate))
	
	EsntlAg$Qsum <- 0
	EsntlAg$NE <- -log(1-runif(nrow(EsntlAg), 0, 1))/Adj_EsntlArrivalRate

	dBugMakeTurns(head(EsntlAg))

	Turn_agent_vec <- EsntlAg$ID

	dBugMakeTurns(head(Turn_agent_vec))

	EsntlAg$Qsum <- EsntlAg$Qsum + EsntlAg$NE
	Turn_order_vec <- EsntlAg$Qsum

	EsntlAg$EsntlArrivals <- 1
	Turn_arrival_vec <- EsntlAg$EsntlArrivals

	dBugMakeTurns(head(EsntlAg))
	dBugMakeTurns(min(EsntlAg$Qsum))

	arrivalinc <- 2
	while(min(EsntlAg$Qsum) < 1) {
		EsntlAg$NE <- 0
		EsntlAg$EsntlArrivals[EsntlAg$Qsum < 1] <- arrivalinc
		EsntlAg$NE[EsntlAg$EsntlArrivals == arrivalinc] <- -log(1-runif(sum(EsntlAg$EsntlArrivals == arrivalinc), 0, 1))/Adj_EsntlArrivalRate

		Turn_agent_vec <- c(Turn_agent_vec, EsntlAg$ID[EsntlAg$EsntlArrivals == arrivalinc])
		EsntlAg$Qsum <- EsntlAg$Qsum + EsntlAg$NE
		Turn_order_vec <- c(Turn_order_vec, EsntlAg$Qsum[EsntlAg$EsntlArrivals == arrivalinc])
		Turn_arrival_vec <- c(Turn_arrival_vec, EsntlAg$EsntlArrivals[EsntlAg$EsntlArrivals == arrivalinc])
		arrivalinc <- arrivalinc + 1
	} 

	dBugMakeTurns(min(EsntlAg$Qsum))
	dBugMakeTurns(head(EsntlAg))

	dBugMakeTurns(object.size(EsntlAg))

	dBugMakeTurns(head(Turn_agent_vec))
	dBugMakeTurns(head(Turn_order_vec))
	dBugMakeTurns(head(Turn_arrival_vec))

	EsntlTurns <- as.data.frame(cbind(Turn_agent_vec, Turn_order_vec, Turn_arrival_vec))
	EsntlTurns <- EsntlTurns[order(Turn_order_vec), ]
	EsntlTurns <- EsntlTurns[EsntlTurns$Turn_order_vec < 1, ]
	EsntlTurns$turn <- seq(1, nrow(EsntlTurns))
	EsntlTurns$modeltimecode <-  (q - 1) + EsntlTurns$Turn_order_vec
	EsntlTurns$Turn_order_vec <- NULL
	EsntlTurns$TurnType <- "Essential"


	print(sprintf("[Core]                    Turnlist for essential interactions calculated: %d turns this Day", nrow(EsntlTurns)))


	if ( q <= 0 ) {
		NonEsntlAg <- data.frame(ID = simData$agentIndex_vec)
	} else if ( q > 0 ){
		if (params$JailHouse_SymptomBehavior == "RudeFlout") {
			NonEsntlAg <- data.frame(ID = simData$agentIndex_vec[simData$FloutStatus_vec == "Flout" & 
																	(simData$InfectStatus_vec != "Ih" | 
																	simData$InfectStatus_vec != "Rd")])
		} else if (params$JailHouse_SymptomBehavior == "PoliteFlout") {
			NonEsntlAg <- data.frame(ID = simData$agentIndex_vec[simData$FloutStatus_vec == "Flout" & 
																	(simData$InfectStatus_vec != "Iy" |
																	simData$InfectStatus_vec != "Ih" | 
																	simData$InfectStatus_vec != "Rd")])
		} 		
	} 
	dBugMakeTurns(head(NonEsntlAg))
	dBugMakeTurns(nrow(NonEsntlAg))

	Adj_NonEsntlArrivalRate <- (params$JailHouse_ArrivalRate_NonEsntl*params$Jailhouse_ActivityExposureBalancer)
	dBugMakeTurns(sprintf("Adjusted NonEsntl Arrival Rate: %f per day",Adj_NonEsntlArrivalRate))
	NonEsntlAg$Qsum <- 0
	NonEsntlAg$NE <- -log(1-runif(nrow(NonEsntlAg), 0, 1))/Adj_NonEsntlArrivalRate

	dBugMakeTurns(head(NonEsntlAg))


	Turn_agent_vec <- NonEsntlAg$ID

	dBugMakeTurns(head(Turn_agent_vec))

	NonEsntlAg$Qsum <- NonEsntlAg$Qsum + NonEsntlAg$NE
	Turn_order_vec <- NonEsntlAg$Qsum

	NonEsntlAg$NonEsntlArrivals <- 1
	Turn_arrival_vec <- NonEsntlAg$NonEsntlArrivals

	dBugMakeTurns(head(NonEsntlAg))
	dBugMakeTurns(min(NonEsntlAg$Qsum))

	arrivalinc <- 2
	while(min(NonEsntlAg$Qsum) < 1) {
		NonEsntlAg$NE <- 0
		NonEsntlAg$NonEsntlArrivals[NonEsntlAg$Qsum < 1] <- arrivalinc
		NonEsntlAg$NE[NonEsntlAg$NonEsntlArrivals == arrivalinc] <- -log(1-runif(sum(NonEsntlAg$NonEsntlArrivals == arrivalinc), 0, 1))/Adj_NonEsntlArrivalRate

		Turn_agent_vec <- c(Turn_agent_vec, NonEsntlAg$ID[NonEsntlAg$NonEsntlArrivals == arrivalinc])
		NonEsntlAg$Qsum <- NonEsntlAg$Qsum + NonEsntlAg$NE
		Turn_order_vec <- c(Turn_order_vec, NonEsntlAg$Qsum[NonEsntlAg$NonEsntlArrivals == arrivalinc])
		Turn_arrival_vec <- c(Turn_arrival_vec, NonEsntlAg$NonEsntlArrivals[NonEsntlAg$NonEsntlArrivals == arrivalinc])
		arrivalinc <- arrivalinc + 1
	} 

	dBugMakeTurns(min(NonEsntlAg$Qsum))
	dBugMakeTurns(head(NonEsntlAg))

	dBugMakeTurns(object.size(NonEsntlAg))

	dBugMakeTurns(head(Turn_agent_vec))
	dBugMakeTurns(head(Turn_order_vec))
	dBugMakeTurns(head(Turn_arrival_vec))


	NonEsntlTurns <- as.data.frame(cbind(Turn_agent_vec, Turn_order_vec, Turn_arrival_vec))
	NonEsntlTurns <- NonEsntlTurns[order(Turn_order_vec), ]
	NonEsntlTurns <- NonEsntlTurns[NonEsntlTurns$Turn_order_vec < 1, ]
	NonEsntlTurns$turn <- seq(1, nrow(NonEsntlTurns))
	NonEsntlTurns$modeltimecode <- (q - 1) + NonEsntlTurns$Turn_order_vec
	NonEsntlTurns$Turn_order_vec <- NULL
	NonEsntlTurns$TurnType <- "NonEssential"

	print(sprintf("[Core]                    Turnlist for Non-essential interactions calculated: %d turns this Day", nrow(NonEsntlTurns)))

	if ( q <= 0 ) {
		JobAg <- data.frame(ID = simData$agentIndex_vec)
	} else if ( q > 0 ){
		
			JobAg <- data.frame(ID = simData$agentIndex_vec[dailyData$esntlStatus_vec == "Esntl" &
																simData$FloutStatus_vec != "Quarantine" & 
																simData$InfectStatus_vec != "Iy" &
																simData$InfectStatus_vec != "Ih" & 
																simData$InfectStatus_vec != "Rd"]) 		
	} 
	dBugMakeTurns(head(JobAg))
	dBugMakeTurns(nrow(JobAg))

	Adj_JobArrivalRate <- (params$JailHouse_ArrivalRate_Job*params$Jailhouse_ActivityExposureBalancer)
	dBugMakeTurns(sprintf("Adjusted Job Arrival Rate: %f per day",Adj_JobArrivalRate)) 
		
	JobAg$Qsum <- 0
	JobAg$NE <- -log(1-runif(nrow(JobAg), 0, 1))/Adj_JobArrivalRate

	dBugMakeTurns(head(JobAg))

	Turn_agent_vec <- JobAg$ID

	dBugMakeTurns(head(Turn_agent_vec))

	JobAg$Qsum <- JobAg$Qsum + JobAg$NE
	Turn_order_vec <- JobAg$Qsum

	JobAg$JobArrivals <- 1
	Turn_arrival_vec <- JobAg$JobArrivals

	dBugMakeTurns(head(JobAg))
	dBugMakeTurns(min(JobAg$Qsum))

	arrivalinc <- 2
	while(min(JobAg$Qsum) < 1) {
		JobAg$NE <- 0
		JobAg$JobArrivals[JobAg$Qsum < 1] <- arrivalinc

		JobAg$NE[JobAg$JobArrivals == arrivalinc] <- -log(1-runif(sum(JobAg$JobArrivals == arrivalinc), 0, 1))/Adj_JobArrivalRate

		Turn_agent_vec <- c(Turn_agent_vec, JobAg$ID[JobAg$JobArrivals == arrivalinc])
		JobAg$Qsum <- JobAg$Qsum + JobAg$NE
		Turn_order_vec <- c(Turn_order_vec, JobAg$Qsum[JobAg$JobArrivals == arrivalinc])
		Turn_arrival_vec <- c(Turn_arrival_vec, JobAg$JobArrivals[JobAg$JobArrivals == arrivalinc])
		arrivalinc <- arrivalinc + 1
	} 

	dBugMakeTurns(min(JobAg$Qsum))
	dBugMakeTurns(head(JobAg))

	dBugMakeTurns(object.size(JobAg))

	dBugMakeTurns(head(Turn_agent_vec))
	dBugMakeTurns(head(Turn_order_vec))
	dBugMakeTurns(head(Turn_arrival_vec))

	JobTurns <- as.data.frame(cbind(Turn_agent_vec, Turn_order_vec, Turn_arrival_vec))
	JobTurns <- JobTurns[order(Turn_order_vec), ]
	JobTurns <- JobTurns[JobTurns$Turn_order_vec < 1, ]
	JobTurns$turn <- seq(1, nrow(JobTurns))
	JobTurns$modeltimecode <- (q - 1) + JobTurns$Turn_order_vec
	JobTurns$Turn_order_vec <- NULL
	JobTurns$TurnType <- "Job"

	print(sprintf("[Core]                    Turnlist for Job interactions calculated: %d turns this Day", nrow(JobTurns)))

	MT_Turns <- rbind(EsntlTurns, NonEsntlTurns, JobTurns)
	
	print(sprintf("[Core]                    Turnlist for All interactions calculated: %d turns this Day", nrow(MT_Turns)))
	
	dBugMakeTurns(table(MT_Turns$TurnType, exclude=NULL))
	dBugMakeTurns(table(MT_Turns$TurnType, simData$FloutStatus_vec[MT_Turns$Turn_agent_vec], exclude=NULL))

	if (q == 0 ) { 
		print(sprintf("[Core]          JailHouse Runtime: %d Initial States happen now", length(simData$agents$InfectStatus[simData$agents$initialInfecter == 1]))) 
		
		dBugMakeTurns(table(simData$agents$InfectStatus))

		simData$InfectStatus_vec[simData$agents$initialInfecter == 1] <- as.character(params$Jailhouse_InitialInfectsType)
		PastTurnsEntries <- data.frame(Turn_agent_vec = simData$agentIndex_vec[simData$agents$initialInfecter == 1], 
							Turn_arrival_vec=rep(0, length(simData$InfectStatus_vec[simData$agents$initialInfecter == 1])), 
							turn=rep(0, length(simData$InfectStatus_vec[simData$agents$initialInfecter == 1])), 
							modeltimecode=rep(0, length(simData$InfectStatus_vec[simData$agents$initialInfecter == 1])),
							TurnType=rep(as.character(params$Jailhouse_InitialInfectsType), length(simData$InfectStatus_vec[simData$agents$initialInfecter == 1])), 
							Turn_in_Day=rep(0, length(simData$InfectStatus_vec[simData$agents$initialInfecter == 1])))
		simData$PastTurns <- rbind(simData$PastTurns, PastTurnsEntries)

		dBugMakeTurns(simData$PastTurns)

		dBugMakeTurns(head(simData$InfectStatus_vec))
		dBugMakeTurns(table(simData$InfectStatus_vec, exclude=NULL))

		print(sprintf("[Init]          JailHouse Agent initialization %d states set to status %s, adding progressions", length(simData$InfectStatus_vec[simData$InfectStatus_vec == params$Jailhouse_InitialInfectsType]), params$Jailhouse_InitialInfectsType)) 
		
		dBugMakeTurns(simData$progressions[progressions$agentIndex %in% simData$agentIndex_vec[simData$InfectStatus_vec == params$Jailhouse_InitialInfectsType], ])
		
		if (params$Jailhouse_InitialInfectsType == "E") {
# 			ProgressTurnsTime <- system.time({	
				lapply(simData$agentIndex_vec[simData$agents$initialInfecter == 1], function (i) {
					if (simData$progressions$E2_Pa_or_Py[simData$progressions$agentIndex == i] == "Pa") {
						dBugMakeTurns("Pa")
						ProgressEntries <- data.frame(Turn_agent_vec = rep(simData$progressions$agentIndex[simData$progressions$agentIndex == i], 3), 
							Turn_arrival_vec=1, 
							turn=1, 
							modeltimecode=c(simData$progressions$E_EndTime[simData$progressions$agentIndex == i], 
											simData$progressions$Pa_EndTime[simData$progressions$agentIndex == i], 
											simData$progressions$Ia_EndTime[simData$progressions$agentIndex == i]),
							TurnType=c("Pa","Ia","Rr"), 
							Turn_in_Day=0)
					} else if (simData$progressions$E2_Pa_or_Py[simData$progressions$agentIndex == i] == "Py") {			
						if (simData$progressions$E2_Py2_Rr_or_Ih[simData$progressions$agentIndex == i] == "Rr") {
							dBugMakeTurns("PyIyRr")
							ProgressEntries <- data.frame(Turn_agent_vec=rep(simData$progressions$agentIndex[simData$progressions$agentIndex == i], 3), 
								Turn_arrival_vec=1, 
								turn=1, 
								modeltimecode=c(simData$progressions$E_EndTime[simData$progressions$agentIndex == i], 
												simData$progressions$Py_EndTime[simData$progressions$agentIndex == i], 
												simData$progressions$Iy_Rr_EndTime[simData$progressions$agentIndex == i]),
								TurnType=c("Py","Iy","Rr"), 
								Turn_in_Day=0)
						} else if (simData$progressions$E2_Py2_Rr_or_Ih[simData$progressions$agentIndex == i] == "Ih") {
							if (simData$progressions$E2_Py2_Ih2_Rr_or_Rd[simData$progressions$agentIndex == i] == "Rr") {
								dBugMakeTurns("PyIyIhRr")
								ProgressEntries <- data.frame(Turn_agent_vec=rep(simData$progressions$agentIndex[simData$progressions$agentIndex == i], 4), 
									Turn_arrival_vec=1, 
									turn=1, 
									modeltimecode=c(simData$progressions$E_EndTime[simData$progressions$agentIndex == i],
													simData$progressions$Py_EndTime[simData$progressions$agentIndex == i], 
													simData$progressions$Iy_Ih_EndTime[simData$progressions$agentIndex == i], 
													simData$progressions$Ih_Rr_EndTime[simData$progressions$agentIndex == i]),
									TurnType=c("Py","Iy","Ih", "Rr"), 
									Turn_in_Day=0)
							} else if (simData$progressions$E2_Py2_Ih2_Rr_or_Rd[simData$progressions$agentIndex == i] == "Rd") {
								dBugMakeTurns("PyIyIhRd")
								ProgressEntries <- data.frame(Turn_agent_vec=rep(simData$progressions$agentIndex[simData$progressions$agentIndex == i], 4), 
									Turn_arrival_vec=1, 
									turn=1, 
									modeltimecode=c(simData$progressions$E_EndTime[simData$progressions$agentIndex == i],
													simData$progressions$Py_EndTime[simData$progressions$agentIndex == i], 
													simData$progressions$Iy_Ih_EndTime[simData$progressions$agentIndex == i], 
													simData$progressions$Ih_Rd_EndTime[simData$progressions$agentIndex == i]),
									TurnType=c("Py","Iy","Ih", "Rd"), 
									Turn_in_Day=0)
							}
						}
					}
				dBugMakeTurns(ProgressEntries)
				dBugMakeTurns(head(ProgressEntries))
				dBugMakeTurns(tail(ProgressEntries))
				dBugMakeTurns(nrow(ProgressEntries))
				dBugMakeTurns(nrow(simData$Progress_Turns))
#					ProgressEntries <- rbind(ProgressEntries, tmpProgressEntries)
				simData$Progress_Turns <- rbind(simData$Progress_Turns, ProgressEntries)
				dBugMakeTurns(nrow(simData$Progress_Turns))
				})
# 			}, gcFirst=FALSE)
		} else if (params$Jailhouse_InitialInfectsType == "Pa") {
# 			ProgressTurnsTime <- system.time({	
				lapply(simData$agentIndex_vec[simData$agents$initialInfecter == 1], function (i) {
					if (simData$progressions$E2_Pa_or_Py[simData$progressions$agentIndex == i] == "Pa") {
						ProgressEntries <- data.frame(Turn_agent_vec = rep(simData$progressions$agentIndex[simData$progressions$agentIndex == i], 2), 
							Turn_arrival_vec=1, 
							turn=1, 
							modeltimecode=c(simData$progressions$Pa_EndTime[simData$progressions$agentIndex == i], 
											simData$progressions$Ia_EndTime[simData$progressions$agentIndex == i]),
							TurnType=c("Ia","Rr"), 
							Turn_in_Day=0)
					} else if (simData$progressions$E2_Pa_or_Py[simData$progressions$agentIndex == i] == "Py") {			
						if (simData$progressions$E2_Py2_Rr_or_Ih[simData$progressions$agentIndex == i] == "Rr") {
							ProgressEntries <- data.frame(Turn_agent_vec=rep(simData$progressions$agentIndex[simData$progressions$agentIndex == i], 2), 
								Turn_arrival_vec=1, 
								turn=1, 
								modeltimecode=c(simData$progressions$Py_EndTime[simData$progressions$agentIndex == i], 
												simData$progressions$Iy_Rr_EndTime[simData$progressions$agentIndex == i]),
								TurnType=c("Iy","Rr"), 
								Turn_in_Day=0)
						} else if (simData$progressions$E2_Py2_Rr_or_Ih[simData$progressions$agentIndex == i] == "Ih") {
						if (simData$progressions$E2_Py2_Ih2_Rr_or_Rd[simData$progressions$agentIndex == i] == "Rr") {
								ProgressEntries <- data.frame(Turn_agent_vec=rep(simData$progressions$agentIndex[simData$progressions$agentIndex == i], 3), 
									Turn_arrival_vec=1, 
									turn=1, 
									modeltimecode=c(simData$progressions$Py_EndTime[simData$progressions$agentIndex == i], 
													simData$progressions$Iy_Ih_EndTime[simData$progressions$agentIndex == i], 
													simData$progressions$Ih_Rr_EndTime[simData$progressions$agentIndex == i]),
									TurnType=c("Iy","Ih", "Rr"), 
									Turn_in_Day=0)
							} else if (simData$progressions$E2_Py2_Ih2_Rr_or_Rd[simData$progressions$agentIndex == i] == "Rd") {
								ProgressEntries <- data.frame(Turn_agent_vec=rep(simData$progressions$agentIndex[simData$progressions$agentIndex == i], 3), 
									Turn_arrival_vec=1, 
									turn=1, 
									modeltimecode=c(simData$progressions$Py_EndTime[simData$progressions$agentIndex == i], 
													simData$progressions$Iy_Ih_EndTime[simData$progressions$agentIndex == i], 
													simData$progressions$Ih_Rd_EndTime[simData$progressions$agentIndex == i]),
									TurnType=c("Iy","Ih", "Rd"), 
									Turn_in_Day=0)
							}
						}
					}
				dBugMakeTurns(head(ProgressEntries))
				dBugMakeTurns(tail(ProgressEntries))
				dBugMakeTurns(nrow(ProgressEntries))
				dBugMakeTurns(nrow(simData$Progress_Turns))
#					ProgressEntries <- rbind(ProgressEntries, tmpProgressEntries)
				simData$Progress_Turns <- rbind(simData$Progress_Turns, ProgressEntries)
				dBugMakeTurns(nrow(simData$Progress_Turns))
				})
# 			}, gcFirst=FALSE)

		} else if (params$Jailhouse_InitialInfectsType == "Ia") {
# 			ProgressTurnsTime <- system.time({	
				lapply(simData$agentIndex_vec[simData$agents$initialInfecter == 1], function (i) {
					if (simData$progressions$E2_Pa_or_Py[simData$progressions$agentIndex == i] == "Pa") {
						ProgressEntries <- data.frame(Turn_agent_vec = rep(simData$progressions$agentIndex[simData$progressions$agentIndex == i], 1), 
							Turn_arrival_vec=1, 
							turn=1, 
							modeltimecode=c(simData$progressions$Ia_EndTime[simData$progressions$agentIndex == i]),
							TurnType=c("Rr"), 
							Turn_in_Day=0)
					} else if (simData$progressions$E2_Pa_or_Py[simData$progressions$agentIndex == i] == "Py") {			
						if (simData$progressions$E2_Py2_Rr_or_Ih[simData$progressions$agentIndex == i] == "Rr") {
							ProgressEntries <- data.frame(Turn_agent_vec=rep(simData$progressions$agentIndex[simData$progressions$agentIndex == i], 2), 
								Turn_arrival_vec=1, 
								turn=1, 
								modeltimecode=c(simData$progressions$Py_EndTime[simData$progressions$agentIndex == i], 
												simData$progressions$Iy_Rr_EndTime[simData$progressions$agentIndex == i]),
								TurnType=c("Iy","Rr"), 
								Turn_in_Day=0)
						} else if (simData$progressions$E2_Py2_Rr_or_Ih[simData$progressions$agentIndex == i] == "Ih") {
							if (simData$progressions$E2_Py2_Ih2_Rr_or_Rd[simData$progressions$agentIndex == i] == "Rr") {
								ProgressEntries <- data.frame(Turn_agent_vec=rep(simData$progressions$agentIndex[simData$progressions$agentIndex == i], 3), 
									Turn_arrival_vec=1, 
									turn=1, 
									modeltimecode=c(simData$progressions$Py_EndTime[simData$progressions$agentIndex == i], 
													simData$progressions$Iy_Ih_EndTime[simData$progressions$agentIndex == i], 
													simData$progressions$Ih_Rr_EndTime[simData$progressions$agentIndex == i]),
									TurnType=c("Iy","Ih", "Rr"), 
									Turn_in_Day=0)
							} else if (simData$progressions$E2_Py2_Ih2_Rr_or_Rd[simData$progressions$agentIndex == i] == "Rd") {
								ProgressEntries <- data.frame(Turn_agent_vec=rep(simData$progressions$agentIndex[simData$progressions$agentIndex == i], 3), 
									Turn_arrival_vec=1, 
									turn=1, 
									modeltimecode=c(simData$progressions$Py_EndTime[simData$progressions$agentIndex == i], 
													simData$progressions$Iy_Ih_EndTime[simData$progressions$agentIndex == i], 
													simData$progressions$Ih_Rd_EndTime[simData$progressions$agentIndex == i]),
									TurnType=c("Iy","Ih", "Rd"), 
									Turn_in_Day=0)
							}
						
						}
					}
				dBugMakeTurns(head(ProgressEntries))
				dBugMakeTurns(tail(ProgressEntries))
				dBugMakeTurns(nrow(ProgressEntries))
				dBugMakeTurns(nrow(simData$Progress_Turns))
#					ProgressEntries <- rbind(ProgressEntries, tmpProgressEntries)
				simData$Progress_Turns <- rbind(simData$Progress_Turns, ProgressEntries)
				dBugMakeTurns(nrow(simData$Progress_Turns))
				})
# 			}, gcFirst=FALSE)

		}
# 		dBugMakeTurns(ProgressTurnsTime)


		
		
		simData$Progress_Turns <- simData$Progress_Turns[order(simData$Progress_Turns$Turn_agent_vec, simData$Progress_Turns$modeltimecode),]

		dBugMakeTurns(simData$Progress_Turns)
		dBugMakeTurns(head(simData$Progress_Turns))
		dBugMakeTurns(tail(simData$Progress_Turns))
		dBugMakeTurns(nrow(simData$Progress_Turns))



	} else if (q > 0) { 
		simData$Progress_Turns <- simData$Progress_Turns[order(simData$Progress_Turns$modeltimecode), ]
		dBugMakeTurns(nrow(simData$Progress_Turns))
		dBugMakeTurns(head(simData$Progress_Turns))
		dBugMakeTurns(tail(simData$Progress_Turns))

		dBugMakeTurns("Day (q)")
		dBugMakeTurns(q)

		print(sprintf("[Core]                    Previously Scheduled Progressions dailyData$Turns: %d Total turns", nrow(simData$Progress_Turns)))

		ProgressInsertions <- simData$Progress_Turns[simData$Progress_Turns$modeltimecode <= q, ]
		ProgressInsertions <- ProgressInsertions[order(ProgressInsertions$modeltimecode), ]
		ProgressInsertions$Turn_in_Day <- NULL
		dBugMakeTurns(head(ProgressInsertions))
		dBugMakeTurns(tail(ProgressInsertions))
		dBugMakeTurns(tail(ProgressInsertions))
		dBugMakeTurns(table(ProgressInsertions$TurnType))

#			ProgressInsertions$Turn_order_vec
		print(sprintf("[Core]                    Progressions this Day: %d turns this Day", nrow(ProgressInsertions)))

		dBugMakeTurns("Remove scheduled simData$progressions from simData$Progress_Turns")
		simData$Progress_Turns <- simData$Progress_Turns[simData$Progress_Turns$modeltimecode > q, ]
		simData$Progress_Turns <- simData$Progress_Turns[order(simData$Progress_Turns$modeltimecode), ]
		dBugMakeTurns(nrow(simData$Progress_Turns))
		dBugMakeTurns(head(simData$Progress_Turns))
		dBugMakeTurns(tail(simData$Progress_Turns))
	
		print(sprintf("[Core]                    Progressions left to schedule: %d turns", nrow(simData$Progress_Turns)))

	
		MT_Turns <- rbind(MT_Turns, ProgressInsertions)
	}
	
	MT_Turns <- MT_Turns[order(MT_Turns$modeltimecode), ]
	MT_Turns$Turn_in_Day <- seq(1, nrow(MT_Turns))
	print(sprintf("[Core]                    Turnlist for All new activities calculated: %d turns this Day", nrow(MT_Turns)))
	
	
	dBugMakeTurns(head(MT_Turns))
	dBugMakeTurns(tail(MT_Turns))
	dBugMakeTurns(nrow(MT_Turns))
	dBugMakeTurns(table(MT_Turns$TurnType))
	
	dailyData$Turns <- rbind(dailyData$Turns, MT_Turns)
	print(sprintf("[Core]                    Turnlist for total activities calculated: %d turns", nrow(dailyData$Turns)))
#		[order(dailyData$Turns$Turn_order_vec), ]
	dBugMakeTurns(head(dailyData$Turns))
	dBugMakeTurns(tail(dailyData$Turns))
	dBugMakeTurns(nrow(dailyData$Turns))
} # end of MakeTurns function

#####------------------------#
### TakeTurns Function  
#####------------------------#	
	
TakeTurns = function(simData, dailyData, turn) {
	subModelID <- simData$subModelID
	q <- dailyData$q
	
	TT_JailHouseInfectStatus_vec <- simData$InfectStatus_vec
	dBugTakeTurns(table(TT_JailHouseInfectStatus_vec))
	dBugTakeTurns(table(simData$InfectStatus_vec))
	
	dBugTakeTurns(turn)
	
	dBugTakeTurns(dailyData$Turns_In_Day$modeltimecode[turn])
	
	dBugTakeTurns(dailyData$Turns_In_Day$Turn_agent_vec[turn])
	
	dBugTakeTurns(dailyData$Turns_In_Day$TurnType[turn])

	if (dailyData$Turns_In_Day$TurnType[turn] == "Skip") {
# ----------- Skipped turn		
		dBugTurn("Skip turn")
		dBugTurn(dailyData$Turns_In_Day$modeltimecode[turn])
		
	} else if (dailyData$Turns_In_Day$TurnType[turn] == "Pa") {
# ----------- Progression type turn		
# 		PaTurnTime <- system.time({
			dBugTurn("Progression turn")
			TT_JailHouseInfectStatus_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]] <- "Pa"
# 		},gcFirst=FALSE)
# 		dBugTurn(PaTurnTime)
	} else if (dailyData$Turns_In_Day$TurnType[turn] == "Py") {
# ----------- Progression type turn		
# 		PyTurnTime <- system.time({
			dBugTurn("Progression turn")
			TT_JailHouseInfectStatus_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]] <- "Py"
# 		}, gcFirst=FALSE)
# 		dBugTurn(PyTurnTime)
	} else if (dailyData$Turns_In_Day$TurnType[turn] == "Ia") {
# ----------- Progression type turn		
# 		IaTurnTime <- system.time({
			dBugTurn("Progression turn")
			TT_JailHouseInfectStatus_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]] <- "Ia"
# 		}, gcFirst=FALSE)
# 		dBugTurn(IaTurnTime)
	} else if (dailyData$Turns_In_Day$TurnType[turn] == "Iy") {
# ----------- Progression type turn		
# 		IyTurnTime <- system.time({
			dBugTurn("Progression turn Iy")
			
			
			TT_JailHouseInfectStatus_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]] <- "Iy"
			
			if (dailyData$Turns_In_Day$Turn_agent_vec[turn] %in% dailyData$Turns$Turn_agent_vec[dailyData$Turns$modeltimecode > dailyData$Turns_In_Day$modeltimecode[turn]] ) {
				dBugTurn("Unschedule NonEssential Interaction turns")
				dBugTurn(dailyData$Turns[Turns$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn],])
				
				if (params$JailHouse_SymptomBehavior == "RudeFlout") {
					if (simData$FloutStatus_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]] != "Flout") {
						dailyData$NonEssentialAct_W <<- dailyData$NonEssentialAct_W - nrow(dailyData$Turns_In_Day[Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] & dailyData$Turns_In_Day$TurnType[turn] == "NonEssential",])

						dailyData$Turns_In_Day$TurnType[(dailyData$Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] & (dailyData$Turns_In_Day$TurnType == "NonEssential")) ] <- "Skip"	
					}
					
				} else if (params$JailHouse_SymptomBehavior == "PoliteFlout") {
					dailyData$NonEssentialAct_W <- dailyData$NonEssentialAct_W - nrow(dailyData$Turns_In_Day[Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] & dailyData$Turns_In_Day$TurnType[turn] == "NonEssential",])

					dailyData$Turns_In_Day$TurnType[(dailyData$Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] & (dailyData$Turns_In_Day$TurnType == "NonEssential")) ] <- "Skip"	
				} 		


							
				dBugTurn(dailyData$Turns[Turns$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn],])
			}
# 		}, gcFirst=FALSE)
# 		dBugTurn(IyTurnTime)
	} else if (dailyData$Turns_In_Day$TurnType[turn] == "Ih") {
# ----------- Progression type turn		
# 		IhTurnTime <- system.time({
			dBugTurn("Progression turn Ih")
							
			dBugTurn(dailyData$Turns_In_Day[Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn], ])
			
			TT_JailHouseInfectStatus_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]] <- "Ih"
			if (dailyData$Turns_In_Day$Turn_agent_vec[turn] %in% dailyData$Turns_In_Day$Turn_agent_vec[dailyData$Turns_In_Day$modeltimecode > dailyData$Turns_In_Day$modeltimecode[turn]] ) {
		
				dBugTurn("Unschedule Essential and NonEssential Interaction turns")
		
				dBugTurn(dailyData$Turns_In_Day[dailyData$Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn], ])
				
				dBugTurn(dailyData$Turns_In_Day[dailyData$Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] & dailyData$Turns_In_Day$TurnType == "Essential", ])
				
				dBugTurn(dailyData$Turns_In_Day[dailyData$Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] & dailyData$Turns_In_Day$TurnType == "NonEssential", ])

				dailyData$EssentialAct_W <- dailyData$EssentialAct_W - nrow(dailyData$Turns_In_Day[dailyData$Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] &  dailyData$Turns_In_Day$TurnType == "Essential",])
				dailyData$NonEssentialAct_W <- dailyData$NonEssentialAct_W - nrow(dailyData$Turns_In_Day[dailyData$Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] &  dailyData$Turns_In_Day$TurnType == "NonEssential",])
# 					dBugOneShot('dailyData$Turns[(dailyData$Turns$turn > turn & dailyData$Turns$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] & (dailyData$Turns$TurnType == "Essential" | dailyData$Turns$TurnType == "NonEssential")), ]')
# 					dBugOneShot(dailyData$Turns[(dailyData$Turns$turn > turn & dailyData$Turns$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] & (dailyData$Turns$TurnType == "Essential" | dailyData$Turns$TurnType == "NonEssential")), ])

				dBugTurn(dailyData$Turns_In_Day[(dailyData$Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] & (dailyData$Turns_In_Day$TurnType == "Essential" | dailyData$Turns_In_Day$TurnType == "NonEssential")), ])	

				dailyData$Turns_In_Day$TurnType[(dailyData$Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] & (dailyData$Turns_In_Day$TurnType == "Essential" | dailyData$Turns_In_Day$TurnType == "NonEssential")) ] <- "Skip"	
				
				dBugTurn(dailyData$Turns_In_Day[(dailyData$Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] & (dailyData$Turns_In_Day$TurnType == "Essential" | dailyData$Turns_In_Day$TurnType == "NonEssential")), ])	

				
# 					dBugOneShot('dailyData$Turns[(dailyData$Turns$turn > turn & dailyData$Turns$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] & (dailyData$Turns$TurnType == "Essential" | dailyData$Turns$TurnType == "NonEssential")), ]')
# 					dBugOneShot(dailyData$Turns[(dailyData$Turns$turn > turn & dailyData$Turns$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn] & (dailyData$Turns$TurnType == "Essential" | dailyData$Turns$TurnType == "NonEssential")), ])
				dBugTurn(dailyData$Turns_In_Day[dailyData$Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn], ])

			}
			dBugTurn(dailyData$Turns_In_Day[dailyData$Turns_In_Day$Turn_agent_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn], ])

#	 	}, gcFirst=FALSE)
# 		dBugTurn(IhTurnTime)
	} else if (dailyData$Turns_In_Day$TurnType[turn] == "Rr") {
# ----------- Progression type turn		
# 		RrTurnTime <- system.time({
			dBugTakeTurns("Progression turn")
			TT_JailHouseInfectStatus_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]] <- "Rr"
		
			dBugTurn("Recovered - Resume pattern of interactions")
# 			}, gcFirst=FALSE)
# 		dBugTurn(RrTurnTime)
	} else if (dailyData$Turns_In_Day$TurnType[turn] == "Rd") {
# ----------- Progression type turn		
# 		RdTurnTime <- system.time({
			dBugTurn("Progression turn")
			TT_JailHouseInfectStatus_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]] <- "Rd"
		
			dBugTurn("Died, No new Interaction Scheduled")
# 			}, gcFirst=FALSE)
# 		dBugTurn(RdTurnTime)
	} else if (dailyData$Turns_In_Day$TurnType[turn] == "Essential") { 
		
		Target <- sample(simData$agentIndex_vec[dailyData$esntlStatus_vec == "Esntl"], 1) 
	
		dBugTakeTurns(Target)	
		dBugTakeTurns(TT_JailHouseInfectStatus_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)])

	} else if (dailyData$Turns_In_Day$TurnType[turn] == "NonEssential") { 
		
		dBugTakeTurns(simData$agentIndex_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]])
				
		dBugTakeTurns("Getting friends")
	
		dBugTakeTurns(simData$Alter_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]])
	
		connectIndices = as.numeric(unlist(simData$Alter_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]]))
	
		dBugTakeTurns(connectIndices)
		
		dBugTakeTurns(simData$FloutStatus_vec[connectIndices])
	
		dBugTakeTurns("connectIndices[simData$FloutStatus_vec[connectIndices] == Flout]")
		dBugTakeTurns(connectIndices[simData$FloutStatus_vec[connectIndices] == "Flout"])
	
		CoFloutIndices = connectIndices[simData$FloutStatus_vec[connectIndices] == "Flout"]

		dBugTakeTurns(CoFloutIndices)
		
		dBugTakeTurns("Removing Sick or Dead Friends")
		if ( q > 0 ){
			if (params$JailHouse_SymptomBehavior == "RudeFlout") {
				Inviteds <- CoFloutIndices[simData$InfectStatus_vec[CoFloutIndices] == "S" | simData$InfectStatus_vec[CoFloutIndices] == "Pa" | simData$InfectStatus_vec[CoFloutIndices] == "Py" | simData$InfectStatus_vec[CoFloutIndices] == "Ia" | simData$InfectStatus_vec[CoFloutIndices] == "Iy" | simData$InfectStatus_vec[CoFloutIndices] == "Rr"]
			} else if (params$JailHouse_SymptomBehavior == "PoliteFlout") {
				Inviteds <- CoFloutIndices[simData$InfectStatus_vec[CoFloutIndices] == "S" | simData$InfectStatus_vec[CoFloutIndices] == "Pa" | simData$InfectStatus_vec[CoFloutIndices] == "Py" | simData$InfectStatus_vec[CoFloutIndices] == "Ia" | simData$InfectStatus_vec[CoFloutIndices] == "Rr"]
			} 		
		} 
	Inviteds <- CoFloutIndices[simData$InfectStatus_vec[CoFloutIndices] == "S" | simData$InfectStatus_vec[CoFloutIndices] == "Pa" | simData$InfectStatus_vec[CoFloutIndices] == "Py" | simData$InfectStatus_vec[CoFloutIndices] == "Ia" | simData$InfectStatus_vec[CoFloutIndices] == "Rr"]
		dBugTakeTurns(simData$InfectStatus_vec[Inviteds])
	
	
		if (params$Jailhouse_ApplyGroupThresh == TRUE) {
			dBugTakeTurns("Getting Friends' thresholds")		
	
			dBugTakeTurns(simData$GroupThresh_vec[CoFloutIndices])
	
			NumInvited = min(length(CoFloutIndices), simData$GroupThresh_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]])
	
			PotentialGroupMembers <- CoFloutIndices[simData$GroupThresh_vec[CoFloutIndices] >= NumInvited+1]
	
			dBugTakeTurns(NumInvited+1)	
	
			dBugTakeTurns(PotentialGroupMembers)			
	
			Target <-  sample(PotentialGroupMembers, min(length(PotentialGroupMembers), NumInvited)) 	# Random connection index within agent i's connections
			Target <- Target[order(Target)]
		} else {
			dBugTakeTurns("Applying OWN Group size Threshold")
			
			dBugTakeTurns(Inviteds)
			dBugTakeTurns(length(Inviteds))
			dBugTakeTurns(simData$GroupThresh_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]])
			dBugTakeTurns(min(length(Inviteds), simData$GroupThresh_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]]))						
			Target <- as.numeric(sample(as.character(Inviteds), min(length(Inviteds), simData$GroupThresh_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]]), replace=FALSE)) 
			Target <- Target[order(Target)]
			simData$PrevFloutTargets <- c(simData$PrevFloutTargets, dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)
			simData$PrevFloutTargetTimes <- c(simData$PrevFloutTargetTimes, rep(dailyData$Turns_In_Day$modeltimecode[turn], length(c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target))))
			dBugTakeTurns(Target)				
		}
# 				dBugOneShot("Target")
# 				dBugOneShot(Target)
	} else if (dailyData$Turns_In_Day$TurnType[turn] == "Job") { 
		
		dBugTakeTurns(simData$agentJob_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]])
				
		dBugTakeTurns("Getting coWorkers")
		
		coWorkerIndices = simData$agentIndex_vec[simData$agentJob_vec == simData$agentJob_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]]]
	
		dBugTakeTurns(coWorkerIndices)
				
		dBugTakeTurns("Removing Sick or Dead coWorkers")
		
		coWorking <- coWorkerIndices[simData$InfectStatus_vec[coWorkerIndices] == "S" | simData$InfectStatus_vec[coWorkerIndices] == "Pa" | simData$InfectStatus_vec[coWorkerIndices] == "Py" | simData$InfectStatus_vec[coWorkerIndices] == "Ia" | simData$InfectStatus_vec[coWorkerIndices] == "Rr"]
		
		dBugTakeTurns(simData$InfectStatus_vec[coWorking])
	

			dBugTakeTurns("Applying OWN Group size Threshold")
			
			dBugTakeTurns(coWorking)
			dBugTakeTurns(length(coWorking))
			dBugTakeTurns(simData$GroupThresh_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]])
			dBugTakeTurns(min(length(coWorking), simData$GroupThresh_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]]))						
			Target <- as.numeric(sample(as.character(coWorking), min(length(coWorking), simData$GroupThresh_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]]), replace=FALSE)) 
			Target <- Target[order(Target)]
			simData$PrevCoWorkTargets <- c(simData$PrevCoWorkTargets, dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)
			simData$PrevCoWorkTargetTimes <- c(simData$PrevCoWorkTargetTimes, rep(dailyData$Turns_In_Day$modeltimecode[turn], length(c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target))))
			dBugTakeTurns(Target)				

# 				dBugOneShot("Target")
# 				dBugOneShot(Target)
	}
	
# ----------- Now Expose targets		
				
	if (exists("Target") ) {
		dBugTakeTurns(Target)
		
		dBugTakeTurns(simData$InfectStatus_vec[Target])
		dBugTakeTurns(dailyData$esntlStatus_vec[Target])
		dBugTakeTurns(simData$FloutStatus_vec[Target])	
		
		dBugTakeTurns(simData$agentIndex_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)])
		dBugTakeTurns(TT_JailHouseInfectStatus_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)])
		if (q > 0 & !all(TT_JailHouseInfectStatus_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)] == "S" | TT_JailHouseInfectStatus_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)] == "E" | TT_JailHouseInfectStatus_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)] == "Rr") & "S" %in% TT_JailHouseInfectStatus_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)]) {	

			dBugTakeTurns("POTENTIAL EXPOSURE!")
		
			dBugTakeTurns("Applying PrExposer")
			PotentialExposer_vec <- simData$agentIndex_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)][TT_JailHouseInfectStatus_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)] != "S" & TT_JailHouseInfectStatus_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)] != "E" & TT_JailHouseInfectStatus_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)] != "Rr"]
			dBugTakeTurns(PotentialExposer_vec)
			if (params$Jailhouse_UseAwareness == TRUE & simData$Current_Awareness == 1) {
				Exposer_or_Not_vec <- lapply(PotentialExposer_vec, function (i) {
					BaselinePrExposure <- (params$Jailhouse_PrExposure)
					odds1 <- BaselinePrExposure/(1-BaselinePrExposure)
					dBugTakeTurns(odds1)
					dBugTakeTurns(simData$RiskTol_vec[i])
					dBugTakeTurns(simData$agents$AgeHH[i])
					odds2 <- simData$RiskTol_vec[i]/(1-simData$RiskTol_vec[i])
					dBugTakeTurns(odds2)
					odds3 <- mean(simData$RiskTol_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)])/(1-mean(simData$RiskTol_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)]))
					dBugTakeTurns(odds3)
					totalodds <- odds1*odds2*odds3		
					dBugTakeTurns(totalodds)
					totalPr_Exposer <- (totalodds/(1+totalodds))
					dBugTakeTurns(totalPr_Exposer)
					sample(c(1, 0), 1, replace=TRUE, prob=c(totalPr_Exposer, (1-totalPr_Exposer)))
					})
				dBugTakeTurns(Exposer_or_Not_vec)	
			} else {
				Exposer_or_Not_vec <- lapply(PotentialExposer_vec, function (i) {
						BaselinePrExposure <- (params$Jailhouse_PrExposure)
						sample(c(1, 0), 1, replace=TRUE, prob=c(BaselinePrExposure, (1-BaselinePrExposure)))
						})
				dBugTakeTurns("Exposer_or_Not_vec")
				dBugTakeTurns(Exposer_or_Not_vec)	
				
			}
			Exposer_vec <- PotentialExposer_vec[Exposer_or_Not_vec == 1]
			
			dBugTakeTurns(Exposer_vec)	
			
			if (length(Exposer_vec) > 0) { 	
			
				dBugTakeTurns(Target)
		
				dBugTakeTurns(simData$InfectStatus_vec[Target])
				dBugTakeTurns(dailyData$esntlStatus_vec[Target])
				dBugTakeTurns(simData$FloutStatus_vec[Target])	
		
				dBugTakeTurns(table(TT_JailHouseInfectStatus_vec))

				dBugTakeTurns("dailyData$Turns_In_Day$TurnType[turn]")

				dBugTakeTurns("All interaction Agents")
				dBugTakeTurns(c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target))
				dBugTakeTurns("All interaction Infect Statuses")
				dBugTakeTurns(TT_JailHouseInfectStatus_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)])

				dBugTakeTurns("Applying PrExposed")
				PotentialExposed_vec <- simData$agentIndex_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)][TT_JailHouseInfectStatus_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)] == "S"]
				dBugTakeTurns(PotentialExposed_vec)	
				
					
				if (params$Jailhouse_UseAwareness == TRUE & simData$Current_Awareness == 1) {			
					Exposed_or_Not_vec <- lapply(PotentialExposed_vec, function (i) {
						BaselinePrExposure <- (params$Jailhouse_PrExposure)
						odds1 <- BaselinePrExposure/(1-BaselinePrExposure)
						odds2 <- simData$RiskTol_vec[i]/(1-simData$RiskTol_vec[i])
						if (params$Jailhouse_EventRiskUpdates == "Off") {
							odds3 <- 1
						} else {
							odds3 <- mean(simData$RiskTol_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)])/(1-mean(simData$RiskTol_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)]))
						}
						totalodds <- odds1*odds2*odds3
						totalPr_Exposed <- (totalodds/(1+totalodds))
						sample(c(1, 0), 1, replace=TRUE, prob=c(totalPr_Exposed, (1-totalPr_Exposed)))
						})
					dBugTakeTurns("Exposed_or_Not_vec")
					dBugTakeTurns(Exposed_or_Not_vec)	
				} else {
					Exposed_or_Not_vec <- lapply(PotentialExposed_vec, function (i) {
						BaselinePrExposure <- (params$Jailhouse_PrExposure)
						sample(c(1, 0), 1, replace=TRUE, prob=c(BaselinePrExposure, (1-BaselinePrExposure)))
						})
					dBugTakeTurns("Exposed_or_Not_vec")
					dBugTakeTurns(Exposed_or_Not_vec)	
				}
				newExposed_vec <- PotentialExposed_vec[Exposed_or_Not_vec == 1] 
				dBugTakeTurns(newExposed_vec)	
			
				if (length(newExposed_vec) > 0) { 
			
# 					Exposer_vec <- simData$agentIndex_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)][TT_JailHouseInfectStatus_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)] != "S"]
# 					dBugTakeTurns("Exposer_vec")
# 					dBugTakeTurns(Exposer_vec)
# 		
	
					newDirectExposures <- length(newExposed_vec)/length(Exposer_vec)
					dBugTakeTurns(newDirectExposures)
					simData$DirectExposures_vec[Exposer_vec] <- simData$DirectExposures_vec[Exposer_vec] + newDirectExposures
					
					if (dailyData$Turns_In_Day$TurnType[turn] == "Essential") { 
						simData$EssentialInfects_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]] <- simData$EssentialInfects_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]] + 1 
					}

					if ("Ia" %in% simData$InfectStatus_vec[Exposer_vec]) {
						simData$IaInfects_vec[Exposer_vec] <- simData$IaInfects_vec[Exposer_vec] + newDirectExposures
					}
					if (simData$FloutStatus_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]] == "Flout") { 
						simData$FloutInfects_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]] <- simData$FloutInfects_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]] + length(newExposed_vec)
					}
	
					dBugTakeTurns(table(simData$DirectExposures_vec, exclude=NULL))
					dBugTakeTurns(mean(simData$DirectExposures_vec[JailHouseDirectExposures_vec != 0]))
	
					dBugTakeTurns("Doing Exposing - Scheduling all simData$progressions")
					dBugTakeTurns(TT_JailHouseInfectStatus_vec[newExposed_vec])
			
			
					TT_JailHouseInfectStatus_vec[newExposed_vec] <- "E"
			
			
					dBugTakeTurns(TT_JailHouseInfectStatus_vec[newExposed_vec])

					dailyData$ExposedToday_vec <- c(dailyData$ExposedToday_vec, newExposed_vec)
					dailyData$ExposedTime_vec <- c(dailyData$ExposedTime_vec, rep(dailyData$Turns_In_Day$modeltimecode[turn], length(newExposed_vec)))

					dBugTakeTurns(head(Progress_Turns))
					dBugTakeTurns(tail(Progress_Turns))
					dBugTakeTurns(nrow(Progress_Turns))
				} else {
					dBugTakeTurns("No Actual Exposures")
				}
			}
			dBugTakeTurns("No Actual Exposers")
		}  ####-------END EXPOSURE CHECK	
		dBugTakeTurns(TT_JailHouseInfectStatus_vec[c(dailyData$Turns_In_Day$Turn_agent_vec[turn], Target)])
		dBugTakeTurns("outside")
		dBugTakeTurns(table(TT_JailHouseInfectStatus_vec))
	

	} #### END TARGET > 0 CHECK

	dBugTurn("Activity Turn taken")

	if (params$NarrativeOut == "On") {
		write.table(
			as.matrix(t(c(dailyData$Turns_In_Day$modeltimecode[turn],
				params$Model, 
				params$subModelID,
				params$RuntimeInfectMod,
				params$ModelType,
				dailyData$Turns_In_Day$Turn_agent_vec[turn],
				simData$agentPopID_vec[simData$agentIndex_vec == dailyData$Turns_In_Day$Turn_agent_vec[turn]],
				simData$InfectStatus_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]],				
				dailyData$esntlStatus_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]],
				simData$FloutStatus_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]],
				simData$TestStatus_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]],
				simData$RiskTol_vec[dailyData$Turns_In_Day$Turn_agent_vec[turn]],
				as.character(dailyData$Turns_In_Day$TurnType[turn]),
				if (exists("Target")) {
					Target <- unique(Target[order(Target)])
					c(paste(Target, collapse="-"),
						paste(simData$agentPopID_vec[simData$agentIndex_vec %in% Target], collapse="-"),
						paste(simData$InfectStatus_vec[Target], collapse="-"),
						paste(dailyData$esntlStatus_vec[Target], collapse="-"),
						paste(simData$FloutStatus_vec[Target], collapse="-"),
						paste(simData$TestStatus_vec[Target], collapse="-"),
						paste(simData$RiskTol_vec[Target], collapse="-")
					)
				} else {
					c("None",
						"None",
						"None",
						"None",
						"None",
						"None",
						"None"
					)
				},
				if (length("Exposer_vec") & exists("newExposed_vec")) {
					c(paste(Exposer_vec, collapse="-"),
						paste(simData$agentPopID_vec[simData$agentIndex_vec %in% Exposer_vec], collapse="-"),
						paste(newExposed_vec, collapse="-"),
						paste(simData$agentPopID_vec[simData$agentIndex_vec %in% newExposed_vec], collapse="-")
					)
				} else {
					c("None",
						"None",
						"None",
						"None"
					)
				}
			))), 
		file=sprintf("%s/CovidABM7_NarrativeOuts_%s_job%s.csv", dirname(tempdir()), params$Model, params$job), sep = ",", col.names = FALSE, row.names = FALSE, append=TRUE)


	}


	simData$InfectStatus_vec <- TT_JailHouseInfectStatus_vec
	dBugTakeTurns(table(TT_JailHouseInfectStatus_vec))
	dBugTakeTurns(table(simData$InfectStatus_vec))
} # end of TakeTurns function


JailHouseupdate <- function (simData, q) {

    subModelID <- params$subModelID
    dailyData <- jailhouseDailyDataClass$new()
    dailyData$q <- q

    #####------------------------#
    ### Initialize a Daily environment
    #####------------------------#	
    dBugDay("also, str(q)")
    dBugDay(str(q))
    print(sprintf("[Core]          Updating Day %d environment", q))
    dailyData$EssentialAct_W <- NULL
    dailyData$NonEssentialAct_W <- NULL
    dailyData$ExposedToday_vec <- NULL
    dailyData$ExposedTime_vec <- NULL
    dailyData$Tests_vec <- NULL
    
	simData$Current_Awareness <- tail(simData$Context$Jailhouse_Awareness[simData$Context$modeltime <= q], 1)
	if (params$Jailhouse_UseAwareness == TRUE & simData$Current_Awareness == 1) {
	    #### Update Risk Tolerance
		dBugDay(simData$RiskTol_vec[1:6])	
		dBugDay(summary(simData$RiskTol_vec))
	
		dailyData$sickAlterFrac_vec <- sapply(simData$agentIndex_vec, function (i) {
			allAlters <- length(simData$InfectStatus_vec[as.numeric(unlist(simData$Alter_vec[i]))])
			IyAlters <- length(simData$InfectStatus_vec[as.numeric(unlist(simData$Alter_vec[i]))][simData$InfectStatus_vec[as.numeric(unlist(simData$Alter_vec[i]))] == "Iy"])
			IhAlters <- length(simData$InfectStatus_vec[as.numeric(unlist(simData$Alter_vec[i]))][simData$InfectStatus_vec[as.numeric(unlist(simData$Alter_vec[i]))] == "Ih"])
			sickAlterFrac <- (IyAlters + IhAlters)/allAlters
			return(sickAlterFrac)
		})

	if (params$Jailhouse_DifferentRiskTols == "Off_Young") {
		simData$RiskTol_vec <- exp(params$Jailhouse_Risk_b0 + 
											params$Jailhouse_Risk_b1*min(simData$agents$AgeHH) + 
	#										params$Jailhouse_Risk_b2*I(simData$agents$AgeHH^2) + 
											params$Jailhouse_Risk_b3*dailyData$sickAlterFrac_vec)/(1+exp(params$Jailhouse_Risk_b0 + 
																							params$Jailhouse_Risk_b1*min(simData$agents$AgeHH) + 
	#																						params$Jailhouse_Risk_b2*I(simData$agents$AgeHH^2) + 
																							params$Jailhouse_Risk_b3*dailyData$sickAlterFrac_vec))
	} else if (params$Jailhouse_DifferentRiskTols == "Off_Old") {
		simData$RiskTol_vec <- exp(params$Jailhouse_Risk_b0 + 
											params$Jailhouse_Risk_b1*max(simData$agents$AgeHH) + 
	#										params$Jailhouse_Risk_b2*I(simData$agents$AgeHH^2) + 
											params$Jailhouse_Risk_b3*dailyData$sickAlterFrac_vec)/(1+exp(params$Jailhouse_Risk_b0 + 
																							params$Jailhouse_Risk_b1*max(simData$agents$AgeHH) + 
	#																						params$Jailhouse_Risk_b2*I(simData$agents$AgeHH^2) + 
																							params$Jailhouse_Risk_b3*dailyData$sickAlterFrac_vec))
	} else if (params$Jailhouse_DifferentRiskTols == "On_Rand") {
		
		simData$RiskTol_vec <- exp(params$Jailhouse_Risk_b0 + 
											params$Jailhouse_Risk_b1*round((abs(simData$RandomStable_vec)*0.5) * (max(simData$agents$AgeHH) - min(simData$agents$AgeHH)) + min(simData$agents$AgeHH), 0) + 
	#										params$Jailhouse_Risk_b2*I(simData$agents$AgeHH^2) + 
											params$Jailhouse_Risk_b3*dailyData$sickAlterFrac_vec)/(1+exp(params$Jailhouse_Risk_b0 + 
																							params$Jailhouse_Risk_b1*round((abs(simData$RandomStable_vec)*0.5) * (max(simData$agents$AgeHH) - min(simData$agents$AgeHH)) + min(simData$agents$AgeHH), 0) + 
	#																						params$Jailhouse_Risk_b2*I(simData$agents$AgeHH^2) + 
																							params$Jailhouse_Risk_b3*dailyData$sickAlterFrac_vec))
	} else {
		simData$RiskTol_vec <- exp(params$Jailhouse_Risk_b0 + 
											params$Jailhouse_Risk_b1*simData$agents$AgeHH + 
	#										params$Jailhouse_Risk_b2*I(simData$agents$AgeHH^2) + 
											params$Jailhouse_Risk_b3*dailyData$sickAlterFrac_vec)/(1+exp(params$Jailhouse_Risk_b0 + 
																							params$Jailhouse_Risk_b1*simData$agents$AgeHH + 
	#																						params$Jailhouse_Risk_b2*I(simData$agents$AgeHH^2) + 
																							params$Jailhouse_Risk_b3*dailyData$sickAlterFrac_vec))
	}

		dBugDay(simData$RiskTol_vec[1:6])	
		dBugDay(summary(simData$RiskTol_vec[dailyData$sickAlterFrac_vec == 0]))	
		dBugDay(summary(simData$RiskTol_vec[dailyData$sickAlterFrac_vec != 0]))	
		dBugDay(head(simData$agentIndex_vec[dailyData$sickAlterFrac_vec != 0]))
		dBugDay(head(simData$RiskTol_vec[dailyData$sickAlterFrac_vec != 0]))
		simData$GroupThresh_vec <- round(simData$RiskTol_vec * rpois(n=length(simData$RiskTol_vec), lambda = params$Jailhouse_GroupThreshMax), 0)
		simData$GroupThresh_vec[simData$GroupThresh_vec <= 1] <- 2
		dBugDay(table(simData$FloutStatus_vec, exclude=NULL))
		dBugDay(table(simData$GroupThresh_vec, exclude=NULL))
		dBugDay(length(simData$FloutStatus_vec))
		dBugDay(length(simData$GroupThresh_vec))
		dBugDay(table(simData$FloutStatus_vec, simData$GroupThresh_vec, exclude=NULL))

    }  
    print("[Core]          Getting Current Essential Assignments")
    Current_Esntl_Rate <- tail(simData$Context$Jailhouse_Esntl_Rate[simData$Context$modeltime <= q], 1)
    dBugDay(Current_Esntl_Rate)
    
    if (params$Jailhouse_EsntlAssign == "Income") { 	
        simData$agents$Pr_Esntl <- simData$RandomStable_vec*0.000000001 + exp(params$Jailhouse_Esntl_b0 + params$Jailhouse_Esntl_b1*simData$agents$IncomeHH + params$Jailhouse_Esntl_b2*I(simData$agents$IncomeHH^2))/(1+exp(params$Jailhouse_Esntl_b0 + params$Jailhouse_Esntl_b1*simData$agents$IncomeHH + params$Jailhouse_Esntl_b2*I(simData$agents$IncomeHH^2)))
        dBugDay("plot(simData$agents$IncomeHH, simData$agents$Pr_Esntl)")
    #	dBugDay(plot(simData$agents$IncomeHH, simData$agents$Pr_Esntl))
        simData$agents$Esntl <- "NonEsntl"
        simData$agents$Esntl[simData$agents[order(-simData$agents$Pr_Esntl), c("agentIndex","Pr_Esntl")][1:(round(Current_Esntl_Rate*nrow(simData$agents), 0)), c("agentIndex") ]] = "Esntl"
        simData$agents$Esntl[simData$FloutStatus_vec == "Quarantine"] <- "NonEsntl"
        
        dailyData$esntlStatus_vec <- simData$agents$Esntl
        dBugDay(table(dailyData$esntlStatus_vec, simData$FloutStatus_vec, exclude=NULL))
    } else if (params$Jailhouse_EsntlAssign == "Job") {
        EsntlJobs_string <- tail(simData$Context$Jailhouse_Esntl_Jobs[simData$Context$modeltime <= q], 1)
        EsntlJobs_vec <- as.character(as.list(strsplit(as.character(EsntlJobs_string), ";"))[[1]])
        
        dBugDay(EsntlJobs_vec)
        simData$agents$Esntl <- "NonEsntl"
        simData$agents$Esntl[simData$agents$OccupationHH %in% EsntlJobs_vec] = "Esntl"
# 		simData$agents$Esntl[simData$FloutStatus_vec == "Quarantine"] <- "NonEsntl"
        
        dailyData$esntlStatus_vec <- simData$agents$Esntl
        dBugDay(table(dailyData$esntlStatus_vec, simData$FloutStatus_vec, exclude=NULL))		
        
    }
    
    print("[Core]          Checking for testing")
    DailyTests <- tail(simData$Context$Jailhouse_DailyTests[simData$Context$modeltime <= q], 1)
    if (params$Jailhouse_TestStrategy == "Random" & DailyTests > 0) {
        print(sprintf("[Core]          Testing %d today with strategy: %s",DailyTests, params$Jailhouse_TestStrategy) )
        
        dailyData$Tests_vec <- sample(simData$agentIndex_vec, DailyTests, replace=FALSE)
        
        Positives <- dailyData$Tests_vec[simData$InfectStatus_vec[dailyData$Tests_vec] == "Ia" | simData$InfectStatus_vec[dailyData$Tests_vec] == "Iy"]
        Negatives <- dailyData$Tests_vec[simData$InfectStatus_vec[dailyData$Tests_vec] == "S" | simData$InfectStatus_vec[dailyData$Tests_vec] == "E"]
        simData$TestStatus_vec[Positives] <- sample(c("Positive", "Negative"), length(Positives), replace = TRUE, prob=c((1-params$Jailhouse_TestFN), params$Jailhouse_TestFN))
        simData$TestStatus_vec[Negatives] <- sample(c("Positive", "Negative"), length(Negatives), replace = TRUE, prob=c(params$Jailhouse_TestFP, (1-params$Jailhouse_TestFP)))
        dBugDay(table(simData$InfectStatus_vec, simData$TestStatus_vec, exclude=NULL))
    
    } else if (params$Jailhouse_TestStrategy == "Essential" & DailyTests > 0) {
        print(sprintf("[Core]          Testing %d today with strategy: %s",DailyTests, params$Jailhouse_TestStrategy) )
        
        dailyData$Tests_vec <- sample(simData$agentIndex_vec[dailyData$esntlStatus_vec == "Esntl"], DailyTests, replace=FALSE)
        
        Positives <- dailyData$Tests_vec[simData$InfectStatus_vec[dailyData$Tests_vec] == "Ia" | simData$InfectStatus_vec[dailyData$Tests_vec] == "Iy"]
        Negatives <- dailyData$Tests_vec[simData$InfectStatus_vec[dailyData$Tests_vec] == "S" | simData$InfectStatus_vec[dailyData$Tests_vec] == "E"]
        simData$TestStatus_vec[Positives] <- sample(c("Positive", "Negative"), length(Positives), replace = TRUE, prob=c((1-params$Jailhouse_TestFN), params$Jailhouse_TestFN))
        simData$TestStatus_vec[Negatives] <- sample(c("Positive", "Negative"), length(Negatives), replace = TRUE, prob=c(params$Jailhouse_TestFP, (1-params$Jailhouse_TestFP)))
        dBugDay(table(simData$InfectStatus_vec, simData$TestStatus_vec, exclude=NULL))
        dBugDay(table(simData$TestStatus_vec, dailyData$esntlStatus_vec, exclude=NULL))
    
    } else if (params$Jailhouse_TestStrategy == "Flout" & DailyTests > 0) {
                
        PreviousFloutTargetTimes_limited <- simData$PrevFloutTargetTimes[PreviousFloutTargetTimes > q - 1 - params$Jailhouse_TestStrategyParam]
        PreviousFloutTargets_limited <- simData$PrevFloutTargets[simData$PrevFloutTargetTimes > q - 1 - params$Jailhouse_TestStrategyParam]

        FloutGroups <- as.numeric(as.factor(PreviousFloutTargetTimes_limited))
        FloutGroups_df <- data.frame(table(as.numeric(as.factor(PreviousFloutTargetTimes_limited))))
        FloutGroups_df$randomOrder <- runif(nrow(FloutGroups_df), 0, 1)
        FloutGroups_df <- FloutGroups_df[order(FloutGroups_df$randomOrder), ]
        FloutGroups_df$cumFlouts <- cumsum(FloutGroups_df$Freq)
        dailyData$Tests_vec <- PreviousFloutTargets_limited[FloutGroups %in% FloutGroups_df$Var1[FloutGroups_df$cumFlouts <= DailyTests]]
                
        print(sprintf("[Core]          Testing %d today with strategy: %s", length(dailyData$Tests_vec), params$Jailhouse_TestStrategy) )
        print(sprintf("[Core]          Flouting occurred in previous %d days", params$Jailhouse_TestStrategyParam) )
        
        Positives <- dailyData$Tests_vec[simData$InfectStatus_vec[dailyData$Tests_vec] == "Ia" | simData$InfectStatus_vec[dailyData$Tests_vec] == "Iy"]
        Negatives <- dailyData$Tests_vec[simData$InfectStatus_vec[dailyData$Tests_vec] == "S" | simData$InfectStatus_vec[dailyData$Tests_vec] == "E"]
        simData$TestStatus_vec[Positives] <- sample(c("Positive", "Negative"), length(Positives), replace = TRUE, prob=c((1-params$Jailhouse_TestFN), params$Jailhouse_TestFN))
        simData$TestStatus_vec[Negatives] <- sample(c("Positive", "Negative"), length(Negatives), replace = TRUE, prob=c(params$Jailhouse_TestFP, (1-params$Jailhouse_TestFP)))
        dBugDay(table(simData$InfectStatus_vec, simData$TestStatus_vec, exclude=NULL))
        dBugDay(table(simData$TestStatus_vec, dailyData$esntlStatus_vec, exclude=NULL))
    } else if (params$Jailhouse_TestStrategy == "RandomLocation" & DailyTests > 0) {
        
         tractbg_df <- data.frame(table(simData$agents$tractbg))
        tractbg_df$randomOrder <- runif(nrow(tractbg_df), 0, 1)
        tractbg_df <- tractbg_df[order(tractbg_df$randomOrder), ]
        tractbg_df$cumInBG <- cumsum(tractbg_df$Freq)
        dailyData$Tests_vec <- simData$agents$agentIndex[simData$agents$tractbg %in% tractbg_df$Var1[tractbg_df$cumInBG <= DailyTests]]
    
        dBugDay(head(dailyData$Tests_vec))
            
        print(sprintf("[Core]          Testing %d today with strategy: %s", length(dailyData$Tests_vec), params$Jailhouse_TestStrategy) )
        print(sprintf("[Core]          Testing BGs: %s", paste(unique(tractbg_df$Var1[tractbg_df$cumInBG <= DailyTests]), collapse=", ")))
                
        Positives <- dailyData$Tests_vec[simData$InfectStatus_vec[dailyData$Tests_vec] == "Ia" | simData$InfectStatus_vec[dailyData$Tests_vec] == "Iy"]
        Negatives <- dailyData$Tests_vec[simData$InfectStatus_vec[dailyData$Tests_vec] == "S" | simData$InfectStatus_vec[dailyData$Tests_vec] == "E"]
        simData$TestStatus_vec[Positives] <- sample(c("Positive", "Negative"), length(Positives), replace = TRUE, prob=c((1-params$Jailhouse_TestFN), params$Jailhouse_TestFN))
        simData$TestStatus_vec[Negatives] <- sample(c("Positive", "Negative"), length(Negatives), replace = TRUE, prob=c(params$Jailhouse_TestFP, (1-params$Jailhouse_TestFP)))
        dBugDay(table(simData$InfectStatus_vec, simData$TestStatus_vec, exclude=NULL))
        dBugDay(table(simData$TestStatus_vec, dailyData$esntlStatus_vec, exclude=NULL))
    } else if (params$Jailhouse_TestStrategy == "IaOnly" & DailyTests > 0) {
        
        dBugDay("head(simData$PastTurns[PastTurns$TurnType == Ia & simData$PastTurns$modeltimecode > q - 1 - params$Jailhouse_TestStrategyParam & simData$PastTurns$modeltimecode <= q - params$Jailhouse_TestStrategyParam, ])")
        dBugDay(head(simData$PastTurns[PastTurns$TurnType == "Ia" & simData$PastTurns$modeltimecode > q - 1 - params$Jailhouse_TestStrategyParam & simData$PastTurns$modeltimecode <= q - params$Jailhouse_TestStrategyParam, ]))
        dBugDay("tail(simData$PastTurns[PastTurns$TurnType == Ia & simData$PastTurns$modeltimecode > q - 1 - params$Jailhouse_TestStrategyParam & simData$PastTurns$modeltimecode <= q - params$Jailhouse_TestStrategyParam, ])")
        dBugDay(tail(simData$PastTurns[PastTurns$TurnType == "Ia" & simData$PastTurns$modeltimecode > q - 1 - params$Jailhouse_TestStrategyParam & simData$PastTurns$modeltimecode <= q - params$Jailhouse_TestStrategyParam, ]))
        
        dailyData$Tests_vec <- sample(simData$PastTurns$Turn_agent_vec[simData$PastTurns$TurnType == "Ia" & simData$PastTurns$modeltimecode > q - 1 - params$Jailhouse_TestStrategyParam & simData$PastTurns$modeltimecode <= q - params$Jailhouse_TestStrategyParam], 
                        min(DailyTests,length(simData$PastTurns$Turn_agent_vec[simData$PastTurns$TurnType == "Ia" & simData$PastTurns$modeltimecode > q - 1 - params$Jailhouse_TestStrategyParam & simData$PastTurns$modeltimecode <= q - params$Jailhouse_TestStrategyParam])), replace=FALSE)
    
        dBugDay(head(dailyData$Tests_vec))
            
        print(sprintf("[Core]          Testing %d today with strategy: %s and a %d day delay", length(dailyData$Tests_vec), params$Jailhouse_TestStrategy, params$Jailhouse_TestStrategyParam) )
                
        Positives <- dailyData$Tests_vec[simData$InfectStatus_vec[dailyData$Tests_vec] == "Ia" | simData$InfectStatus_vec[dailyData$Tests_vec] == "Iy"]
        Negatives <- dailyData$Tests_vec[simData$InfectStatus_vec[dailyData$Tests_vec] == "S" | simData$InfectStatus_vec[dailyData$Tests_vec] == "E"]
        simData$TestStatus_vec[Positives] <- sample(c("Positive", "Negative"), length(Positives), replace = TRUE, prob=c((1-params$Jailhouse_TestFN), params$Jailhouse_TestFN))
        simData$TestStatus_vec[Negatives] <- sample(c("Positive", "Negative"), length(Negatives), replace = TRUE, prob=c(params$Jailhouse_TestFP, (1-params$Jailhouse_TestFP)))
        dBugDay(table(simData$TestStatus_vec, simData$InfectStatus_vec, exclude=NULL))
        dBugDay(table(simData$TestStatus_vec, dailyData$esntlStatus_vec, exclude=NULL))
    }
    print("[Core]          Checking for tracing")
    if (params$Jailhouse_TraceStrategy == "Neighbors" & DailyTests > 0) {
        TestPositive_vec <- simData$agentIndex_vec[simData$agentIndex_vec %in% dailyData$Tests_vec & simData$TestStatus_vec == "Positive"] 
        dBugDay(TestPositive_vec)
        TraceCandidates_vec <- as.numeric(unlist(simData$Alter_vec[TestPositive_vec]))
        dBugDay(TraceCandidates_vec)
        Trace_vec <- sample(TraceCandidates_vec, min(params$Jailhouse_TraceStrategyParam, length(TraceCandidates_vec)), replace = FALSE)
        
        print(sprintf("[Core]          Tracing and Testing %d of %d Neighbors of Positive Tests", length(Trace_vec), length(TraceCandidates_vec)) )

        Positives <- Trace_vec[simData$InfectStatus_vec[Trace_vec] == "Ia" | simData$InfectStatus_vec[Trace_vec] == "Iy"]
        Negatives <- Trace_vec[simData$InfectStatus_vec[Trace_vec] == "S" | simData$InfectStatus_vec[Trace_vec] == "E"]
        simData$TestStatus_vec[Positives] <- sample(c("Positive", "Negative"), length(Positives), replace = TRUE, prob=c((1-params$Jailhouse_TestFN), params$Jailhouse_TestFN))
        simData$TestStatus_vec[Negatives] <- sample(c("Positive", "Negative"), length(Negatives), replace = TRUE, prob=c(params$Jailhouse_TestFP, (1-params$Jailhouse_TestFP)))
        dailyData$Tests_vec <- c(dailyData$Tests_vec, Trace_vec)
    } else if (params$Jailhouse_TraceStrategy == "Previous" & DailyTests > 0) {
        TestPositive_vec <- simData$agentIndex_vec[simData$agentIndex_vec %in% dailyData$Tests_vec & simData$TestStatus_vec == "Positive"] 
        dBugDay(TestPositive_vec)
        
        dBugDay(head(simData$PastTurns[PastTurns$modeltimecode > q - 1 - params$Jailhouse_TestStrategyParam & simData$PastTurns$modeltimecode <= q - params$Jailhouse_TestStrategyParam, ]))

        
        
        
        TraceCandidates_vec <- as.numeric(unlist(simData$Alter_vec[TestPositive_vec]))
        dBugDay(TraceCandidates_vec)
        Trace_vec <- sample(TraceCandidates_vec, min(params$Jailhouse_TraceStrategyParam, length(TraceCandidates_vec)), replace = FALSE)
        
        print(sprintf("[Core]          Tracing and Testing 100 of %d Contacts of Positive Tests in past 1 day", length(TraceCandidates_vec), params$Jailhouse_TraceStrategyParam) )

        Positives <- Trace_vec[simData$InfectStatus_vec[Trace_vec] == "Ia" | simData$InfectStatus_vec[Trace_vec] == "Iy"]
        Negatives <- Trace_vec[simData$InfectStatus_vec[Trace_vec] == "S" | simData$InfectStatus_vec[Trace_vec] == "E"]
        simData$TestStatus_vec[Positives] <- sample(c("Positive", "Negative"), length(Positives), replace = TRUE, prob=c((1-params$Jailhouse_TestFN), params$Jailhouse_TestFN))
        simData$TestStatus_vec[Negatives] <- sample(c("Positive", "Negative"), length(Negatives), replace = TRUE, prob=c(params$Jailhouse_TestFP, (1-params$Jailhouse_TestFP)))
        dailyData$Tests_vec <- c(dailyData$Tests_vec, Trace_vec)
    }

    dBugDay(head(dailyData$Tests_vec))
#Enter Quarantine
    simData$FloutStatus_vec[simData$agentIndex_vec %in% dailyData$Tests_vec & simData$TestStatus_vec == "Positive" & !(simData$InfectStatus_vec == "Rr")] <- "Quarantine"
#Schedule a time to exit Quarantine
	simData$QuarantineTill_vec[simData$agentIndex_vec %in% dailyData$Tests_vec & simData$TestStatus_vec == "Positive" & !(simData$InfectStatus_vec == "Rr")] <- q + params$JailHouse_QuarantineDays

	dBugDay(table(simData$FloutStatus_vec, simData$QuarantineTill_vec))

	if (params$Jailhouse_TestStrategy != "Off" & DailyTests > 0) {
		print(sprintf("[Core]          Cumulative Testing: %d T +ives & %d F +ives. T -ives: %d, F -ives: %d", 
			length(simData$TestStatus_vec[simData$TestStatus_vec == "Positive" & (simData$InfectStatus_vec == "Ia" | simData$InfectStatus_vec == "Iy")]), 
			length(simData$TestStatus_vec[simData$TestStatus_vec == "Positive" & (simData$InfectStatus_vec == "S" | simData$InfectStatus_vec == "E")]), 
			length(simData$TestStatus_vec[simData$TestStatus_vec == "Negative" & (simData$InfectStatus_vec == "S" | simData$InfectStatus_vec == "E")]), 
			length(simData$TestStatus_vec[simData$TestStatus_vec == "Negative" & (simData$InfectStatus_vec == "Ia" | simData$InfectStatus_vec == "Iy")])))
		print(sprintf("[Core]          In Quarantine this AM: %d, leaving this AM: %d", length(simData$FloutStatus_vec[simData$FloutStatus_vec == "Quarantine"]), length(simData$FloutStatus_vec[simData$FloutStatus_vec == "Quarantine" & simData$QuarantineTill_vec <= q])))
	}



	print("[Core]          Updating Activity Status...")
	Current_Flout_Rate <- tail(simData$Context$Jailhouse_Flout_Rate[simData$Context$modeltime <= q], 1)
	dBugDay(Current_Flout_Rate)
	
#	simData$agents$Pr_Flout <- simData$RiskTol_vec 
#	simData$agents$RandomStable_vec <- simData$RandomStable_vec
#	simData$agents$Flout <- "SIP"

	simData$FloutStatus_vec <- rep("SIP", nrow(simData$agents))
	
	dBugDay(simData)
	dBugDay(head(simData$agents))
	
	dBugDay(head(simData$RiskTol_vec))
	dBugDay(head(simData$RandomStable_vec))
	
	simData$FloutStatus_vec[order(-simData$RiskTol_vec,simData$RandomStable_vec)][1:(round(Current_Flout_Rate*nrow(simData$agents), 0))] = "Flout"
	simData$agents$FloutStatus_vec[simData$QuarantineTill_vec > q] <- "Quarantine"
	
#	simData$FloutStatus_vec <- simData$agents$Flout
	
	dBugDay(table(simData$FloutStatus_vec))
	dBugDay(mean(simData$RiskTol_vec[simData$FloutStatus_vec == "Flout"]))
	dBugDay(mean(simData$RiskTol_vec[simData$FloutStatus_vec != "Flout"]))
	
	dBugDay(length(simData$TestStatus_vec))
	dBugDay(length(simData$InfectStatus_vec))
	dBugDay(table(simData$TestStatus_vec, simData$InfectStatus_vec, exclude=NULL))
	dBugOneShot(table(simData$FloutStatus_vec, simData$InfectStatus_vec, exclude=NULL))
	dBugDay(table(simData$FloutStatus_vec, simData$TestStatus_vec, exclude=NULL))

	print(sprintf("[Core]          Currently %d Essential Employees & %d Flouters", length(dailyData$esntlStatus_vec[dailyData$esntlStatus_vec == "Esntl"]), length(simData$FloutStatus_vec[simData$FloutStatus_vec == "Flout"])))
	
	dBugDay("SOLVED - Carryover Leftover dailyData$Turns to beginning of Day")
	dBugDay(head(dailyData$Turns))
	dBugDay(tail(dailyData$Turns))
	dBugDay(nrow(dailyData$Turns))
	
	if ( q > 0 ) { 
		simData$Progress_Turns <- simData$Progress_Turns[order(simData$Progress_Turns$modeltimecode), ]
		dBugDay(head(simData$Progress_Turns))
		dBugDay(tail(simData$Progress_Turns))
		dBugDay(nrow(simData$Progress_Turns))
	}

	MakeTurnsTime <- MakeTurns(simData,dailyData)
# 	dBugOneShot(MakeTurnsTime)
		
	dailyData$EssentialAct_W <-  nrow(dailyData$Turns[dailyData$Turns$TurnType == "Essential",])
	dailyData$NonEssentialAct_W <- nrow(dailyData$Turns[dailyData$Turns$TurnType == "NonEssential",])
	
	dailyData$Turns <- dailyData$Turns[order(dailyData$Turns$modeltimecode), ]

	dBugDay("CHECK - for Carryover Leftover dailyData$Turns")
	dBugDay(head(dailyData$Turns))
	dBugDay(tail(dailyData$Turns))
	dBugDay(nrow(dailyData$Turns))

	#####------------------------#
	### Step through a Day
	#####------------------------#	
	dailyData$Turns_In_Day <- NULL
	dailyData$Turns_In_Day <- dailyData$Turns[dailyData$Turns$modeltimecode <= q, ]

	dBugDay("Move dailyData$Turns_In_Day from dailyData$Turns to simData$PastTurns") 
	simData$PastTurns <- rbind(simData$PastTurns, dailyData$Turns[dailyData$Turns$modeltimecode <= q, ])
	dailyData$Turns <- dailyData$Turns[dailyData$Turns$modeltimecode > q, ]


	TakeTurnsTime <- lapply(seq(1, nrow(dailyData$Turns_In_Day)), function(turn) TakeTurns(simData,dailyData,turn))
# 	dBugOneShot(TakeTurnsTime)

	dBugTakeTurns(dailyData$NonEssentialAct_W)
	dBugTakeTurns(dailyData$EssentialAct_W)
	
	print(sprintf("[Core]          New Exposures today: %d", length(dailyData$ExposedToday_vec)))
	dBugTakeTurns(head(dailyData$ExposedToday_vec))
	
	dBugTakeTurns(length(dailyData$ExposedTime_vec))	
	dBugTakeTurns(head(dailyData$ExposedTime_vec))

	if (length(dailyData$ExposedToday_vec) > 0 ) {
#	ProgressTurnsTime <- system.time({	
		lapply(seq(1, length(dailyData$ExposedToday_vec)), function (i) {			
			dBugDay(i)
			dBugDay(simData$progressions[progressions$agentIndex == dailyData$ExposedToday_vec[i], ])
			if (simData$progressions$E2_Pa_or_Py[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]] == "Pa") {
				ProgressEntries <- data.frame(Turn_agent_vec=rep(simData$progressions$agentIndex[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 3), 
					Turn_arrival_vec=1, 
					turn=1, 
					modeltimecode=c(dailyData$ExposedTime_vec[i] + simData$progressions$E_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 
									dailyData$ExposedTime_vec[i] + simData$progressions$Pa_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 
									dailyData$ExposedTime_vec[i] + simData$progressions$Ia_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]]),
					TurnType=c("Pa","Ia","Rr"), 
					Turn_in_Day=0)
			} else if (simData$progressions$E2_Pa_or_Py[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]] == "Py") {			
				if (simData$progressions$E2_Py2_Rr_or_Ih[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]] == "Rr") {
					ProgressEntries <- data.frame(Turn_agent_vec=rep(simData$progressions$agentIndex[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 3), 
						Turn_arrival_vec=1, 
						turn=1, 
						modeltimecode=c(dailyData$ExposedTime_vec[i] + simData$progressions$E_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 
										dailyData$ExposedTime_vec[i] + simData$progressions$Py_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 
										dailyData$ExposedTime_vec[i] + simData$progressions$Iy_Rr_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]]),
						TurnType=c("Py","Iy","Rr"), 
						Turn_in_Day=0)
				} else if (simData$progressions$E2_Py2_Rr_or_Ih[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]] == "Ih") {
					if (simData$progressions$E2_Py2_Ih2_Rr_or_Rd[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]] == "Rr") {
						ProgressEntries <- data.frame(Turn_agent_vec=rep(simData$progressions$agentIndex[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 4), 
							Turn_arrival_vec=1, 
							turn=1, 
							modeltimecode=c(dailyData$ExposedTime_vec[i] + simData$progressions$E_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 
											dailyData$ExposedTime_vec[i] + simData$progressions$Py_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 
											dailyData$ExposedTime_vec[i] + simData$progressions$Iy_Ih_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 
											dailyData$ExposedTime_vec[i] + simData$progressions$Ih_Rr_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]]),
							TurnType=c("Py","Iy","Ih", "Rr"), 
							Turn_in_Day=0)
					} else if (simData$progressions$E2_Py2_Ih2_Rr_or_Rd[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]] == "Rd") {
						ProgressEntries <- data.frame(Turn_agent_vec=rep(simData$progressions$agentIndex[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 4), 
							Turn_arrival_vec=1, 
							turn=1, 
							modeltimecode=c(dailyData$ExposedTime_vec[i] + simData$progressions$E_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 
											dailyData$ExposedTime_vec[i] + simData$progressions$Py_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 
											dailyData$ExposedTime_vec[i] + simData$progressions$Iy_Ih_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]], 
											dailyData$ExposedTime_vec[i] + simData$progressions$Ih_Rd_EndTime[simData$progressions$agentIndex == dailyData$ExposedToday_vec[i]]),
							TurnType=c("Py","Iy","Ih", "Rd"), 
							Turn_in_Day=0)
					}		
				}
			}
		dBugDay(head(ProgressEntries))
		dBugDay(tail(ProgressEntries))
		dBugDay(nrow(ProgressEntries))
		dBugDay(nrow(simData$Progress_Turns))
		simData$Progress_Turns <- rbind(simData$Progress_Turns, ProgressEntries)
		dBugDay(nrow(simData$Progress_Turns))
		})
#	}, gcFirst=FALSE)
	dBugDay(ProgressTurnsTime)
	simData$Progress_Turns <- simData$Progress_Turns[order(simData$Progress_Turns$Turn_agent_vec, simData$Progress_Turns$modeltimecode),]
	}
	
	
	dBugDay("PROBLEM - Leftover dailyData$Turns at end of Day")
	dBugDay(head(dailyData$Turns))
	dBugDay(tail(dailyData$Turns))
	dBugDay(nrow(dailyData$Turns))
		
# 	dBugOneShot("FindturnsTime")
# 	dBugOneShot(FindturnsTime)
# 	
    #####------------------------#
    ### Close out a Daily environment
    #####------------------------#	
    
#	print(sprintf("[Core]                    %d simData$agents took %d turns", length(unique(dailyData$Turns$Turn_agent_vec)), length(dailyData$Turns$Turn_agent_vec)))
    
    dBugDay(table(simData$InfectStatus_vec))
# 	print(sprintf("[Core]                    There are %s Total New Infecters this Day", sum(quartnewInfecters)))
# 	print(sprintf("[Core]                    There are %s Total Infecters", sum(simData$InfectStatus_vec)))
    print("[Core]                    Cleaning Up the Day")
    
    if (q > 0 ) { 
        simData$Progress_Turns <- simData$Progress_Turns[order(simData$Progress_Turns$modeltimecode), ]
        dBugDay(head(simData$Progress_Turns))
        dBugDay(tail(simData$Progress_Turns))
        dBugDay(nrow(simData$Progress_Turns))
        
        dBugDay(sum(simData$DirectExposures_vec))
    }

    # Some ugly hackiness to get around the fact that not all data is globallized
    # in the original functions
#	print(head(simData$agents))
	
#	simData$agents = subset(simData$agents, select=-c(Esntl,Pr_Flout,RandomStable_vec, Flout))

#	print(head(simData$agents))

    return(dailyData)


}#------End of JailHouse update function




#-----------------------------#
# Create Runtime Routine
#-----------------------------#

runModel <- function (populationData) {	
    
    print("[Core]          Staging runtime modules")

    if (params$RuntimeStageMod == "JailHouse") {
        simData <- JailHouseRuntimeStaging(populationData)
    }#------End of JailHouse Runtime Staging check

    print("[Core]          Runtime module staging complete")
### ---------------- Runtime Profiling
# profileOut <- profvis({
# print("Timing Test on the Runtime")
### ---------------- Runtime Profiling
    for(q in params$StartDay:params$EndDay) {
        print(sprintf("[Core]          Running Day %d", q))
        if (params$RuntimeInfectMod == "JailHouse") {

#             prof_fn = sprintf("runlogs/prof_6013_day_%d.Rprof",q)
#             Rprof(filename=prof_fn, interval=0.1, memory.profiling=TRUE,
#                 gc.profiling=TRUE, line.profiling=TRUE, bufsize=2000000000L)

            dailyData <- JailHouseupdate(simData, q)

#             Rprof(NULL)

#     dailyData$toGlobals()
#     simData$toGlobals()

	
        }#------End of JailHouse Runtime check	
    }#------End of Day increment
### ---------------- Runtime Profiling
# })
# saveRDS(profileOut, file="TimingRuntime_profileOut.Rds")
### ---------------- Runtime Profiling
    print("[Core]                    Runtime ENDED")
    
}#------End of runModel


