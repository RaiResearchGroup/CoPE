# CoPE – COVID-19 Policy Evaluation tool
#
# An agent-based model of the social spread of COVID-19 with a focus on 
# individual-level behavioral responses to policy. 
# 
# Thank you for your interest in CoPE. 
# If your use of CoPE results in a publication, please cite as follows: 
# 
# Rai Group. (2020). CoPE: COVID-19 Policy Evaluation tool
# 	 Version 0.1. [Computer Software].
#
# This project is under active development. If you find something that needs our 
# attention, please send a message to BAMEx.devs@gmail.com. 
# Your feedback and input is extremely valuable. Thank you!
#
# 
# CovidABM7 
# UT Austin, RaiGroup
# Created: 06/12/2020
#
# #---------------#
args = commandArgs(TRUE)

ModelNumber <- c(7204)
outDir <- "outputs/"
inDir <- "inputs/"
ProcOutDir <- "processedOuts/"
PlotOutDir <- "analytics/package/"
runlogDir = ("runlogs")
cores = 1


if (!is.na(args[1])) {
	print("Additional CMD line args present")
	if (args[1] == "PostProcInSeries") {
		ModelNumber <<- args[2]
		print(sprintf("[PostProc]     Verifying Model Number: %s", ModelNumber))
	}
}
#-------------------------#
# Import Libraries
#-------------------------#

print("[Anls]          Loading Libraries ...")

library(ggplot2)
library(gridExtra)
library(R6)
library(future)
library(future.apply)
library(DBI)

print("[Anls]          ... Libraries Loaded")


dataStore <- R6Class("dataStore", public=list(
	writer = function(field){
		print(field)
		print(sprintf("Writing out %s", field))
		saveRDS(self[[field]], file = sprintf("%s/CovidABM7_%s_%s.Rds", ProcOutDir, field, ModelNumber), compress=FALSE)
		invisible(self)
	}
))


PostProcStore <- R6Class("setupDataClass", inherit = dataStore, public = list(
	job = NULL,
	ParamsData = NULL, 
	ProgressionsData = NULL, 
	NarrativeData = NULL, 
	NetworkData = NULL, 
	ExposerData = NULL
))

PostProcs <- PostProcStore$new()

#---------------#
# Get models ParamLogs
#---------------#

print("[Anls]          Reading Model Parameter Logs")
print(sprintf( "[Anls]          ParamLogs:%s", ModelNumber))
print("[Anls]          Finding Model Parameter Logs files")


# Out_pattern = sprintf("CovidABM7_ParamLog_%s_job", ModelNumber)
# Outfiles = unlist(lapply(Out_pattern, function(x) {list.files(path = runlogDir, pattern = x)}))
# # print(Out_pattern)
# # print(Outfiles)
# PostProcs$job <- seq(1,length(Outfiles))
# 
# 
# plan(multiprocess)
# 
# PostProcs$ParamsData <- future_lapply(PostProcs$job, function(j) {
# 	print(sprintf("[Anls]          Reading Model Parameter Log File:%s", Outfiles[j]))
# 	fname <- sprintf("%s/%s", runlogDir, Outfiles[j])
# 	#print(fname)
#     tmpParamLog <- read.csv(file = fname)
#     tmpParamLog$JobID <- j
#     tmpParamLog$uniqueRunID <- paste(tmpParamLog$Model, tmpParamLog$JobID, tmpParamLog$subModelID, sep = "-")
# 	return(tmpParamLog)
# })
# 
# plan(sequential)

PostProcs$ParamsData <- readRDS(file=sprintf("%s/CovidABM7_ParamsData_%s.Rds", ProcOutDir, ModelNumber))


# ---------------#
# Get Pop
# ---------------#
pop <-
  read.csv(
    file = sprintf(
      "inputs/%s%02d_%03d_%s.csv",
      PostProcs$ParamsData[[1]]$AgentPopulationStub,
      as.numeric(PostProcs$ParamsData[[1]]$state),
      as.numeric(PostProcs$ParamsData[[1]]$county),
      if (PostProcs$ParamsData[[1]]$UsePreviousAgentPopulation == TRUE) {
      	PostProcs$ParamsData[[1]]$loadAgentModel
      } else {
      	 ModelNumber
      }
    )
  )

#head(pop)

numAgents = nrow(pop)
agentPopID_vec <- seq(1, numAgents)
runDays_vec = seq(PostProcs$ParamsData[[1]]$StartDay, PostProcs$ParamsData[[1]]$EndDay)


essntl_occ <- read.csv(paste0(inDir, unique(PostProcs$ParamsData[[1]]$ContextData)))
essntl_occ <- unlist(strsplit(as.character(essntl_occ$Jailhouse_Esntl_Jobs[2]), split=";"))

trueParams <- PostProcs$ParamsData[[1]][1 ,c("Jailhouse_PrExposure",
							paste0("JailHouse_Duration_", c("E", "Pa", "Py", "Ia","Iy_Ih", "Iy_Rr", "Ih_Rr","Ih_Rd")),
							paste0("JailHouse_Prob_",c("E_Pa","Ia_Rr","Iy_Rr_age","Ih_Rr_age")))]


print(paste("[Anls]          Evaluating model", ModelNumber, "..."))

#---------------#
# Load Runtime data
#---------------#
#---------------#
print("[Anls]          Loading Datasets ...")

#---------------#
# All Progressions
cat("Progressions, ")
AllProgs_ListDF <- readRDS(file = sprintf("%sCovidABM7_ProgressionsData_%s.Rds", ProcOutDir, ModelNumber))

AllProgs_DF <- do.call("rbind", AllProgs_ListDF)

AllProgs_DF$RunID <- sub(".*-(.*?)-.*", "\\1", AllProgs_DF$uniqueRunID)


#---------------#
# Narrative Outs
cat("Narratives \n")

NarrConn = dbConnect(RSQLite::SQLite(), sprintf("processedOuts/CovidABM_Narratives_%s.db", ModelNumber))
Narr_Param_DF <- dbGetQuery(NarrConn, "SELECT * FROM Narratives")
dbDisconnect(NarrConn)


Narr_Param_DF$RunID <- sub(".*-(.*?)-.*", "\\1", Narr_Param_DF$uniqueRunID)
if (nrow(subset(Narr_Param_DF, FocalAgentStatus=="E" & Event %in% c("Ia","Iy")))!=0){
	print("WARNING: SOME AGENTS SKIPPING PRE-INFECTED BIN")
}
if (nrow(subset(Narr_Param_DF, as.character(FocalAgentStatus)==as.character(Event)))!=0){
	print("WARNING: SOME PROGRESSIONS DOUBLE RECORDING")
}
print("[Anls]          ... Datasets Loaded")


#---------------#
# Activities
#---------------#
print("Computing Activity Characteristics")
Activities <- subset(Narr_Param_DF, WithAgents!="None" & Time>0)

#Number of exposures
Activities$num_exp <- lengths(strsplit(as.character(Activities$NewExposurePopIDs),"-"))
Activities[Activities$NewExposurePopIDs=="None", "num_exp"] <- 0
exps <- aggregate(num_exp ~ RunID + Event, data=Activities, summary)
exps <- tableGrob(aggregate(.~Event, data=subset(exps, select=-RunID), mean))

#Group sizes
Activities$group_size <- lengths(strsplit(as.character(Activities$WithAgentsPopID),"-"))
groups <- aggregate(group_size ~ RunID + Event, data=Activities, summary)
groups <- tableGrob(aggregate(.~Event, data=subset(groups, select=-RunID), FUN=mean))

#Arrival Rates
arriv <- aggregate(Time ~ FocalAgentPopID + RunID + Event, data=subset(Activities, FocalAgentStatus=="S"),
					function(z) length(z) / ceiling(pmax(max(z)-min(z),1)))
arriv <- aggregate(Time ~ RunID + Event, data=arriv, mean)
arriv <- tableGrob(aggregate(Time ~ Event, data=arriv, mean))

pdf(paste0(PlotOutDir,ModelNumber, "_verification_report.pdf"), width=8, height=11)
plot.new()
grid.arrange(arrangeGrob(exps, top="Number of Exposures"),
			arrangeGrob(groups, top="\n\n\nGroup Sizes"),
			arrangeGrob(arriv, top="\n\n\nArrival Rates"),
			ncol=1, newpage=FALSE, heights=unit(c(4,6,6),"cm"))
mtext("Activities", side=3, cex=2, font=2)



#---------------#
# Progression Durations
#---------------#
print("Computing Durations")

# AllProgs Durations
cat("Scheduled:  ")

Durations <- with(AllProgs_DF, data.frame("duration.E"=E_EndTime, "duration.Ia"=Ia_EndTime-Pa_EndTime))
Durations[AllProgs_DF$E2_Pa_or_Py!="Pa", "duration.Ia"] <- NA

orders <- list(c("E_EndTime","Pa","Pa_EndTime","Py","Py_EndTime"),
				c("Py_EndTime","Rr","Iy_Rr_EndTime","Ih","Iy_Ih_EndTime"),
				c("Iy_Ih_EndTime","Rr","Ih_Rr_EndTime","Rd","Ih_Rd_EndTime"))
for (x in orders) {
	col <- grep(paste0("2.*",x[2],"_or_",x[4]), names(AllProgs_DF), value=TRUE)
	cat(col, ", ")

	new_cols <- paste0("duration.",sub("_EndTime","",x[c(3,5)]))
	Durations[,new_cols] <- AllProgs_DF[,x[c(3,5)]] - AllProgs_DF[,x[1]]

	Durations[AllProgs_DF[col]!=x[2], new_cols[1]] <- NA
	Durations[AllProgs_DF[col]!=x[4], new_cols[2]] <- NA
}
Durations <- aggregate(Durations, list(RunID=AllProgs_DF$RunID), mean, na.rm=TRUE)
Durations <- reshape(Durations, direction='long', varying=2:9, sep=".", timevar="type")
Durations$true <- as.numeric(trueParams[1,paste0("JailHouse_Duration_",Durations$type)])
Durations$type <- factor(Durations$type, levels=c("E","Pa","Py","Ia","Iy_Rr","Iy_Ih","Ih_Rr","Ih_Rd"))

grid.arrange(ggplot(Durations, aes(x=type, y=duration)) +
				geom_jitter(width=0.2, height=0, alpha=0.2, aes(color=RunID)) +
				geom_point(aes(y=true), color="red", shape=8) +
				labs(y="Time Length", x="") +
				theme(legend.position="none", axis.text.x=element_blank()),

			ggplot(Durations, aes(x=type, y=duration/true)) +
				geom_jitter(width=0.2, height=0, alpha=0.2, aes(color=RunID)) +
				geom_hline(yintercept=1) +
				labs(y="Percent of Input", x="Progression") +
				guides(color = guide_legend(nrow = 2, label.position="top")) +
				theme(legend.position="bottom"),

				ncol=1, heights=unit(c(10,13.5),"cm"), widths=unit(20,"cm"))
mtext("Durations - Scheduled", side=3, cex=2, font=2)
mtext("Average time agents spend in each disease progression state calculated from \n all scheduled activities", side=1, adj=0, padj=1)


# Narritive Durations
if (sum(Narr_Param_DF$ExposedCount) > 0) {

	cat("\nRealized:   ")


	Progressions <- subset(Narr_Param_DF, WithAgents=="None", c(FocalAgentPopID, RunID, FocalAgentStatus, Event, Time))

	exposures <- subset(Narr_Param_DF, !(NewExposurePopIDs %in% c("None","")), c(NewExposurePopIDs, Time, RunID))
	exposures <- apply(exposures, 1, function(z)
						cbind("FocalAgentPopID"=unlist(strsplit(as.character(z[1]),"-")), "Time"=z[2], "RunID"=z[3]))
	exposures <- data.frame(do.call("rbind", exposures), stringsAsFactors=FALSE)
	exposures$Time <- as.numeric(exposures$Time)
	exposures$Event <- "E"
	exposures$FocalAgentStatus <- "S"

	Progressions <- rbind(Progressions, exposures)

	orders <- with(trueParams, list(c("E","Pa",JailHouse_Duration_E), c("E","Py",JailHouse_Duration_E),
									c("Pa","Ia", JailHouse_Duration_Pa), c("Py","Iy", JailHouse_Duration_Py),
									c("Ia","Rr", JailHouse_Duration_Ia),
									c("Iy","Ih",JailHouse_Duration_Iy_Ih), c("Iy","Rr", JailHouse_Duration_Iy_Rr),
									c("Ih","Rr", JailHouse_Duration_Ih_Rr), c("Ih","Rd", JailHouse_Duration_Ih_Rd)))
	Durations <- data.frame()
	for (x in orders){
		cat(x[1], "to", x[2], ", ")
		dur <- merge(subset(Progressions, Event==x[1], c(FocalAgentPopID, RunID, Time)),
					subset(Progressions, Event==x[2] & FocalAgentStatus==x[1], c(FocalAgentPopID, RunID, Time)),
					by = c("FocalAgentPopID","RunID"))
		dur$duration <- dur$Time.y - dur$Time.x
		if(nrow(dur) > 0) { 
			dur <- aggregate(duration~RunID, data=dur, mean)
			dur$true <- as.numeric(x[3]) #trueParams$JailHouse_Duration_
			dur$type <- paste(x[1], x[2])

			Durations <- rbind(Durations, dur)
		}
	}
	cat("\n")
	Durations$type <- factor(Durations$type, levels=c("E Pa","E Py","Pa Ia","Py Iy","Ia Rr","Iy Rr","Iy Ih","Ih Rr","Ih Rd"))

	grid.arrange(ggplot(Durations, aes(x=type, y=duration)) +
					geom_jitter(width=0.2, height=0, alpha=0.2, aes(color=RunID)) +
					geom_point(aes(y=true), color="red", shape=8) +
					labs(y="Time Length", x="") +
					theme(legend.position="none", axis.text.x=element_blank()),

				ggplot(Durations, aes(x=type, y=duration/true)) +
					geom_jitter(width=0.2, height=0, alpha=0.2, aes(color=RunID)) +
					geom_hline(yintercept=1) +
					labs(y="Percent of Input", x="Progression") +
					guides(color = guide_legend(nrow = 2, label.position="top")) +
					theme(legend.position="bottom"),

					ncol=1, heights=unit(c(10,13.5),"cm"), widths=unit(20,"cm"))
	mtext("Durations - Realized", side=3, cex=2, font=2)
	mtext("Average time agents spend in each disease progression state calculated from \nonly transitions which complete by the end of model runtime", side=1, adj=0, padj=1)

} else {
	print("PROBLEM: No New Exposures Generated")
}


#---------------#
# Probabilities
#---------------#
print("Computing Probabilities")
# AllProgs Probabilities
cat("Scheduled: ")
Probabilities <- AllProgs_DF[AllProgs_DF[,"E2_Pa_or_Py"]!="Not", c("RunID","E2_Pa_or_Py")]
Probabilities <- merge(aggregate(. ~ RunID, data=Probabilities, length),
				aggregate(. ~ RunID, data=Probabilities[Probabilities[,"E2_Pa_or_Py"]=="Pa",], length), by="RunID")
Probabilities <- data.frame("RunID"=Probabilities$RunID, "probability"=Probabilities[,3] / Probabilities[,2],
					"type"=paste("Pa", "\ngiven", "E"), "true"=as.numeric(trueParams["JailHouse_Prob_E_Pa"]))
cat("Pa given E, ")

orders <- c(lapply(list(c(21.5,0.967),c(34.5,0.967), c(54.5,0.887),c(75,0.823)), function(x) c("Iy","Rr","Ih",x)),
			lapply(list(c(21.5,0.969),c(34.5,0.969), c(54.5,0.893),c(75,0.769)), function(x) c("Ih","Rr","Rd",x)))
for (x in orders) {
	cat(x[2], "given", x[1], ", ")
	col <- grep(paste0("2.*",x[2],"_or_",x[3]), names(AllProgs_DF), value=TRUE)
	prob <- subset(AllProgs_DF[AllProgs_DF[,col]!="Not",], AgeHH==as.numeric(x[4]), c("RunID",col))
	prob <- merge(aggregate(. ~ RunID, data=prob, length),
				aggregate(. ~ RunID, data=prob[prob[,col]==x[2],], length), by="RunID")
	prob <- data.frame("RunID"=prob$RunID, "probability"=prob[,3] / prob[,2],
							"type"=paste(x[4], x[2], "\ngiven", x[1]), "true"=as.numeric(x[5]))
	Probabilities <- rbind(Probabilities, prob)
}
Probabilities$type <- factor(Probabilities$type, levels=c("Pa \ngiven E",
														paste(c(21.5, 34.5, 54.5, 75), "Rr \ngiven Iy"),
														paste(c(21.5, 34.5, 54.5, 75), "Rr \ngiven Ih")))

grid.arrange(ggplot(Probabilities, aes(x=type, y=probability)) +
				geom_jitter(width=0.2, height=0, alpha=0.2, aes(color=RunID)) +
				geom_point(aes(y=true), color="red", shape=8) +
				labs(y="Probability", x="") +
				theme(legend.position="none", axis.text.x=element_blank()),

			ggplot(Probabilities, aes(x=type, y=probability / true)) +
				geom_jitter(width=0.2, height=0, alpha=0.2, aes(color=RunID)) +
				geom_hline(yintercept=1) +
				labs(y="Percent of Input", x="Transition") +
				guides(color = guide_legend(nrow = 2, label.position="top")) +
				theme(legend.position="bottom"),

				heights=unit(c(10,13.5),"cm"), widths=unit(20,"cm"))
mtext("Probabilities - Scheduled", side=3, cex=2, font=2)
mtext("Probability that an agent moves from one state to another calculated from \nall scheduled transitions", side=1, adj=0, padj=1)

if (sum(Narr_Param_DF$ExposedCount) > 0) {
	# Narritive Probabilities
	cat("\nRealized:  ")
	Progressions$AgeHH <- pop[match(as.numeric(Progressions$FocalAgentPopID), as.numeric(pop$PopID)),"AgeHH"]

	# Probability of being exposed when interacting with an infectious individual
	Probabilities <- transform(subset(Narr_Param_DF, WithAgents!="None"),
								all_status=paste(FocalAgentStatus, WithAgentsStatus, sep="-"))
	Probabilities <- subset(Probabilities, grepl("S", all_status) & grepl("Pa|Ia|Py|Iy|Rr|Iy", all_status))
	Probabilities$num_S <- lengths(gregexpr("S", Probabilities$all_status))
	Probabilities$num_E <- lengths(strsplit(as.character(Probabilities$NewExposurePopIDs), split="-"))
	Probabilities[Probabilities$NewExposurePopIDs %in% c("None",""), "num_E"] <- 0
	Probabilities$probability <- Probabilities$num_E  / Probabilities$num_S
	Probabilities <- aggregate(probability ~ RunID, data=Probabilities, mean)
	Probabilities$true <- trueParams$Jailhouse_PrExposure
	Probabilities$type <- "E"
	cat("E, ")

	orders <- c(list(c("E","Pa"), c("Ia","Rr")),
				lapply(list(c(21.5,0.967),c(34.5,0.967), c(54.5,0.887),c(75,0.823)), function(x) c("Iy","Rr",x)),
				lapply(list(c(21.5,0.969),c(34.5,0.969), c(54.5,0.893),c(75,0.769)), function(x) c("Ih","Rr",x)))
	for (x in orders){
		cat(x[2], "given", x[1], ", ")
		if (length(x)==4) {
			prob <- subset(Progressions, FocalAgentStatus==x[1] & AgeHH==as.numeric(x[3]), c(RunID,Event))

			if(nrow(prob) > 0) { 
				prob <- merge(aggregate(. ~ RunID, data=prob, length),
								aggregate(. ~ RunID, data=subset(prob,Event==x[2]), length), by="RunID")
				prob <- data.frame("RunID"=prob$RunID, "probability"=prob[,3] / prob[,2],
									"type"=paste(x[3], x[2], "\ngiven", x[1]), "true"=as.numeric(x[4]))
			}
		} else{
			if(nrow(prob) > 0) { 
				prob <- subset(Progressions, FocalAgentStatus==x[1], c(RunID,Event))
				prob <- merge(aggregate(. ~ RunID, data=prob, length),
								aggregate(. ~ RunID, data=subset(prob,Event==x[2]), length), by="RunID")
				prob <- data.frame("RunID"=unique(Progressions$RunID), "probability"=prob[,3]/prob[,2],
									"type"=paste(x[2], "\ngiven", x[1]),
									"true"=as.numeric(trueParams[paste0("JailHouse_Prob_",x[1],"_",x[2])]))
			}
		}
		if(nrow(prob) > 0) {
			Probabilities <- rbind(Probabilities, prob)
		}
	}
	cat("\n")
	Probabilities$type <- factor(Probabilities$type, levels=c("E", "Pa \ngiven E", "Rr \ngiven Ia",
															paste(c(21.5, 34.5, 54.5, 75), "Rr \ngiven Iy"),
															paste(c(21.5, 34.5, 54.5, 75), "Rr \ngiven Ih")))

	grid.arrange(ggplot(Probabilities, aes(x=type, y=probability)) +
					geom_jitter(width=0.2, height=0, alpha=0.2, aes(color=RunID)) +
					geom_point(aes(y=true), color="red", shape=8) +
					labs(y="Probability", x="") +
					theme(legend.position="none", axis.text.x=element_blank()),

				ggplot(Probabilities, aes(x=type, y=probability / true)) +
					geom_jitter(width=0.2, height=0, alpha=0.2, aes(color=RunID)) +
					geom_hline(yintercept=1) +
					labs(y="Percent of Input", x="Transition") +
					guides(color = guide_legend(nrow = 2, label.position="top")) +
					theme(legend.position="bottom"),

					heights=unit(c(10,13.5),"cm"), widths=unit(20,"cm"))
	mtext("Probabilities - Realized", side=3, cex=2, font=2)
	mtext("Probability that an agent moves from one state to another calculated from \nonly transitions which complete by the end of model runtime", side=1, adj=0, padj=1)

} else {
	print("PROBLEM: No New Exposures Generated")
}
dev.off()
warnings()
print("[Anls]          Verification Complete ...")
q()
