# CoPE – COVID-19 Policy Evaluation tool
#
# An agent-based model of the social spread of COVID-19 with a focus on 
# individual-level behavioral responses to policy. 
# 
# Thank you for your interest in CoPE. 
# If your use of CoPE results in a publication, please cite as follows: 
# 
# Rai Group. (2020). CoPE: COVID-19 Policy Evaluation tool
# 	 Version 0.1. [Computer Software].
#
# This project is under active development. If you find something that needs our 
# attention, please send a message to BAMEx.devs@gmail.com. 
# Your feedback and input is extremely valuable. Thank you!
#
# 
# CovidABM7 
# UT Austin, RaiGroup
# Created: 06/12/2020
#
# 

dataStore <- R6Class("dataStore", public=list(
	writer = function(field){
	#	print(field)
		print(sprintf("Writing out %s", field))
		saveRDS(self[[field]], file = sprintf("%sCovidABM7_%s_%s_job%s.Rds", params$outdir, field, params$Model, params$job), compress=FALSE)
		invisible(self)
	},
# This function should only ever be used for debugging.
	toGlobals = function(){
		for(name in names(self)){
			assign(name, self[[name]], inherits = TRUE)
		}
		invisible(self)
	},
	fromGlobals = function(){
		for(name in names(self)){
			self[[name]] <- get(name)
		}
		invisible(self)
	}
))

runsOutClass <- R6Class("runsOutClass", public=list(
 	ModelType = NULL,
 	ModelNum = NULL,
 	Runtime = NULL,
 	Batch = NULL,
 	Run = NULL,
 	TotalS = NULL,
 	TotalE = NULL,
 	TotalPa = NULL,
 	TotalPy = NULL,
 	TotalIa = NULL,
 	TotalIy = NULL,
 	TotalIh = NULL,
 	TotalRr = NULL,
 	TotalRd = NULL,
 	TotalEsntl = NULL,
 	TotalNonEsnt = NULL,
 	TotalSIP = NULL,
 	TotalFlout = NULL,
 	almostR0 = NULL,
 	EssEmp_Ia = NULL,
 	EssEmp_Iy = NULL,
 	EssEmp_Ih = NULL
))

endStateClass <- R6Class("endStateClass", public = list(
	ModelType = NULL,
	ModelNum = NULL,
	Runtime = NULL,
	Batch = NULL,
	Run = NULL,
	agentIndex = NULL,
	agentPopID = NULL,
	WGSlat = NULL,
	WGSlon = NULL,
	tractbg = NULL,
	InfectStatus = NULL,
	DirectExposures = NULL,
	FloutStatusatEnd = NULL,
	EsntlStatusatEnd = NULL,
	GroupThreshold = NULL,
	IncomeHH = NULL,
	OldestHH = NULL
))

# Parameters class. Represents the set of immutable parameters for a single run
# of the ABM. Object is immutable once created--attempting
# to modify a value will throw an error.
paramsClass = R6Class("paramsClass", inherit = dataStore, public = list(
	runParams = NULL,
	lockdown = function(){
		for (n in names(self)){
			lockBinding(n, self)
		}
	}
))




# A class representing the data needed purely in the init phase, that can be
# discarded once the simulation is running. This class is mutable.
setupDataClass <- R6Class("setupDataClass", inherit = dataStore, public = list(
	GeoneiDF_bg = NULL,
	LocalneiDF = NULL,
	JailHousenonLocals = NULL,
	JailHouseLocals = NULL,
	GeoneiDF = NULL
))

# The data of a population. This data is created by the initModel function and
# used for initialization--its data will be transferred over to a class which
# can mutably store that data for interaction during a simulation run.
populationDataClass <- R6Class("populationDataClass", inherit = dataStore, public=list(
	agents = NULL,
	JailHouseAlter_vec = NULL,
	size_data = NULL,
	attr_data = NULL,
	occupation_data = NULL,
	size_stats = NULL,
	attr_bins = NULL,
	attr_probs = NULL,
	occupation_bins = NULL,
	occupation_probs = NULL,
	lockdown = function(){
		for (n in names(self)){
			lockBinding(n, self)
		}
	}
))

# A class representing the data needed for an individual simulation run. It 
# should be initialized in initModel (or whatever function prepares a single
# simulation to be run) and can be deleted at the end of a simulation run (after
# the data has been recorded)
jailhouseRunDataClass <- R6Class("jailhouseRunDataClass",inherit = dataStore, public=list(
	agents = NULL,
	Alter_vec = NULL,
	Context = NULL,    # manual
	DirectExposures_vec = NULL,
	EssentialInfects_vec = NULL,
	FloutInfects_vec = NULL,
	FloutStatus_vec = NULL,
	GroupThresh_vec = NULL,
	IaInfects_vec = NULL,
	InfectStatus_vec = NULL,
	PastTurns = NULL,   # Previously called "PastTurns"
	LeftoverTurns = NULL, # Previously not needed--carries data about turns that
	PrevCoWorkTargetTimes = NULL,
	PrevCoWorkTargets = NULL,
	PrevFloutTargetTimes = NULL,
	PrevFloutTargets = NULL,
	Progress_Turns = NULL,
	QuarantineTill_vec = NULL,
	RandomStable_vec = NULL,
	RiskTol_vec = NULL,
	TestStatus_vec = NULL, 
	YesterdayFloutTargets = NULL,
	agentIndex_vec = NULL,
	agentJob_vec = NULL,
	agentPopID_vec = NULL,
	agentWGSlat_vec = NULL,
	agentWGSlon_vec = NULL,
	progressions = NULL,
	Current_Awareness = NULL,
	# Needs a manual override for this class because global name mappings differ.
	toGlobals = function(){
		assign("Context", self$Context, envir=.GlobalEnv)
		assign("JailHouseAlter_vec", self$Alter_vec, envir=.GlobalEnv)
		assign("JailHouseDirectExposures_vec", self$DirectExposures_vec, envir=.GlobalEnv)
		assign("JailHouseEssentialInfects_vec", self$EssentialInfects_vec, envir=.GlobalEnv)
		assign("JailHouseFloutInfects_vec", self$FloutInfects_vec, envir=.GlobalEnv)
		assign("JailHouseFloutStatus_vec", self$FloutStatus_vec, envir=.GlobalEnv)
		assign("JailHouseGroupThresh_vec", self$GroupThresh_vec, envir=.GlobalEnv)
		assign("JailHouseIaInfects_vec", self$IaInfects_vec, envir=.GlobalEnv)
		assign("JailHouseInfectStatus_vec", self$InfectStatus_vec, envir=.GlobalEnv)
		assign("JailHouseQuarantineTill_vec", self$QuarantineTill_vec, envir=.GlobalEnv)
		assign("JailHouseRandomStable_vec", self$RandomStable_vec, envir=.GlobalEnv)
		assign("JailHouseTestStatus_vec", self$TestStatus_vec, envir=.GlobalEnv)
		assign("JailHouseagentIndex_vec", self$agentIndex_vec, envir=.GlobalEnv)
		assign("JailHouseagentJob_vec", self$agentJob_vec, envir=.GlobalEnv)
		assign("JailHouseagentPopID_vec", self$agentPopID_vec, envir=.GlobalEnv)
		assign("JailHouseagentWGSlat_vec",  self$agentWGSlat_vec, envir=.GlobalEnv)
		assign("JailHouseagentWGSlon_vec", self$agentWGSlon_vec, envir=.GlobalEnv)
		assign("PastTurns" , self$PastTurns, envir=.GlobalEnv)
		assign("YesterdayFloutTargets" , self$YesterdayFloutTargets, envir=.GlobalEnv)
		assign("agents", self$agents, envir=.GlobalEnv)
		assign("progressions", self$progressions, envir=.GlobalEnv)
		assign("LeftoverTurns", self$LeftoverTurns, envir = .GlobalEnv)
		assign("PreviousCoWorkTargetTimes", self$PrevCoWorkTargetTimes, envir = .GlobalEnv)
		assign("PreviousCoWorkTargets", self$PrevCoWorkTargets, envir = .GlobalEnv)
		assign("PreviousFloutTargetTimes", self$PrevFloutTargetTimes , envir = .GlobalEnv)
		assign("PreviousFloutTargets", self$PrevFloutTargets, envir = .GlobalEnv)
		assign("Progress_Turns" , self$Progress_Turns, envir=.GlobalEnv)
		invisible(self)
	}
))

# A class representing the data needed in a single day of the simulation. It can
# be created at the start of the update and discarded at the end (though some
# data, e.g. flouters, may need to be carried over to the next day).
jailhouseDailyDataClass <- R6Class("jailhouseDailyDataClass",inherit = dataStore, public=list(
	EssentialAct_W = NULL,
	ExposedToday_vec = NULL,
	ExposedTime_vec = NULL,
	NonEssentialAct_W = NULL,
	RiskTol_vec = NULL,
	Tests_vec = NULL,
	Turns = NULL,   # Should be called "RawTurns". A DF of turns that will be processed
					# down to produce Turns_In_Day
	Turns_In_Day = NULL,  # The turns that will be executed today (should be called "TurnList_Today")
	esntlStatus_vec = NULL,
	sickAlterFrac_vec = NULL,
	q = 0,          # Today's day index ("What day is it?")
	# Needs a manual override for this class because global name mappings differ.
	toGlobals = function(){
		assign("EssentialAct_W", self$EssentialAct_W, envir=.GlobalEnv)
		assign("ExposedToday_vec",  self$ExposedToday_vec, envir=.GlobalEnv)
		assign("ExposedTime_vec", self$ExposedTime_vec, envir=.GlobalEnv)
		assign("NonEssentialAct_W", self$NonEssentialAct_W, envir=.GlobalEnv)
		assign("JailHouse_RiskTol_vec", self$RiskTol_vec, envir=.GlobalEnv)
		assign("Tests_vec", self$Tests_vec, envir=.GlobalEnv)
		assign("Turns", self$Turns, envir=.GlobalEnv)
		assign("Turns_In_Day", self$Turns_In_Day, envir=.GlobalEnv)
		assign("JailHouseEsntlStatus_vec", self$esntlStatus_vec, envir=.GlobalEnv)
		assign("sickAlterFrac_vec", self$sickAlterFrac_vec, envir=.GlobalEnv)
		invisible(self)
	}
))

# NarrativesDataClass <- R6Class("NarrativesDataClass",inherit = dataStore, public=list(
# 		Events = NULL 
# ))

# NarrativesDataClass <- R6Class("NarrativesDataClass",inherit = dataStore, public=list(
# 		EventCount = 0, 
# 		NarrativeOuts = NULL,
# # 		initialize = function() {
# # 			self$NarrativeOuts[[1]] <- c("FocalAgent", 
# # 			"FocalAgentPopID", 
# # 			"FocalAgentStatus", 
# # 			"FocalAgentEsntl", 
# # 			"FocalAgentFlout", 
# # 			"FocalAgentTest", 
# # 			"FocalAgent_RiskTol", 
# # 			"Event", 
# # 			"Time", 
# # 			"WithAgents", 
# # 			"WithAgentsPopID", 
# # 			"WithAgentsStatus", 
# # 			"WithAgentsEsntl", 
# # 			"WithAgentsFlout", 
# # 			"WithAgentsTest", 
# # 			"WithAgents_RiskTol", 
# # 			"ExposerIDs", 
# # 			"ExposerPopIDs", 
# # 			"NewExposureIDs", 
# # 			"NewExposurePopIDs", 
# # 			"ModelType", 
# # 			"ModelNum", 
# # 			"Runtime", 
# # 			"subModelID")
# # 		},
#   		addEvent = function(newEvent) {
#   			self$NarrativeOuts[[self$EventCount + 2]] <- newEvent
#   			self$EventCount <- self$EventCount + 1
#   			invisible(self)
#   		}
# ))