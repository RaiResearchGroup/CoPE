#!/usr/bin/python

# CoPE – COVID-19 Policy Evaluation tool
#
# An agent-based model of the social spread of COVID-19 with a focus on 
# individual-level behavioral responses to policy. 
# 
# Thank you for your interest in CoPE. 
# If your use of CoPE results in a publication, please cite as follows: 
# 
# Rai Group. (2020). CoPE: COVID-19 Policy Evaluation tool
# 	 Version 0.1. [Computer Software].
#
# This project is under active development. If you find something that needs our 
# attention, please send a message to BAMEx.devs@gmail.com. 
# Your feedback and input is extremely valuable. Thank you!
#
# 
# CovidABM7 
# UT Austin, RaiGroup
# Created: 06/12/2020
#
# 
import PySimpleGUI as sg    
  
import os
import stat

sg.ChangeLookAndFeel('GreenTan')      

# ------ Menu Definition ------ #      
# menu_def = [['File', ['Open', 'Save', 'Exit', 'Properties']],      
#             ['Edit', ['Paste', ['Special', 'Normal', ], 'Undo'], ],      
#             ['Help', 'About...'], ]      

# ------ Column Definition ------ #      
# column1 = [[sg.Text('Column 1', background_color='#F7F3EC', justification='center', size=(10, 1))],      
#             [sg.Spin(values=('Spin Box 1', '2', '3'), initial_value='Spin Box 1')],      
#             [sg.Spin(values=('Spin Box 1', '2', '3'), initial_value='Spin Box 2')],      
#             [sg.Spin(values=('Spin Box 1', '2', '3'), initial_value='Spin Box 3')]]      


modelNum = len(open("ModelTracker.csv").readlines())
#sum(1 for line in "ModelTracker.csv")

layout = [      
#     [sg.Menu(menu_def, tearoff=True)],      
    [sg.Text('CovidABM Model number '+str(modelNum), size=(30, 1), justification='center', font=("Helvetica", 25), relief=sg.RELIEF_RIDGE)],    
	[sg.Text('FIPS State:'), sg.InputText('48', size=(2,1), key="FIPSState")],
	[sg.Text('FIPS County:'), sg.InputText('453', size=(3,1), key="FIPSCounty")],
	[sg.Text('Run Length in days:'), sg.InputText('120', size=(3,1), key="modelLength_var")],
	[sg.Text('SIP delay in days:'), sg.InputText('28', size=(3,1), key="policyDelay_var")],
	[sg.Text('SIP duration in days:'), sg.InputText('45', size=(3,1), key="policyDuration_var")],
	[sg.Text('SIP Compliance rate (between 0 and 1):'), sg.InputText('0.75', size=(4,1), key="policyCompliance_var")],
	[sg.Text('Which occupations are essential? (check all that apply)')],
	[sg.Checkbox('Architecture and engineering', key='Architecture and engineering'), sg.Checkbox('Arts, design, entertainment, sports, and media', key='Arts, design, entertainment, sports, and media')],
	[sg.Checkbox('Building and grounds cleaning and maintenance', key='Building and grounds cleaning and maintenance', default=True), sg.Checkbox('Business and financial operations', key='Business and financial operations', default=True)],
	[sg.Checkbox('Community and social service', key='Community and social service', default=True), sg.Checkbox('Computer and mathematical', key='Computer and mathematical')],
	[sg.Checkbox('Construction and extraction', key='Construction and extraction', default=True), sg.Checkbox('Educational instruction, and library', key='Educational instruction, and library')],
	[sg.Checkbox('Farming, fishing, and forestry', key='Farming, fishing, and forestry', default=True), sg.Checkbox('Food preparation and serving related', key='Food preparation and serving related')],
	[sg.Checkbox('Healthcare practitioners and technical', key='Healthcare practitioners and technical', default=True), sg.Checkbox('Healthcare support', key='Healthcare support', default=True)],
	[sg.Checkbox('Installation, maintenance, and repair', key='Installation, maintenance, and repair', default=True), sg.Checkbox('Legal', key='Legal')],
	[sg.Checkbox('Life, physical, and social science', key='Life, physical, and social science'), sg.Checkbox('Management', key='Management')],
	[sg.Checkbox('Material moving', key='Material moving', default=True), sg.Checkbox('Office and administrative support', key='Office and administrative support')],
	[sg.Checkbox('Personal care and service', key='ersonal care and service'), sg.Checkbox('Production', key='Production', default=True)],
	[sg.Checkbox('Protective service', key='Protective service', default=True), sg.Checkbox('Sales and related', key='Sales and related')],
	[sg.Checkbox('Transportation', key='Transportation', default=True)],
    [sg.Submit(tooltip='Click to use these settings'), sg.Cancel()]    
]      


window = sg.Window('CovidABM settings', layout, default_element_size=(40, 1), grab_anywhere=False)      

event, ABMsettings = window.read()      

if event == "Submit":

	policyEssntl_var = ""
	for keyname, keyvalue in ABMsettings.items():
		if keyvalue == True:
	#         print(keyname)
			policyEssntl_var += ";"
			policyEssntl_var += keyname 

	policyEssntl_var = policyEssntl_var[1:]

	policyFlout_var=1-float(ABMsettings['policyCompliance_var'])

	policySIPoff_var=int(ABMsettings['policyDelay_var'])+int(ABMsettings['policyDuration_var'])

	modelLength=int(ABMsettings['modelLength_var'])+1

	TimeEstimate_min=modelLength*2

	window.close() 
   
	layout = [ 
		[sg.Submit(tooltip='Click to use these settings'), sg.Cancel()]    
	] 

	# print("Ok, building csv scenario file")

	f = open("inputs/scenarii/CovidABM7_Scenario_"+str(modelNum)+".csv", "w")

	f.write("Scenario, Day,Jailhouse_Awareness,Jailhouse_Esntl_Rate,Jailhouse_Flout_Rate,Jailhouse_DailyTests,Jailhouse_Esntl_Jobs\n")
	f.write("Static,-100,0,1,1,0,\"Architecture and engineering;Arts, design, entertainment, sports, and media;Building and grounds cleaning and maintenance;Business and financial operations;Community and social service;Computer and mathematical;Construction and extraction;Educational instruction, and library;Farming, fishing, and forestry;Food preparation and serving related;Healthcare practitioners and technical;Healthcare support;Installation, maintenance, and repair;Legal;Life, physical, and social science;Management;Material moving;Office and administrative support;Personal care and service;Production;Protective service;Sales and related;Transportation\"\n")
	f.write("Static,"+ABMsettings['policyDelay_var']+",1,1,"+str(policyFlout_var)+",0,\""+policyEssntl_var+"\"\n")
	f.write("Static,"+str(policySIPoff_var)+",1,1,1,0,\"Architecture and engineering;Arts, design, entertainment, sports, and media;Building and grounds cleaning and maintenance;Business and financial operations;Community and social service;Computer and mathematical;Construction and extraction;Educational instruction, and library;Farming, fishing, and forestry;Food preparation and serving related;Healthcare practitioners and technical;Healthcare support;Installation, maintenance, and repair;Legal;Life, physical, and social science;Management;Material moving;Office and administrative support;Personal care and service;Production;Protective service;Sales and related;Transportation\"\n")
	f.write("Static,"+str(modelLength)+",1,1,1,0,\"Architecture and engineering;Arts, design, entertainment, sports, and media;Building and grounds cleaning and maintenance;Business and financial operations;Community and social service;Computer and mathematical;Construction and extraction;Educational instruction, and library;Farming, fishing, and forestry;Food preparation and serving related;Healthcare practitioners and technical;Healthcare support;Installation, maintenance, and repair;Legal;Life, physical, and social science;Management;Material moving;Office and administrative support;Personal care and service;Production;Protective service;Sales and related;Transportation\"\n")
	f.write("Static,1000,1,1,1,0,\"Architecture and engineering;Arts, design, entertainment, sports, and media;Building and grounds cleaning and maintenance;Business and financial operations;Community and social service;Computer and mathematical;Construction and extraction;Educational instruction, and library;Farming, fishing, and forestry;Food preparation and serving related;Healthcare practitioners and technical;Healthcare support;Installation, maintenance, and repair;Legal;Life, physical, and social science;Management;Material moving;Office and administrative support;Personal care and service;Production;Protective service;Sales and related;Transportation\"\n")

	f.close()

	f = open("ModelTracker.csv", "a")
	f.write(str(modelNum)+","+str(ABMsettings['FIPSState'])+","+str(ABMsettings['FIPSCounty'])+","+str(ABMsettings['modelLength_var'])+","+str(ABMsettings['policyDelay_var'])+","+str(ABMsettings['policyDuration_var'])+","+policyEssntl_var+","+str(ABMsettings['policyCompliance_var'])+"\n")
	f.close()


	if os.name == 'nt':
		runscript = "RunCovidABM"+str(modelNum)+".bat"
		f = open(runscript, "w")
		f.write('@echo off\n')
		f.write('SET modelCount=1\n')
		f.write('FOR %%A in (runlogs\CovidABM7_Log_'+str(modelNum)+'*) DO SET /a modelCount+=1\n')
		f.write('Rscript CovidABM7_exe_run.R jobNum %modelCount% ModelNum '+str(modelNum)+' ModelLength '+str(ABMsettings['modelLength_var'])+' FIPSstate '+str(ABMsettings['FIPSState'])+' FIPScounty '+str(ABMsettings['FIPSCounty'])+'\n')
	else:
		runscript = "RunCovidABM"+str(modelNum)+".sh"
		f = open(runscript, "w")
		f.write('#!/bin/bash\n')
		f.write('modelCount=`ls runlogs/CovidABM7_Log_'+str(modelNum)+'* | wc -l`\n')
		f.write('modelCount=$(($modelCount+1))\n')
		f.write('Rscript CovidABM7_exe_run.R jobNum $modelCount ModelNum '+str(modelNum)+' ModelLength '+str(ABMsettings['modelLength_var'])+' FIPSstate '+str(ABMsettings['FIPSState'])+' FIPScounty '+str(ABMsettings['FIPSCounty'])+'\n')

	f.write('echo "Done running"\n')
	f.write('Rscript CovidABM7_exe_postproc.R PostProcInSeries '+str(modelNum)+'\n')
	f.write('echo "Done basic post-processing"\n')
	f.write('Rscript CovidABM7_exe_analytics_Verification.R PostProcInSeries '+str(modelNum)+'\n')
	f.write('echo "Done verification"\n')
	f.write('Rscript CovidABM7_exe_analytics_PackageSingle.R PostProcInSeries '+str(modelNum)+'\n')
	f.write('echo "Done packaging outputs"\n')
	f.write('exit 0')
	f.close()

	st = os.stat(runscript)
	os.chmod(runscript, st.st_mode | stat.S_IEXEC)

# 	print('Rscript CovidABM7_exe_run.R jobNum '+instanceID+' ModelNum '+str(modelNum)+' ModelLength '+str(ABMsettings['modelLength_var'])+' FIPSstate '+str(ABMsettings['FIPSState'])+' FIPScounty '+str(ABMsettings['FIPSCounty']))

	sg.popup('CovidABM settings for Model ', modelNum, 
				'Executable for Covid ABM Model ', modelNum,     
				'Estimated tme to finish in minutes: ', TimeEstimate_min, 
				'FIPS State: ', ABMsettings['FIPSState'],   
				'FIPS County: ', ABMsettings['FIPSCounty'],    
				'Run Length in days: ', ABMsettings['modelLength_var'], 
				'SIP delay in days: ', ABMsettings['policyDelay_var'],
				'SIP duration in days: ', ABMsettings['policyDuration_var'],
				'SIP Compliance rate: ', ABMsettings['policyCompliance_var'],
				'Essential Occupations: ', policyEssntl_var, 
				'YOUR MODEL IS BUILT', 
				'Type ./' + runscript + ' to run it')

elif event == "Cancel":
	exit(0)      