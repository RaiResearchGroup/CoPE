# CoPE – COVID-19 Policy Evaluation tool
#
# An agent-based model of the social spread of COVID-19 with a focus on 
# individual-level behavioral responses to policy. 
# 
# Thank you for your interest in CoPE. 
# If your use of CoPE results in a publication, please cite as follows: 
# 
# Rai Group. (2020). CoPE: COVID-19 Policy Evaluation tool
# 	 Version 0.1. [Computer Software].
#
# This project is under active development. If you find something that needs our 
# attention, please send a message to BAMEx.devs@gmail.com. 
# Your feedback and input is extremely valuable. Thank you!
#
# 
# CovidABM7 
# UT Austin, RaiGroup
# Created: 06/12/2020
#
# 
# This assembles raw inputs, downloading when necessary, and builds a suitable population 


JailHouseACSAgentSource <- function (state, county, popData) {

    bg_file <- paste0("tl_2010_", as.character(state), as.character(county),"_bg10")
    
    
    #####----- CENSUS BLOCK GROUP SHAPE FILES -----#####
        #https://www2.census.gov/geo/tiger/TIGER2010/BG/2010/ + bg_file + .zip
        #https://www2.census.gov/geo/tiger/TIGER2010/BG/2010/tl_2010_48453_bg10.zip

    if (params$GetNewGeography == TRUE) {
        if(!file.exists(paste0("inputs/", bg_file, "/",bg_file, ".shp"))){
            print("Shape files not found")
            print(sprintf("Downloading shapefile from https://www2.census.gov/geo/tiger/TIGER2010/BG/2010/%s.zip",bg_file))
            dir.create(sprintf("inputs/%s",bg_file))
            download.file(url=sprintf("https://www2.census.gov/geo/tiger/TIGER2010/BG/2010/%s.zip",bg_file), destfile = paste0("inputs/",bg_file,"/",bg_file,".zip"), method="auto")

            print(sprintf("Unzipping https://www2.census.gov/geo/tiger/TIGER2010/BG/2010/%s.zip to inputs/%s",bg_file,bg_file))
            print(sprintf("inputs/%s/", bg_file))
            unzip(sprintf("inputs/%s/%s.zip", bg_file, bg_file), exdir= sprintf("inputs/%s", bg_file))
        } else {
            print("Shapefile found - not downloading")
        }

    }
    print("[Init]          Generating new input file")

    print(paste0("inputs/",bg_file))

    county_BG <- readOGR(paste0("inputs/",bg_file), bg_file);
    county_BG <- spTransform(county_BG, CRS("+proj=longlat +ellps=WGS84"))


    #####----- CENSUS BLOCK GROUP ACS DATA -----#####
    census_key <- "&key=93bc8622cfd3ab7ef2d762eab15ff0c071f0d830"

    #variable suffix (code) and race abbreviation (name) for the races present in count and housholder data
    race_code <- c("B", "C",    "D", "E",       "F", "G",  "H", "I")
	race_name <- c("B", "NAm",  "A", "NHaPIs",  "O", "Mu", "W", "Hi")

    ##-- Number of households by race (census variable group: B25006B-I)
    race_count <- fromJSON(paste0("https://api.census.gov/data/2018/acs/acs5?get=",paste0("B11001",race_code,"_001E", collapse=","),
                                    "&for=block%20group:*&in=state:",state,"%20county:",county,census_key))
    race_count <- data.frame(race_count, stringsAsFactors=FALSE)
    names(race_count) <- as.character(race_count[1,])
    race_count <- race_count[-1, c("tract", "block group", paste0("B11001",race_code,"_001E"))]    #Estimate fields
    names(race_count)<- c("tract", "bg", race_name)

    race_count[,race_name] <- sapply(race_count[,race_name], as.numeric)
    race_count <- merge(race_count, aggregate(. ~ tract, race_count[,-2], sum), by="tract", all.x=TRUE)
    race_count[,race_name] <- race_count[,paste0(race_name,".x")] / race_count[,paste0(race_name,".y")]
    race_count[sapply(race_count, is.nan)] <- 0 #0/0 = 0

    race_count <- race_count[with(race_count, order(tract, bg)), c("tract", "bg", race_name)]


    ##-- Age of householder by household income, race (census variable group: B19037A-G)
    attr_data_names <- fromJSON("https://api.census.gov/data/2018/acs/acs5/groups/B19037/")
    attr_data_names <- unlist(sapply(attr_data_names[[1]], "[", "label"))
    attr_data_names <- data.frame("code" = gsub(".label", "", names(attr_data_names)), 
                                  "name" = unname(attr_data_names), stringsAsFactors=FALSE)
    attr_data_names <- subset(attr_data_names, !grepl("EA|MA|M", code))               #get only the estimate fields
    attr_data_names <- subset(attr_data_names, !grepl("years$|over$|Total$", name))   #remove the totals variables

    #age and income midpoints
    attr_data_names$age <- sub(".*Householder *(.*?) *years.*", "\\1", attr_data_names$name)
    map <- setNames(c(75, 54.5, 34.5, 21.5), c("65", "45 to 64", "25 to 44", "under 25"))
    attr_data_names$age <- map[attr_data_names$age]

    attr_data_names$income <- gsub(",|\\$|Less than | or more", "", sub(".*Householder *(.*?) *!!", "", attr_data_names$name))
    attr_data_names$income <- lapply(strsplit(attr_data_names$income, " to "), function(x) mean(as.numeric(x)))
    attr_data_names[grepl("Less than \\$10,000", attr_data_names$name),"income"] <- 5000
    attr_data_names[grepl("\\$200,000 or more", attr_data_names$name), "income"] <- 300000

    #coded names to extract values later
    attr_data_names$coded_names <- with(attr_data_names, paste0(age,"-",income))

    #initialize loop dataframe
    attr_data <- setNames(data.frame(matrix(ncol = length(attr_data_names$code)+3, nrow = 0)),
                            c("tract","bg","race", attr_data_names$code))
    for (j in 1:length(race_code)) {
        ##-- Age of householder by household income, race (census variable group: B19037A-G)
        #this data is only available at the tract level, so modify it by the BG distribution by race in each tract
        attr_tract_data <- fromJSON(paste0("https://api.census.gov/data/2018/acs/acs5?get=group(B19037", race_code[j],
                                        ")&for=tract:*&in=state:", state, "%20county:", county, census_key))
        attr_tract_data <- data.frame(attr_tract_data, stringsAsFactors = FALSE)
        names(attr_tract_data) <- as.character(attr_tract_data[1,])
        attr_tract_data <- attr_tract_data[-1,c("tract",gsub("_", paste0(race_code[j], "_"), attr_data_names$code))]
        attr_tract_data <- attr_tract_data[with(attr_tract_data, order(tract)), ]

        #for each county what percent of this race is in each block group
        attr_bg_data <- race_count[,c("tract","bg",race_name[j])]
        attr_bg_data <- merge(attr_bg_data, attr_tract_data, by="tract", all.x=TRUE)
        names(attr_bg_data) <- c("tract", "bg", "weight", attr_data_names$code)

        #append race column
        attr_bg_data$race <- race_name[j]

        attr_data <- rbind(attr_data, attr_bg_data)
    }
    attr_data[,attr_data_names$code] <- sapply(attr_data[,attr_data_names$code], as.numeric)
    attr_data[,attr_data_names$code] <- attr_data[,attr_data_names$code] * attr_data[,"weight"]

    attr_data$tractbg <- paste0("tbg", attr_data[,"tract"], attr_data[,"bg"])

    
    colnames(attr_data)[which(names(attr_data) %in% attr_data_names$code)] <- attr_data_names$coded_names
    attr_data <- reshape(attr_data[,c("tractbg","race",attr_data_names$coded_names)],
                            idvar="tractbg", timevar="race", direction="wide", sep="-")
    attr_data$total <- rowSums(attr_data[,-1])


    ##-- Occupation breakdowns by sex (census variable group: C24010 - Occupations, C24030- Industries)
    #this data is only available at a lower occupational resolution by race
    occupations <- c("Architecture and engineering occupations",
    	"Arts, design, entertainment, sports, and media occupations",
    	"Building and grounds cleaning and maintenance occupations",
    	"Business and financial operations occupations",
    	"Community and social service occupations",
    	"Computer and mathematical occupations",
    	"Construction and extraction occupations",
    	"Educational instruction, and library occupations",
    	"Farming, fishing, and forestry occupations",
    	"Food preparation and serving related occupations" ,
    	"Healthcare practitioners and technical occupations",
    	"Healthcare support occupations" ,
    	"Installation, maintenance, and repair occupations",
    	"Legal occupations",
    	"Life, physical, and social science occupations",
    	"Management occupations",
    	"Material moving occupations",
    	"Office and administrative support occupations",
    	"Personal care and service occupations",
    	"Production occupations",
    	"Protective service occupations",
    	"Sales and related occupations",
    	"Transportation occupations")

    occupation_names <- fromJSON("https://api.census.gov/data/2018/acs/acs5/groups/C24010/")
    occupation_names <- unlist(sapply(occupation_names[[1]], "[", "label"))
    occupation_names <- data.frame("code"= gsub(".label", "", names(occupation_names)),
                                   "name"=unname(occupation_names), stringsAsFactors=FALSE)
    occupation_names <- subset(occupation_names, !grepl("EA|MA|M",code)) #get only the estimate fields
    occupation_names <- subset(occupation_names, grepl(paste(occupations, collapse="$|"), name))
    occupation_names$short_name <- unlist(lapply(strsplit(occupation_names$name, "!!"), function(x) x[length(x)]))

    occupation_data <- fromJSON(paste0("https://api.census.gov/data/2018/acs/acs5?get=group","(C24010)",
                                    "&for=block%20group:*&in=state:",state,"%20county:",county,census_key))
    occupation_data <- data.frame(occupation_data, stringsAsFactors=FALSE)
    names(occupation_data) <- occupation_data[1,]
    occupation_data$tractbg <- paste0("tbg", occupation_data[,"tract"], occupation_data[,"block group"])
    occupation_data <- occupation_data[-1,c("tractbg",occupation_names$code)]

    #combine male & female into new columns
    for (k in unique(occupation_names$short_name)) {
        occupation_data[,gsub(" occupations", "", k)] <-
                rowSums(sapply(occupation_data[,subset(occupation_names,short_name==k)$code], as.numeric))
        occupation_data[,subset(occupation_names,short_name==k)$code] <- NULL
    }
    occupation_data$total <- rowSums(occupation_data[,-1])


    ##-- Household sizes by family type (census variable group: B11016)
    size_names <- fromJSON("https://api.census.gov/data/2018/acs/acs5/groups/B11016/")
    size_names <- unlist(sapply(size_names[[1]], "[", "label"))
    size_names <- data.frame("code"= gsub(".label", "", names(size_names)),
                             "name"=unname(size_names), stringsAsFactors=FALSE)
    size_names <- subset(size_names, !grepl("EA|MA|M",code)) #get only the estimate fields
    size_names$short_name <- unlist(lapply(strsplit(size_names$name, "!!"), function(x) x[4]))
    size_names <- subset(size_names, !is.na(short_name))
    size_names$short_name <- gsub(" person| household","",size_names$short_name)

    size_data <- fromJSON(paste0("https://api.census.gov/data/2018/acs/acs5?get=group","(B11016)",
                                    "&for=block%20group:*&in=state:",state,"%20county:",county,census_key))
    size_data <- data.frame(size_data, stringsAsFactors = FALSE)
    names(size_data) <- size_data[1,]
    size_data$tractbg <- paste0("tbg", size_data[,"tract"], size_data[,"block group"])
    size_data <- size_data[-1,c("tractbg", size_names$code)]

    #combine family & nonfamily into new columns
    for (k in sort(unique(size_names$short_name))) {
        if (k == "1-person") {
            size_data[,k] <- as.numeric(size_data[,subset(size_names,short_name==k)$code])
            size_data[,subset(size_names,short_name==k)$code] <- NULL
            next
        }
        size_data[,k] <- rowSums(sapply(size_data[,subset(size_names,short_name==k)$code], as.numeric))
        size_data[,subset(size_names,short_name==k)$code] <- NULL
    }
    size_data$total <- rowSums(size_data[,-1])

    #append ~geographic centroids to size_data
    size_data$WGSlon <- coordinates(county_BG)[,1]
    size_data$WGSlat <- coordinates(county_BG)[,2]

	#####----- DISTRIBUTIONS BY CENSUS BLOCK GROUP -----#####

	##-- Household sizes
	
	dBugInit("head(size_data)")
	dBugInit(head(size_data))
	
	size_data  <- size_data[order(size_data$tractbg), ]
	size_counts <- size_data[,c("1-person","2-person","3-person","4-person","5-person","6-person","7-or-more")]
	size_bins <- c(1,2,3,4,5,6,8)
	mu <- apply(size_counts, 1, function(x) sum(x*size_bins) / sum(x))                                                      #mean by group
	var <- apply(size_counts, 1, function(x) ( sum(x*size_bins^2) - sum(x) * (sum(x*size_bins)/sum(x))^2 ) / (sum(x)-1))    #variance
	std <- sqrt(var)      	                 																				#standard deviation
	size_stats <- data.frame("tractbg"=size_data$tractbg, "WGSlon"=size_data$WGSlon, "WGSlat"=size_data$WGSlat,
								"size_mu"=mu, "size_std"=std, "total_hh"=size_data$total)

	#make sure dataframes are in the same order
	size_stats  <- size_stats[order(size_stats$tractbg), ]
	attr_data <- attr_data[order(attr_data$tractbg),]
	occupation_data <- occupation_data[order(occupation_data$tractbg),]

	dBugInit(head(size_stats))
	dBugInit(tail(size_stats))
	dBugInit(nrow(size_stats))
	

	#remove blockgroups that have 0 households
	print(sprintf("[Init]          JailHouse Agent initialization Dropping %d block groups with no households", sum(size_stats$total_hh==0)))
	attr_data    <- attr_data[size_stats$total_hh!=0,]
	occupation_data <- occupation_data[size_stats$total_hh!=0,]
	size_stats  <- size_stats[size_stats$total_hh!=0,]

	dBugInit("Do Age/Income/Race data")
	##-- Age/Income/Race data (this is binned data)
	attr_probs <- attr_data[,-ncol(attr_data)]
	attr_bins  <- strsplit(names(attr_data)[-c(1,ncol(attr_data))], "-")
	dBugInit("Done Age/Income/Race data")
	
	dBugInit("Do Occupation data")
	##-- Occupation (this is binned data)
	occupation_probs <- occupation_data[-ncol(occupation_data)]
	occupation_bins <- names(occupation_data)[-c(1,ncol(occupation_data))]
	dBugInit("Done Occupation data")

	popData$size_data <- size_data
	popData$attr_data <- attr_data
	popData$occupation_data <- occupation_data
	popData$size_stats <- size_stats
	popData$attr_bins <- attr_bins
	popData$attr_probs <- attr_probs
	popData$occupation_bins <- occupation_bins
	popData$occupation_probs <- occupation_probs

    if (params$SaveGeography == TRUE) {
        save(size_data, attr_data, occupation_data, size_stats, attr_bins, attr_probs, occupation_bins, occupation_probs,
                file=sprintf("%sCovidABM7_Jailhouse_ACSAgentSource_%s%s.Rdata", params$indir, state, county))
        print("[Init]          JailHouse Agent initialization Writing Geography to file")
    }
    return()
}


JailHouseACSAgentInit <- function (setupData,popData) {
	print("[Init]          Initializing popData$agents with JailHouse ACS module") 
    
	if (params$UsePreviousAgentPopulation == FALSE) {
	
		if (params$GetNewGeography == TRUE) {
			JailHouseACSAgentSource(params$state, params$county, popData)
		} else {
			#import: attr_data, size_data, occupation_data
		
			Sys.sleep(1)
		
			load(file=sprintf("%sCovidABM7_Jailhouse_ACSAgentSource_%s%s.Rdata", params$indir, params$state, params$county))
			popData$size_data <- size_data
			popData$attr_data <- attr_data
			popData$occupation_data <- occupation_data
			popData$size_stats <- size_stats
			popData$attr_bins <- attr_bins
			popData$attr_probs <- attr_probs
			popData$occupation_bins <- occupation_bins
			popData$occupation_probs <- occupation_probs
			
			print("I got an old geography!")
		}
		#load(file=sprintf("inputs/JailHouse_ACSAgentSource_%d%d.Rdata", 48, 453))
		

		#####----- GENERATE HOUSEHOLDS FROM DISTRIBUTIONS -----#####
	
		dBugInit(sum(popData$size_stats$total_hh))
		
		households <- data.frame(agentIndex = seq(1, sum(popData$size_stats$total_hh)))
		households$tractbg <- as.character(rep(popData$size_stats$tractbg, popData$size_stats$total_hh))
		households <- merge(households, popData$size_stats, by="tractbg")
		households$NumHH <- ceiling(pmax(sapply(households$agentIndex, function (i) rnorm(n=1, mean=households$size_mu[i], sd=households$size_std[i])), 1))
		
		dBugInit("done households$NumHH")

		dBugInit(head(households))
		dBugInit(tail(households))
		dBugInit(nrow(households))
		
		if (params$AgentsAtCentroid == FALSE) {
				# This wont work 
                # note county_BG no longer loaded in
			block_group[,c("WGSlon", "WGSlat")] <- spsample(subset(county_BG, TRACTCE10==popData$size_stats[i,"tract"] & BLKGRPCE10==popData$size_stats[i,"bg"]), n=nrow(block_group), type='random')@coords
		}
		
		dBugInit(head(households))
		dBugInit(tail(households))
		dBugInit(nrow(households))


		dBugInit("doing AgeHH, IncomeHH, RaceHH - expect 10sec")
		households <- households[order(households$tractbg), ]
		AttrTime <- system.time(Attr <- sapply(unique(households$tractbg), function (i) sample(popData$attr_bins, size = nrow(subset(households,tractbg==i)), replace = TRUE, prob = popData$attr_probs[popData$attr_probs$tractbg == i, -1])))
		AttrTime <- AttrTime + system.time(households[,c("AgeHH","IncomeHH","RaceHH")] <- do.call(rbind, unlist(Attr, recursive = FALSE, use.names=FALSE)))
		households$AgeHH <- as.numeric(as.character(households$AgeHH))
		households$IncomeHH <- as.numeric(as.character(households$IncomeHH))
		dBugInit(AttrTime)

		
		dBugInit("doing households$OccupationHH - expect 10sec")
		households <- households[order(households$tractbg), ]
		OccupationTime <- system.time(Occ <- sapply(unique(households$tractbg), function (i) sample(popData$occupation_bins, size = nrow(subset(households,tractbg==i)), replace = TRUE, prob = popData$occupation_probs[popData$occupation_probs$tractbg == i, -1])))
		OccupationTime <- OccupationTime + system.time(households$OccupationHH <- unlist(Occ, recursive = FALSE, use.names=FALSE))
		dBugInit(OccupationTime)

			
		dBugInit(head(households))
		dBugInit(tail(households))
		dBugInit(nrow(households))

		#assign each agent an index
		households$agentIndex <- seq.int(nrow(households))
		households$InfectDate <- NA

		popData$agents <- households[,c("InfectDate","agentIndex","WGSlat","WGSlon","NumHH","AgeHH","IncomeHH","OccupationHH","RaceHH","tractbg")]
		popData$agents$PopID <- popData$agents$agentIndex
		if(params$SaveAgentPopulation == TRUE) {
			#write.csv(popData$agents, file=sprintf("inputs/JailHouse_ACSAgent_%s_%s_%s_%s.csv",as.character(params$state),as.character(params$county),as.character(params$Model), as.character(params$job)))
            print(sprintf("[Init]          Writing Out Agent Population, n= %d", nrow(popData$agents)))
            write.csv(popData$agents, file=sprintf("%s%s%s_%s_%d.csv", params$indir, params$AgentPopulationStub, params$state, params$county, params$Model), row.names=FALSE)
		}
	} else { ### params$UsePreviousAgentPopulation == TRUE

		print("[Init]          Reading in Previous Geography")

		Sys.sleep(1)
	
		load(file=sprintf("%sCovidABM7_Jailhouse_ACSAgentSource_%s%s.Rdata", params$indir, params$state, params$county))
		popData$size_data <- size_data
		popData$attr_data <- attr_data
		popData$occupation_data <- occupation_data
		popData$size_stats <- size_stats
		popData$attr_bins <- attr_bins
		popData$attr_probs <- attr_probs
		popData$occupation_bins <- occupation_bins
		popData$occupation_probs <- occupation_probs
		
		print("[Init]          Reading in Agent Population")
		#popData$agents <- read.csv(file=sprintf("inputs/JailHouse_ACSAgent_%s_%s_%s_%s.csv",as.character(params$state),as.character(params$county),as.character(params$AgentsLoadModel), as.character(params$AgentsLoadJob)))
		#popData$agents <- read.csv(file=sprintf("inputs/JailHouse_ACSAgent_%d_%d_%d_%d_%d.csv", params$state, params$county, params$loadAgentModel, params$loadAgentJob, params$loadAgentBatch))
		#popData$agents <- read.csv(file=sprintf("%sJailHouse_ACSAgent_%d_%d_%d_%d.csv", params$indir, params$state, params$county, params$loadAgentModel, params$loadAgentJob))
		popData$agents <- read.csv(file=sprintf("%s%s%s_%s_%d.csv", params$indir, params$AgentPopulationStub, params$state, params$county, params$loadAgentModel))
		popData$agents$tractbg <- as.character(popData$agents$tractbg)
	}

		
	if (params$UsePreviousAgentSample == TRUE) {
		print("[Init]          Reading in Agent Sample")
		popData$agents <- read.csv(file=sprintf("%s%s%s_%s_%d_%s.csv", params$indir, params$AgentSampleStub, params$state, params$county, params$loadAgentModel, params$loadAgentJob))
	} else { ### params$UsePreviousAgentSample == FALSE
		if(params$RandomSample == TRUE) {
			print("[Init]          JailHouse Agent initialization sampling popData$agents randomly")
			sampleIndex <- sample(popData$agents$agentIndex, size = round(nrow(popData$agents)*params$SampleFrac, 0))
		} else { #representative sampling
			print("[Init]          JailHouse Agent initialization sampling popData$agents representatively")
			sampleIndex <- sapply(unique(popData$agents$tractbg), function(i) sample(subset(popData$agents, tractbg==i)$agentIndex, size = round(length(subset(popData$agents, tractbg==i)$agentIndex)*params$SampleFrac, 0)))
			sampleIndex <- unlist(sampleIndex, use.names = FALSE)
		}
#		agent <- subset(popData$agents, agentIndex %in% sampleIndex)
		popData$agents <- popData$agents[order(popData$agents$agentIndex),]
		popData$agents <- popData$agents[sampleIndex, ]
		
		popData$agents$agentIndex <- seq(1, nrow(popData$agents))
		rownames(popData$agents) <- popData$agents$agentIndex
#		print(sprintf("[Init]          JailHouse Agent initialization loaded %d popData$agents info", nrow(popData$agents)))
		dBugInit(head(popData$agents))

#		params$num_popData$agents = length(popData$agents$agentIndex)
		print(sprintf("[Init]          JailHouse Agent initialization finds %d popData$agents", nrow(popData$agents))) 
		
		print(sprintf("[Init]          JailHouse Agent initialization all %d InfectStatus to Susceptible", nrow(popData$agents))) 
		popData$agents$InfectStatus <- "S"
		
		if(params$Jailhouse_InitialInfectsMethod == "Random") {
			print(sprintf("[Init]          JailHouse Agent initialization Randomly assigning %d initial Infecters", round(params$SampleFrac*params$Jailhouse_InitialInfectsCount, 0))) 
			InfectList <- list(sample(popData$agents$agentIndex, round(params$SampleFrac*params$Jailhouse_InitialInfectsCount, 0), replace=FALSE))
			dBugInit(InfectList)
			popData$agents$initialInfecter <- 0
			dBugInit(table(popData$agents$initialInfecter))
			
			dBugInit(popData$agents$initialInfecter[unlist(InfectList)])
			popData$agents$initialInfecter[unlist(InfectList)] <- 1 

			dBugInit(table(popData$agents$initialInfecter))
			
			#popData$agents$InfectStatus[popData$agents$initialInfecter == 1] = "Ia"
		
		} else if (params$Jailhouse_InitialInfectsMethod == "Localized") {
			print(sprintf("[Init]          JailHouse Agent initialization Randomly assigning %d initial Infecters", round(params$SampleFrac*params$Jailhouse_InitialInfectsCount, 0))) 
			
			whichTractbg <- sample(unique(popData$agents$tractbg), 1)

			print(sprintf("[Init]          JailHouse Agent initialization Localized to tractbg: %s ", whichTractbg)) 

			InfectList <- list(sample(popData$agents$agentIndex[popData$agents$tractbg == whichTractbg], round(params$SampleFrac*params$Jailhouse_InitialInfectsCount, 0), replace=FALSE))
			dBugInit(InfectList)
			popData$agents$initialInfecter <- 0
			dBugInit(table(popData$agents$initialInfecter))
			
			dBugInit(popData$agents$initialInfecter[unlist(InfectList)])
			popData$agents$initialInfecter[unlist(InfectList)] <- 1 

			dBugInit(table(popData$agents$initialInfecter))
			
			#popData$agents$InfectStatus[popData$agents$initialInfecter == 1] = "Ia"
		
		} else if (params$Jailhouse_InitialInfectsMethod == "Targeted") {
			print(sprintf("[Init]          JailHouse Agent initialization Randomly assigning %d initial Infecters", round(params$SampleFrac*params$Jailhouse_InitialInfectsCount, 0))) 
			
			whichTractbg <- as.list(strsplit(as.character(params$tractbgTargets), ";"))[[1]]

			print(sprintf("[Init]          JailHouse Agent initialization Targeted to tractbg: %s ", whichTractbg)) 

			InfectList <- list(sample(popData$agents$agentIndex[popData$agents$tractbg %in% whichTractbg], round(params$SampleFrac*params$Jailhouse_InitialInfectsCount, 0), replace=FALSE))
			dBugInit(InfectList)
			popData$agents$initialInfecter <- 0
			dBugInit(table(popData$agents$initialInfecter))
			
			dBugInit(popData$agents$initialInfecter[unlist(InfectList)])
			popData$agents$initialInfecter[unlist(InfectList)] <- 1 

			dBugInit(table(popData$agents$initialInfecter))
			
			#popData$agents$InfectStatus[popData$agents$initialInfecter == 1] = "Ia"
		
		} else if (params$Jailhouse_InitialInfectsMethod == "Empirical") {
		
			EmpInfected <- popData$agents[popData$agents$InfectDate != "", ]
			dBugInit(head(EmpInfected))
			
			EmpInfected$initialInfecter <- 0
			EmpInfected$initialInfecter[as.Date(EmpInfected$InfectDate, "%m/%d/%y") < as.Date(params$StartDate, "%m/%d/%Y")] = 1 #Set initial Infecters to those that Infect before 2008
			
			dBugInit(str(EmpInfected$InfectDate))
			dBugInit(head(EmpInfected))
				
			print(sprintf("[Init]          JailHouse Agent initialization finds %d initial Infecters", nrow(EmpInfected[EmpInfected$initialInfecter == 1,]))) 
			popData$agents$initialInfecter <- 0
			popData$agents$initialInfecter[popData$agents$agentIndex %in% EmpInfected$agentIndex[EmpInfected$initialInfecter == 1]] <- 1
		}

		if(params$SaveAgentSample == TRUE) {
				#write.csv(popData$agents, file=sprintf("inputs/JailHouse_ACSAgent_%s_%s_%s_%s.csv",as.character(params$state),as.character(params$county),as.character(params$Model), as.character(params$job)))
				print(sprintf("[Init]          Writing Out Agent Sample: n = %d", nrow(popData$agents)))
				#write.csv(popData$agents, file=sprintf("%sJailHouse_ACSAgent_%d_%d_%d_%d.csv", params$indir, params$state, params$county, params$Model, params$job), row.names=FALSE)
				write.csv(popData$agents, file=sprintf("%s%s%s_%s_%d_%s.csv", params$indir, params$AgentSampleStub, params$state, params$county, params$Model, params$job), row.names=FALSE)
		}
	}
	
	popData$agents <- popData$agents
	dBugInit(head(popData$agents))
	
}#------End of JailHouseAgentInit function


JailHouseSocNetInit <- function (setupData,popData) {
	print("[Init]          Initializing Social Network with JailHouse module") 
	
	print("[Init]          JailHouse SocNet initialization checking whether to calculate GeoNei")
	
	if (params$CalcGeoNei == TRUE) {
	
		print("[Init]          JailHouse SocNet initialization calculating GeoNei with block groups")
		
		#load(file=paste0(params$indir,params$ACSstub,params$state,params$county,".Rdata"))
# 		Sys.sleep(1)
# 		
# 		load(file=sprintf("%sCovidABM7_Jailhouse_ACSAgentSource_%s%s.Rdata", params$indir, params$state, params$county))

		dBugInit("Checkpoint 1")
					
		bg_locate   <- popData$size_stats[with(popData$size_stats, order(tractbg)), c("tractbg","WGSlon","WGSlat") ]
#		bg_locate$tractbg <- as.character(paste0("tbg",bg_locate$tract, bg_locate$bg))
		dBugInit(head(bg_locate))
		dBugInit(tail(bg_locate))				
		dBugInit(nrow(bg_locate))		
		dBugInit(length(unique(popData$size_stats$tractbg)))	
		dBugInit("Checkpoint 2")
		
		BG_Coords <- bg_locate[, c("WGSlon","WGSlat")]
		dBugInit(head(BG_Coords))
		dBugInit("Checkpoint 3")
		
		coordinates(BG_Coords) <- ~ WGSlon + WGSlat
		proj4string(BG_Coords) <- CRS("+init=epsg:4326")
		proj4string(BG_Coords) 
		BG_Coords <- spTransform(BG_Coords, CRS("+init=epsg:32610"))
		proj4string(BG_Coords) 
		dBugInit("Checkpoint 4")

		BG_Coords <- as.data.frame(BG_Coords)
		colnames(BG_Coords)[colnames(BG_Coords) == "WGSlon"] = "Easting"
		colnames(BG_Coords)[colnames(BG_Coords) == "WGSlat"] = "Northing"
		dBugInit("Checkpoint 5")

		bg_locate$Easting <- BG_Coords$Easting
		bg_locate$Northing <- BG_Coords$Northing
		
		
		bg_locate_win <- owin(xrange=range(bg_locate$Easting), yrange=range(bg_locate$Northing))
		bg_locate_ppp <- ppp(x=bg_locate$Easting, y=bg_locate$Northing, window=bg_locate_win)
		dBugInit("Checkpoint 6")
		
		if (params$CalcRadius == TRUE) {
	
			print("[Init]          JailHouse SocNet initialization finding GeoNei clustering radius")

			bg_locate_L <- Lest(bg_locate_ppp, border = best, r=seq(0, 10000, by = 100))
			bg_locate_L$Ldiff <- bg_locate_L$border - bg_locate_L$theo
			GeoNeiDistance <- bg_locate_L$theo[bg_locate_L$Ldiff == max(bg_locate_L$Ldiff)]
			GeoNeimaxL <- bg_locate_L$Ldiff[bg_locate_L$Ldiff == max(bg_locate_L$Ldiff)]

			GeoNeiDistance_M <- GeoNeiDistance*0.3048


			print(sprintf("[Init]          JailHouse SocNet initialization finds informative radius at %d feet, L Difference: %f", GeoNeiDistance, GeoNeimaxL))	
		} else {
		GeoNeiDistance <- params$GeoNeiDistance
		}

		getRadiusGeoNei_bg <- function (bg_ID) {
					
			precandidates <- bg_locate
			precandidates$dist <- sqrt((precandidates$Easting - precandidates$Easting[precandidates$tractbg == bg_ID])^2 + (precandidates$Northing - precandidates$Northing[precandidates$tractbg == bg_ID])^2)

			precandidates$GeoNei <- 0
			precandidates$GeoNei[precandidates$dist <= GeoNeiDistance] = 1

			GeoNei_bg <- list(as.character(precandidates$tractbg[precandidates$GeoNei == 1]))
			return(GeoNei_bg)

		}
		dBugInit("Checkpoint 7")
		setupData$GeoneiDF_bg <- data.frame(tractbg = bg_locate$tractbg)
		setupData$GeoneiDF_bg$GeoNei_bg <- I(list(0))

		GeoNei_bgTime <- system.time(setupData$GeoneiDF_bg$GeoNei_bg <- lapply(setupData$GeoneiDF_bg$tractbg, function (i) getRadiusGeoNei_bg(i)))
		dBugInit(GeoNei_bgTime)
		dBugInit("Checkpoint 8")
		
		dBugInit(head(setupData$GeoneiDF_bg))
		dBugInit(tail(setupData$GeoneiDF_bg))				
		dBugInit(nrow(setupData$GeoneiDF_bg))

		setupData$GeoneiDF <- data.frame(agentIndex = popData$agents$agentIndex, tractbg=as.factor(popData$agents$tractbg))
		setupData$GeoneiDF$GeoNei <- I(list(0))
		dBugInit("Checkpoint 9")
				
		print("[Init]          JailHouse SocNet initialization getting GeoNei ... this may take a while for many, many popData$agents")
		print(sprintf("[Init]          JailHouse SocNet initialization striping by %d...", params$stripingValue))
		stripes <- seq(1, params$stripingValue)
		setupData$GeoneiDF$stripe <- sample(stripes, size=nrow(setupData$GeoneiDF), replace=TRUE)

		getRadiusGeoNei <- function (agentIndex) {
				
			agent_bg <- popData$agents$tractbg[agentIndex]	
					
			close_bgs <- unlist(setupData$GeoneiDF_bg$GeoNei_bg[setupData$GeoneiDF_bg$tractbg == agent_bg])
			
			GeoNeiCandidates <- list(as.character(popData$agents$agentIndex[popData$agents$tractbg %in% close_bgs]))
			
			GeoNei <- list(sample(unlist(GeoNeiCandidates), length(unlist(GeoNeiCandidates)), replace=FALSE)) 
			return(GeoNei)
		}

		mclapply(stripes, function (s) { 
			print(sprintf("[Init]          JailHouse SocNet initialization doing stripe %d using %d cores", s, params$cores))
			GeoneiDF_tmp <- setupData$GeoneiDF[setupData$GeoneiDF$stripe == s, ]
			GeoNeiTime <- system.time(GeoneiDF_tmp$GeoNei <- lapply(GeoneiDF_tmp$agentIndex, function (i) getRadiusGeoNei(i)))
			
			GeoneiDF_tmp$GeoNei <- lapply(GeoneiDF_tmp$agentIndex, function (i) {
				list(unlist(GeoneiDF_tmp$GeoNei[GeoneiDF_tmp$agentIndex == i])[unlist(GeoneiDF_tmp$GeoNei[GeoneiDF_tmp$agentIndex == i]) != i])			
			})
			
			GeoneiDF_tmp$Geok <- sapply(GeoneiDF_tmp$GeoNei, function (k) length(unlist(k)))
			print(sprintf("[Init]          JailHouse SocNet initialization saving stripe %d", s))
			save(GeoneiDF_tmp, file=sprintf("%s%d_%s_%s.Rdata",params$GeoNeiFilestub, s, params$Model, params$job))
		}, mc.cores = params$cores)


	} else {
		print("[Init]          JailHouse SocNet initialization not calculating GeoNei")
	}
	
	print("[Init]          JailHouse SocNet initialization checking whether to calculate locals...")
	
	if (params$CalcLocals == TRUE) {
		
		setupData$LocalneiDF <- NULL

		
		print("[Init]          JailHouse SocNet initialization calculating locals")
		stripes <- seq(1, params$stripingValue)

		sapply(stripes, function (s) { 
			print(sprintf("[Init]          JailHouse SocNet initialization loading GeoNei stripe %d", s))
			load(file=sprintf("%s%d_%s_%s.Rdata",params$GeoNeiFilestub, s, params$Model, params$job))
			
			print(sprintf("[Init]          JailHouse SocNet initialization getting EGO home values for stripe %d", s))
			
			LocalneiDF_tmp <- data.frame(agentIndex = GeoneiDF_tmp$agentIndex)
			LocalneiDF_tmp$IncomeHH <- as.numeric(popData$agents$IncomeHH[fmatch(GeoneiDF_tmp$agentIndex, popData$agents$agentIndex)])
			LocalneiDF_tmp$GeoNei <- GeoneiDF_tmp$GeoNei
			LocalneiDF_tmp$Geok <- GeoneiDF_tmp$Geok
			

			get_NeilistIncome <- function (agentIndList) {
	 			lapply(agentIndList, function (agInd) as.numeric(popData$agents$IncomeHH[fmatch(agInd, popData$agents$agentIndex)]))
	 		}

			print(sprintf("[Init]          JailHouse SocNet initialization getting ALTER home values for stripe %d", s))
			IncomeTime <- system.time(LocalneiDF_tmp$IncomeList_agIndex <- mclapply(LocalneiDF_tmp$GeoNei, function(agentIndList) unlist(get_NeilistIncome(agentIndList)), mc.cores=params$cores))

			dBugInit(IncomeTime)

			print(sprintf("[Init]          JailHouse SocNet initialization getting Squared Difference in home values for stripe %d", s))
			zipper_vec <- seq(1:nrow(LocalneiDF_tmp))
			
			dBugInit(head(LocalneiDF_tmp))
			dBugInit(str(LocalneiDF_tmp))


			LocalneiDF_tmp$IncomeListDiff2_agIndex <- sapply(zipper_vec, function (zip) (unlist(LocalneiDF_tmp$IncomeList_agIndex[zip]) - LocalneiDF_tmp$IncomeHH[zip])^2 )
	#			dBugInit("head(LocalneiDF_tmp$IncomeListDiff2_agIndex)")
	#			dBugInit(head(LocalneiDF_tmp$IncomeListDiff2_agIndex))

			print(sprintf("[Init]          JailHouse SocNet initialization calculating homophily constraint, rho=%f", params$FIT_rho))
			LocalneiDF_tmp$kLocals <- ceiling(LocalneiDF_tmp$Geok * params$FIT_rho)
			dBugInit(head(LocalneiDF_tmp$kLocals))			

		
			print(sprintf("[Init]          JailHouse SocNet initialization applying homophily constraint, rho=%f, on stripe %d", params$FIT_rho, s))
			
			dBugInit(head(LocalneiDF_tmp))
			
			orderAlters_Diff <- function (zippIndex) { 
				inorder <- order(unlist(LocalneiDF_tmp$IncomeListDiff2_agIndex[zippIndex]))
				constrained <- inorder[1:LocalneiDF_tmp$kLocals[zippIndex]]
				HCneiList <- unlist(LocalneiDF_tmp$GeoNei[zippIndex])[constrained]
				return(HCneiList)
			}
			dBugInit("LocalneiDF_tmp$LocalsAgentIndex : Should be empty?")
			dBugInit(LocalneiDF_tmp$LocalsAgentIndex)
			orderTime <- system.time(LocalneiDF_tmp$LocalsAgentIndex <- mclapply(zipper_vec, function (zip) orderAlters_Diff(zip), mc.cores=params$cores) )
			dBugInit(orderTime)
			dBugInit("head(LocalneiDF_tmp$LocalsAgentIndex: Should NOT be Empty)")
			dBugInit(head(LocalneiDF_tmp$LocalsAgentIndex))

			print(sprintf("[Init]          JailHouse SocNet initialization accumulating stripe %d", s))

			dBugInit(head(LocalneiDF_tmp))

			setupData$LocalneiDF <- rbind(setupData$LocalneiDF, LocalneiDF_tmp[, c("agentIndex","kLocals", "LocalsAgentIndex")])	
		})	
		
		setupData$LocalneiDF <- setupData$LocalneiDF[order(setupData$LocalneiDF$agentIndex), ] 

		if (params$SaveLocals == TRUE) {
			print("[Init]          JailHouse SocNet initialization saving locals - OVERWRITING")
 			neiDF <- setupData$LocalneiDF
			save(neiDF, file=sprintf("%s%s%s_%s_%d_%f.Rdata", params$indir, as.character(params$LocalsFilestub), params$state, params$county, params$Model, params$FIT_rho)) 
		}
	
		dBugInit(head(setupData$LocalneiDF))
		dBugInit(tail(setupData$LocalneiDF))				
		dBugInit(nrow(setupData$LocalneiDF))

	} else {
		print("[Init]          JailHouse SocNet initialization not calculating locals")
		load(file=sprintf("%s%s%s_%s_%d_%f.Rdata", params$indir, as.character(params$LocalsFilestub), params$state, params$county, params$loadAgentModel, params$FIT_rho))
	}	
	if (params$DoRewiring == TRUE) { 
		dBugInit(sprintf("Minimum number locals: %d", min(setupData$LocalneiDF$kLocals)))
		print(sprintf("[Init]          JailHouse SocNet initialization SWN random additional wiring with lambda:%f...", params$FIT_lambda))
	
		SWNedgeCount = round(params$FIT_lambda * setupData$LocalneiDF$kLocals)
	
		dBugInit(sprintf("Minimum number SWN rewires: %d", min(SWNedgeCount)))
		dBugInit("But every Agent gets at least one random connection")
		SWNedgeCount[SWNedgeCount == 0] = 1

		dBugInit(sprintf("New minimum number SWN rewires: %d", min(SWNedgeCount)))

		setupData$JailHouseLocals <- setupData$LocalneiDF$LocalsAgentIndex
		setupData$JailHousenonLocals <- sapply(SWNedgeCount, sample, x = popData$agents$agentIndex, replace = F )
	
		dBugInit(head(setupData$LocalneiDF))
		
		dBugInit(head(setupData$LocalneiDF$LocalsAgentIndex))
		dBugInit(head(setupData$JailHousenonLocals))
	
		popData$JailHouseAlter_vec <- mapply(c, setupData$JailHouseLocals, setupData$JailHousenonLocals)
	
		dBugInit("Check Atler_vec for popData$agents w/ no locals")
		dBugInit(popData$JailHouseAlter_vec[setupData$LocalneiDF$kLocals == 0])		

		dBugInit("get rid of NA's in Locals part of Alter_vec by replacing with nonLocals only")

		popData$JailHouseAlter_vec[setupData$LocalneiDF$kLocals == 0] <- setupData$JailHousenonLocals[setupData$LocalneiDF$kLocals == 0]
	
		dBugInit("Check Atler_vec for popData$agents w/ no locals")
		dBugInit(popData$JailHouseAlter_vec[setupData$LocalneiDF$kLocals == 0])
		
		print("[Init]          JailHouse SocNet initialization SWN random additional wiring done")
	} else {
		print("[Init]          JailHouse SocNet initialization skipping SWN random additional wiring")
		print("[Init]          JailHouse SocNet initialization loading SocNet from file")
		load(file=sprintf("%s%s%s_%s_b%s_job%s.Rdata", params$indir, as.character(params$SocNetFilestub), params$ModelType, params$loadAgentModel, params$loadAgentBatch, params$loadAgentJob) )
		popData$JailHouseAlter_vec <- SocNet
	}
	print("[Init]          JailHouse SocNet cleaning up")
	if (params$SaveSocNet == TRUE) {
		SocNet <- popData$JailHouseAlter_vec
		save(SocNet, file=sprintf("%s%s%s_%s_b%d_job%s.Rdata", params$outdir, as.character(params$SocNetFilestub), params$ModelType, params$Model, b, params$job) )
	}#------End of SocNetOut check

	setupData$JailHousenonLocals <- NULL
	setupData$JailHouseLocals <- NULL
	print("[Init]          JailHouse SocNet finished")
	
}#------End of JailHouseSocNetInit function

#-----------------------------#
# Determine Initialization Routine
#-----------------------------#

initModel <- function () {	
	print("[Init]          Determining Initialization Routine...")
	print(sprintf("[Init]          Agent Initialization Type is: %s", params$InitAgentMod))
	print(sprintf("[Init]          Social Net Initialization Type is: %s", params$InitSocNetMod))
	print(sprintf("[Init]          Runtime Initialization Type is: %s", params$RuntimeStageMod))
	print("[Init]          Initialization Routine determined")
	
	popData <- populationDataClass$new()
	setupData <- setupDataClass$new()

	if (params$InitAgentMod == "JailHouse_ACS") {
		JailHouseACSAgentInit(setupData, popData)
	}#------End of JailHouse Agent init check

	if (params$InitSocNetMod == "JailHouse") {
		JailHouseSocNetInit(setupData, popData)
	}#------End of JailHouse Social Net init check
	if (params$SocNetOut == "On") {
			if (params$InitSocNetMod == "JailHouse") {
				SocNet <- popData$JailHouseAlter_vec
				save(SocNet, file=sprintf("%s%s%s_%s_b%d_job%s.Rdata", params$outdir, as.character(params$SocNetFilestub), params$ModelType, params$Model, b, params$job) )
		}#------End of JailHouse Social Net init check
	}#------End of SocNetOut check


	# Lock down the initial population samples to prevent accidental modification
	popData$lockdown()

	# Stricty speaking, probably not needed. Still good to nuke.
	rm(setupData)
	
	sapply(seq(1, params$stripingValue), function (s) { 
		print(sprintf("[Init]          Removing GeoNei stripe %d", s))
		if (file.exists(sprintf("%s%d_%s_%s.Rdata",params$GeoNeiFilestub, s, params$Model, params$job)))
			file.remove(sprintf("%s%d_%s_%s.Rdata",params$GeoNeiFilestub, s, params$Model, params$job))
	})
  


	return(popData)
}#------End of initModel