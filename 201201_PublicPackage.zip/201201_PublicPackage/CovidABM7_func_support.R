# CoPE – COVID-19 Policy Evaluation tool
#
# An agent-based model of the social spread of COVID-19 with a focus on 
# individual-level behavioral responses to policy. 
# 
# Thank you for your interest in CoPE. 
# If your use of CoPE results in a publication, please cite as follows: 
# 
# Rai Group. (2020). CoPE: COVID-19 Policy Evaluation tool
# 	 Version 0.1. [Computer Software].
#
# This project is under active development. If you find something that needs our 
# attention, please send a message to BAMEx.devs@gmail.com. 
# Your feedback and input is extremely valuable. Thank you!
#
# 
# CovidABM7 
# UT Austin, RaiGroup
# Created: 06/12/2020
#
# 

#-----------------------------#
# Load libraries
#-----------------------------#
library(R6)


if (paramsDF$InitAgentMod[1] == "JailHouse_ACS") {
	#note sure if this is the right paramsDF, you need sp if you want to generate new agents
	#you need these packages if the input file hasn't been generated yet
	if (paramsDF$GetNewGeography[1] == TRUE) {
		library(sp)
		library(rgdal)
		library(jsonlite)
	}
	if (paramsDF$CalcGeoNei[1] == TRUE) {
		library(spatstat)
		library(sp)
		library(parallel)
	}
	if (paramsDF$CalcLocals[1] == TRUE) {
		library(parallel)
	}
}

if (paramsDF$InitSocNetMod[1] == "JailHouse") {
	library(fastmatch)
	if (paramsDF$CalcGeoNei[1] == TRUE) {
		library(spatstat)
		library(sp)
		library(parallel)
	}
	if (paramsDF$CalcLocals[1] == TRUE) {
		library(parallel)
	}
}

if (paramsDF$RuntimeStageMod[1] == "JailHouse") {
	library(lubridate)
	library(compiler)
	library(parallel)
}
#-----------------------------#
# Debugging verbosity
#-----------------------------#

debugCore <- function(arg){
	if(is.character(arg)){
		print(arg)
	}else{
		argname <- deparse(substitute(arg))
		print(argname)
		print(arg)
	}
}

quitAndDumpGlobals <- function(location=""){
	print(sprintf("Quitting at location %s", location))
	save(Context,JailHouseagentWGSlat_vec,JailHouseagentWGSlon_vec,
	     JailHouseagentIndex_vec,JailHouseagentPopID_vec,JailHouseagentJob_vec,
		 JailHouseInfectStatus_vec,JailHouseFloutStatus_vec,JailHouseTestStatus_vec,
		 JailHouseQuarantineTill_vec,JailHouseGroupThresh_vec,Progress_Turns,
		 progressions,JailHouseDirectExposures_vec,JailHouseFloutInfects_vec,
		 JailHouseIaInfects_vec,JailHouseEssentialInfects_vec,EssentialAct_W,
		 NonEssentialAct_W,YesterdayFloutTargets,Turns,PastTurns,agents,
		 JailHouseAlter_vec,JailHouseRandomStable_vec,
		 file = "outputs/globalframe.RData", version = NULL, ascii = TRUE,
           	   compress = FALSE)
	q()
}

if ("MakeTurns" %in% as.list(strsplit(as.character(paramsDF$dBug[1]), ";"))[[1]]) {
	debugCore("[Support] MakeTurns Debug on")
	dBugMakeTurns = debugCore
} else { dBugMakeTurns = function (m) {} } 

if ("Turn" %in% as.list(strsplit(as.character(paramsDF$dBug[1]), ";"))[[1]]) {
	debugCore("[Support] Turn Debug on")
	dBugTurn = debugCore
} else { dBugTurn = function (m) {} } 

if ("TakeTurns" %in% as.list(strsplit(as.character(paramsDF$dBug[1]), ";"))[[1]]) {
	debugCore("[Support] TakeTurns Debug on")
	dBugTakeTurns = debugCore
} else { dBugTakeTurns = function (m) {} } 

if ("OneShot" %in% as.list(strsplit(as.character(paramsDF$dBug[1]), ";"))[[1]]) {
	debugCore("[Support] OneShot Debug on")
	dBugOneShot = debugCore
} else { dBugOneShot = function (m) {} } 

if ("Control" %in% as.list(strsplit(as.character(paramsDF$dBug[1]), ";"))[[1]]) {
	debugCore("[Support] Control Debug on")
	dBugControl = debugCore
} else { dBugControl = function (m) {} } 

if ("Init" %in% as.list(strsplit(as.character(paramsDF$dBug[1]), ";"))[[1]]) {
	debugCore("[Support] Init Debug on")
	dBugInit = debugCore
} else { dBugInit = function (m) {} } 

if ("Stage" %in% as.list(strsplit(as.character(paramsDF$dBug[1]), ";"))[[1]]) {
	debugCore("[Support] Stage Debug on")
	dBugStage =debugCore
} else { dBugStage = function (m) {} } 

if ("Run" %in% as.list(strsplit(as.character(paramsDF$dBug[1]), ";"))[[1]]) {
	debugCore("[Support] Run Debug on")
	dBugRun =debugCore
} else { dBugRun = function (m) {} } 

if ("Day" %in% as.list(strsplit(as.character(paramsDF$dBug[1]), ";"))[[1]]) {
	debugCore("[Support] Day Debug on")
	dBugDay = debugCore
} else { dBugDay = function (m) {} } 

if ("Step" %in% as.list(strsplit(as.character(paramsDF$dBug[1]), ";"))[[1]]) {
	debugCore("[Support] Step Debug on")
	dBugStep = debugCore
} else { dBugStep = function (m) {} } 

if ("Substep" %in% as.list(strsplit(as.character(paramsDF$dBug[1]), ";"))[[1]]) {
	debugCore("[Support] Substep Debug on")
	dBugSubstep = debugCore
} else { dBugSubstep = function (m) {} } 

if ("Outs" %in% as.list(strsplit(as.character(paramsDF$dBug[1]), ";"))[[1]]) {
	debugCore("[Support] Output Debug on")
	dBugOuts = debugCore
} else { dBugOuts = function (m) {} } 
