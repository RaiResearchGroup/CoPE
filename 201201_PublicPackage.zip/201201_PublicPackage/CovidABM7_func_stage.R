# CoPE – COVID-19 Policy Evaluation tool
#
# An agent-based model of the social spread of COVID-19 with a focus on 
# individual-level behavioral responses to policy. 
# 
# Thank you for your interest in CoPE. 
# If your use of CoPE results in a publication, please cite as follows: 
# 
# Rai Group. (2020). CoPE: COVID-19 Policy Evaluation tool
# 	 Version 0.1. [Computer Software].
#
# This project is under active development. If you find something that needs our 
# attention, please send a message to BAMEx.devs@gmail.com. 
# Your feedback and input is extremely valuable. Thank you!
#
# 
# CovidABM7 
# UT Austin, RaiGroup
# Created: 06/12/2020
#
# 

JailHouseRuntimeStaging <- function (populationData) {
	print("[CoreStage]          Staging Runtime with JailHouse module") 

	runData <- jailhouseRunDataClass$new()

	# agents and Alter_vec are copied into runData at the end of staging. For now,
	# use the versions in populationData to avoid accidental modifications

	print("[CoreStage]          Staging Context") 
	dBugStage(sprintf("looking for  %s%s", params$indir, as.character(params$ContextData)))
	runData$Context <- read.csv(file = sprintf("%s%s", params$indir, as.character(params$ContextData)))
	dBugStage(head(runData$Context))
	runData$Context$modeltime <- runData$Context$Day
#	decimal_date(as.Date(ADPPolicy$Dates)) - decimal_date(as.Date(params$StartDate, "%m/%d/%Y"))
	dBugStage(head(runData$Context))

	if (params$ModelType == "SIPParamBlast") {
		print("[Run]     This is a SIP ParamBlast run")
		
		dBugOneShot(runData$Context)
		
		dBugOneShot(params$Jailhouse_SIPTiming)

		dBugOneShot(params$Jailhouse_SIPDuration)
		
		runData$Context$modeltime[length(runData$Context$Jailhouse_Awareness[runData$Context$Jailhouse_Awareness == 0])+1] <- params$Jailhouse_SIPTiming
		runData$Context$modeltime[length(runData$Context$Jailhouse_Awareness[runData$Context$Jailhouse_Awareness == 0])+2] <- params$Jailhouse_SIPDuration

		dBugOneShot(runData$Context)
		
		print(sprintf("[Run]     SIP Timing set to: %d and Duration set to %d",runData$Context$modeltime[length(runData$Context$Jailhouse_Flout_Rate[runData$Context$Jailhouse_Flout_Rate == 1])+1] , runData$Context$modeltime[length(runData$Context$Jailhouse_Flout_Rate[runData$Context$Jailhouse_Flout_Rate == 1])+2]))	
		
		print("[Run]     ... Values Generated")
	}


	print("[CoreStage]          Staging Agents") 
	dBugStage(head(populationData$agents))
	runData$agentWGSlat_vec <- as.numeric(populationData$agents$WGSlat)			# Also keep in in a vector
	dBugStage(sprintf("runData$agentWGSlat_vec length: %d", length(runData$agentWGSlat_vec)))

	runData$agentWGSlon_vec <- as.numeric(populationData$agents$WGSlon)			# Also keep in in a vector
	dBugStage(sprintf("runData$agentWGSlon_vec length: %d", length(runData$agentWGSlon_vec)))

	runData$agentIndex_vec <- as.numeric(populationData$agents$agentIndex)			# Also keep in in a vector
	dBugStage(sprintf("runData$agentIndex_vec length: %d", length(runData$agentIndex_vec)))
	dBugStage(head(runData$agentIndex_vec))
	
	runData$agentPopID_vec <- as.numeric(populationData$agents$PopID)			# Also keep in in a vector
	dBugStage(sprintf("runData$agentPopID_vec length: %d", length(runData$agentPopID_vec)))
	dBugStage(head(runData$agentPopID_vec))

	runData$agentJob_vec <- as.character(populationData$agents$OccupationHH)			# Also keep in in a vector
	dBugStage(head(runData$agentJob_vec))

	runData$InfectStatus_vec <- as.character(populationData$agents$InfectStatus)			# Also keep in in a vector
	dBugStage(table(populationData$agents$InfectStatus_vec, exclude=NULL))
	dBugStage(table(runData$InfectStatus_vec, exclude=NULL))

	runData$FloutStatus_vec <- rep("Flout", nrow(populationData$agents))		# Also keep in in a vector
	dBugStage(table(runData$FloutStatus_vec, exclude=NULL))

	runData$TestStatus_vec <- rep("None", nrow(populationData$agents))		# Also keep in in a vector
	dBugStage(table(runData$TestStatus_vec, exclude=NULL))
	
	runData$QuarantineTill_vec <- rep(NA, nrow(populationData$agents))		# Also keep in in a vector
	dBugStage(table(runData$QuarantineTill_vec, exclude=NULL))
	
	runData$RandomStable_vec <-runif(nrow(populationData$agents), -1, 1)
	dBugStage(summary(runData$RandomStable_vec))

	# The global RiskTol vec is currently immediately overridden by the code in daily
	# setup and is otherwise unneeded outside of the individual day's data. We need it
	# here to set up the GroupThresh, so we'll compute it as a local varible.
# 	setup_RiskTol_vec <- exp(params$Jailhouse_Risk_b0 + params$Jailhouse_Risk_b1*populationData$agents$AgeHH + params$Jailhouse_Risk_b2*I(populationData$agents$AgeHH^2))/(1+exp(params$Jailhouse_Risk_b0 + params$Jailhouse_Risk_b1*populationData$agents$AgeHH + params$Jailhouse_Risk_b2*I(populationData$agents$AgeHH^2)))
#	setup_RiskTol_vec <- exp(params$Jailhouse_Risk_b0 + params$Jailhouse_Risk_b1*populationData$agents$AgeHH)/
#	                             (1+exp(params$Jailhouse_Risk_b0 + params$Jailhouse_Risk_b1*populationData$agents$AgeHH))
	
	if (params$Jailhouse_DifferentRiskTols == "Off_Young") {
		setup_RiskTol_vec <- exp(params$Jailhouse_Risk_b0 + params$Jailhouse_Risk_b1*min(populationData$agents$AgeHH))/
			(1+exp(params$Jailhouse_Risk_b0 + params$Jailhouse_Risk_b1*min(populationData$agents$AgeHH)))
		setup_RiskTol_vec <- rep_len(setup_RiskTol_vec, nrow(populationData$agents))
	} else if (params$Jailhouse_DifferentRiskTols == "Off_Old") {
		setup_RiskTol_vec <- exp(params$Jailhouse_Risk_b0 + params$Jailhouse_Risk_b1*max(populationData$agents$AgeHH))/
			(1+exp(params$Jailhouse_Risk_b0 + params$Jailhouse_Risk_b1*max(populationData$agents$AgeHH)))
		setup_RiskTol_vec <- rep_len(setup_RiskTol_vec, nrow(populationData$agents))
	} else if (params$Jailhouse_DifferentRiskTols == "On_Rand") {
		setup_RiskTol_vec <- runif(n=nrow(populationData$agents), min=0, max=0.5)
	} else {
		setup_RiskTol_vec <- exp(params$Jailhouse_Risk_b0 + params$Jailhouse_Risk_b1*populationData$agents$AgeHH)/
			(1+exp(params$Jailhouse_Risk_b0 + params$Jailhouse_Risk_b1*populationData$agents$AgeHH))
	}

	dBugStage(table(setup_RiskTol_vec))
	dBugStage(summary(setup_RiskTol_vec))
	dBugStage(table(populationData$agents$AgeHH, setup_RiskTol_vec))
	dBugStage(head(setup_RiskTol_vec))
	dBugStage(head(populationData$agents$AgeHH))
	dBugStage(plot(populationData$agents$AgeHH, setup_RiskTol_vec))
	runData$RiskTol_vec <- setup_RiskTol_vec
	
	runData$GroupThresh_vec <- round(0.5 * rpois(n=length(runData$FloutStatus_vec), lambda = params$Jailhouse_GroupThreshMax), 0)
	runData$GroupThresh_vec[runData$GroupThresh_vec <= 1] <- 2
	dBugStage(table(runData$FloutStatus_vec, exclude=NULL))
	dBugStage(table(runData$GroupThresh_vec, exclude=NULL))
	dBugStage(length(runData$FloutStatus_vec))
	dBugStage(length(runData$GroupThresh_vec))
	dBugStage(table(runData$FloutStatus_vec, runData$GroupThresh_vec, exclude=NULL))

	dBugStage(head("JailHouseAlter_vec"))
	dBugStage(head(JailHouseAlter_vec))

	print("[CoreStage]          Staging All Progressions") 
			
	runData$Progress_Turns <- NULL
	
	ProgressMapTime <- system.time({
		progressions <- data.frame(agentIndex = runData$agentIndex_vec)	
		progressions$E2_Pa_or_Py <- sample(c("Pa","Py"), nrow(progressions), replace=TRUE, 
		                       prob=c(params$JailHouse_Prob_E_Pa, (1-params$JailHouse_Prob_E_Pa)))
		progressions$E2_Pa2_Rr <- "Not"
		progressions$E2_Pa2_Rr[progressions$E2_Pa_or_Py == "Pa" ] = "Rr"
		progressions$E2_Py2_Rr <- "Not"
		progressions$E2_Py2_Ih <- "Not"
		progressions$E2_Py2_Rr_or_Ih <- "Not"
		progressions$E2_Py2_Rr_or_Ih[progressions$E2_Pa_or_Py == "Py"] <- sample(c("Rr","Ih"), 
		                            nrow(progressions[progressions$E2_Pa_or_Py == "Py", ]), replace=TRUE, 
									prob=c(params$JailHouse_Prob_Iy_Rr, (1-params$JailHouse_Prob_Iy_Rr)))
		progressions$E2_Py2_Rr[progressions$E2_Py2_Rr_or_Ih == "Rr" ] = "Rr"
		progressions$E2_Py2_Ih[progressions$E2_Py2_Rr_or_Ih == "Ih" ] = "Ih"
		progressions$E2_Py2_Ih2_Rr <- "Not"
		progressions$E2_Py2_Ih2_Rd <- "Not"
		progressions$E2_Py2_Ih2_Rr_or_Rd <- "Not"
		
		if (params$JailHouse_Durations_UseAges == FALSE) {
			progressions$E2_Py2_Ih2_Rr_or_Rd[progressions$E2_Py2_Rr_or_Ih == "Ih"] <- sample(c("Rr","Rd"), 
			                                                       nrow(progressions[progressions$E2_Py2_Rr_or_Ih == "Ih", ]),
																   replace=TRUE, prob=c(params$JailHouse_Prob_Ih_Rr, 
																   (1-params$JailHouse_Prob_Ih_Rr)))

		} else if (params$JailHouse_Durations_UseAges == TRUE) {
			print("[CoreStage]          Doing age-based progressions")
			progressions$AgeHH <- populationData$agents$AgeHH
			
			IytoUseAges_vec <- as.numeric(as.list(strsplit(as.character(params$JailHouse_Prob_Iy_Rr_age), ";"))[[1]])

			dBugOneShot(IytoUseAges_vec)
			
			progressions$PrRr_or_Ih[progressions$AgeHH < 49] <- IytoUseAges_vec[1]
			progressions$PrRr_or_Ih[progressions$AgeHH >= 49 & progressions$AgeHH < 64] <- IytoUseAges_vec[2]
			progressions$PrRr_or_Ih[progressions$AgeHH >= 64] <- IytoUseAges_vec[3]

			progressions$E2_Py2_Rr_or_Ih[progressions$E2_Pa_or_Py == "Py"] <- sapply(
				progressions$agentIndex[progressions$E2_Pa_or_Py == "Py"], function (i) {
					sample(c("Rr","Ih"), 1, replace=FALSE, prob=c(progressions$PrRr_or_Ih[i], (1-progressions$PrRr_or_Ih[i])))
				}
			)
			dBugStage(head(progressions[progressions$E2_Py2_Rr_or_Ih == "Ih",]))			


			IhtoUseAges_vec <- as.numeric(as.list(strsplit(as.character(params$JailHouse_Prob_Ih_Rr_age), ";"))[[1]])

			dBugOneShot(IhtoUseAges_vec)
			
			progressions$PrRr_or_Rd[progressions$AgeHH < 49] <- IhtoUseAges_vec[1]
			progressions$PrRr_or_Rd[progressions$AgeHH >= 49 & progressions$AgeHH < 64] <- IhtoUseAges_vec[2]
			progressions$PrRr_or_Rd[progressions$AgeHH >= 64] <- IhtoUseAges_vec[3]
			
			progressions$E2_Py2_Ih2_Rr_or_Rd[progressions$E2_Py2_Rr_or_Ih == "Ih"] <- sapply(
				progressions$agentIndex[progressions$E2_Py2_Rr_or_Ih == "Ih"], function (i) {
					sample(c("Rr","Rd"), 1, replace=FALSE, prob=c(progressions$PrRr_or_Rd[i], (1-progressions$PrRr_or_Rd[i])))
				}
			)
			dBugStage(head(progressions[progressions$E2_Py2_Rr_or_Ih == "Ih",]))			
		}

		progressions$E2_Py2_Rr[progressions$E2_Py2_Rr_or_Ih == "Rr" ] = "Rr"
		progressions$E2_Py2_Ih[progressions$E2_Py2_Rr_or_Ih == "Ih" ] = "Ih"

		progressions$E2_Py2_Ih2_Rr[progressions$E2_Py2_Ih2_Rr_or_Rd == "Rr" ] = "Rr"
		progressions$E2_Py2_Ih2_Rd[progressions$E2_Py2_Ih2_Rr_or_Rd == "Rd" ] = "Rd"
		
		dBugStage(head(progressions))
		
		dBugStage("table(progressions$E2_Py2_Rr_or_Ih[progressions$E2_Pa_or_Py == Py], progressions$AgeHH[progressions$E2_Pa_or_Py == Py])")
		dBugStage(table(progressions$E2_Py2_Rr_or_Ih[progressions$E2_Pa_or_Py == "Py"], progressions$AgeHH[progressions$E2_Pa_or_Py == "Py"]))

		dBugStage("table(progressions$E2_Py2_Ih2_Rr_or_Rd[progressions$E2_Py2_Rr_or_Ih == Ih], progressions$AgeHH[progressions$E2_Py2_Rr_or_Ih == Ih])")
		dBugStage(table(progressions$E2_Py2_Ih2_Rr_or_Rd[progressions$E2_Py2_Rr_or_Ih == "Ih"], progressions$AgeHH[progressions$E2_Py2_Rr_or_Ih == "Ih"]))
		
	}, gcFirst = FALSE)
	dBugStage(ProgressMapTime)
	dBugStage(table(progressions$E2_Py2_Rr_or_Ih,populationData$agents$AgeHH ))
	dBugStage(table(progressions$E2_Py2_Ih2_Rr_or_Rd,populationData$agents$AgeHH ))
	E_TimingTime <- system.time({
		progressions$E_rand <- runif(n = nrow(progressions), min = 0, max = 1)
		progressions$E_EndTime <- (-log(1-progressions$E_rand)/I(1/params$JailHouse_Duration_E))
	}, gcFirst = FALSE)
	dBugStage(E_TimingTime)
	
	Pa_TimingTime <- system.time({
		progressions$Pa_rand <- runif(n = nrow(progressions), min = 0, max = 1)
		progressions$Pa_EndTime <- progressions$E_EndTime + (-log(1-progressions$Pa_rand)/I(1/params$JailHouse_Duration_Pa))
	}, gcFirst = FALSE)
	dBugStage(Pa_TimingTime)
	
	Py_TimingTime <- system.time({
		progressions$Py_rand <- runif(n = nrow(progressions), min = 0, max = 1)
		progressions$Py_EndTime <- progressions$E_EndTime + (-log(1-progressions$Py_rand)/I(1/params$JailHouse_Duration_Py))
	}, gcFirst = FALSE)
	dBugStage(Py_TimingTime)
	
	Ia_TimingTime <- system.time({
		progressions$Ia_rand <- runif(n = nrow(progressions), min = 0, max = 1)
		progressions$Ia_EndTime <- progressions$Pa_EndTime + (-log(1-progressions$Ia_rand)/I(1/params$JailHouse_Duration_Ia))
	}, gcFirst = FALSE)
	dBugStage(Ia_TimingTime)
	
	Iy_Ih_TimingTime <- system.time({
		progressions$Iy_Ih_rand <- runif(n = nrow(progressions), min = 0, max = 1)
		progressions$Iy_Ih_EndTime <- progressions$Py_EndTime + (-log(1-progressions$Iy_Ih_rand)/I(1/params$JailHouse_Duration_Iy_Ih))
	}, gcFirst = FALSE)
	dBugStage(Iy_Ih_TimingTime)
	
	Iy_Rr_TimingTime <- system.time({
		progressions$Iy_Rr_rand <- runif(n = nrow(progressions), min = 0, max = 1)
		progressions$Iy_Rr_EndTime <- progressions$Py_EndTime + (-log(1-progressions$Iy_Rr_rand)/I(1/params$JailHouse_Duration_Iy_Rr))
	}, gcFirst = FALSE)
	dBugStage(Iy_Rr_TimingTime)
	
	Ih_Rr_TimingTime <- system.time({
		progressions$Ih_Rr_rand <- runif(n = nrow(progressions), min = 0, max = 1)
		progressions$Ih_Rr_EndTime <- progressions$Iy_Ih_EndTime + (-log(1-progressions$Ih_Rr_rand)/I(1/params$JailHouse_Duration_Ih_Rr))
	}, gcFirst = FALSE)
	dBugStage(Ih_Rr_TimingTime)
	
	Ih_Rd_TimingTime <- system.time({
		progressions$Ih_Rd_rand <- runif(n = nrow(progressions), min = 0, max = 1)
		progressions$Ih_Rd_EndTime <- progressions$Iy_Ih_EndTime + (-log(1-progressions$Ih_Rd_rand)/I(1/params$JailHouse_Duration_Ih_Rd))
	}, gcFirst = FALSE)
	dBugStage(Ih_Rd_TimingTime)
	
	runData$progressions <- progressions
	
	progressions$ModelNum <- params$Model
	progressions$subModelID <- subModelID
	
	dBugStage(head(progressions))
	dBugStage(tail(progressions))
	dBugStage(nrow(progressions))
	dBugStage(str(progressions))

	if (params$AllProgressionsOut == "On") {
		dBugOuts(head(progressions))
		save(progressions, file=sprintf("%sCovidABM7_AllProgressions_%s_job%s.Rdata", params$outdir, params$Model, params$job))
	}

	print("[CoreStage]          Staging Outputs") 
	runData$DirectExposures_vec <- rep(0, length(runData$agentIndex_vec)) 
	dBugStage(table(runData$DirectExposures_vec, exclude=NULL))
	
	runData$FloutInfects_vec <- rep(0, length(runData$agentIndex_vec)) 
	dBugStage(table(runData$FloutInfects_vec, exclude=NULL))
	
	runData$IaInfects_vec <- rep(0, length(runData$agentIndex_vec)) 
	dBugStage(table(runData$IaInfects_vec, exclude=NULL))
	
	runData$EssentialInfects_vec <- rep(0, length(runData$agentIndex_vec)) 
	dBugStage(table(runData$EssentialInfects_vec, exclude=NULL))
	
	#EssentialAct_W <- NULL
	#NonEssentialAct_W <- NULL
	#YesterdayFloutTargets <- NULL

	print("[CoreStage]          Staging Turns") 
	#Turns <- NULL
	#PastTurns <- NULL
#	runData$Progress_Turns <- NULL

	print("[CoreStage]          JailHouse Runtime Staging cleaning up")

	print("[CoreStage]          JailHouse Runtime Staging finished")

	runData$agents <- populationData$agents
	runData$Alter_vec <- populationData$JailHouseAlter_vec

	runData$Current_Awareness <- 0
	
	return(runData)
}#------End of JailHouseRuntimeStaging function


